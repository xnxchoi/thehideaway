import { MigrateUpArgs, MigrateDownArgs, sql } from '@payloadcms/db-postgres'

export async function up({ db, payload, req }: MigrateUpArgs): Promise<void> {
  await db.execute(sql`
   DROP INDEX "search_tags_tag_key_idx";
  DROP INDEX "search_tags_weight_idx";
  ALTER TABLE "search_tags" ALTER COLUMN "tag_title" SET NOT NULL;
  ALTER TABLE "search_tags" ALTER COLUMN "tag_key" SET NOT NULL;
  ALTER TABLE "search_tags" ALTER COLUMN "weight" SET NOT NULL;
  ALTER TABLE "search" ALTER COLUMN "slug" SET NOT NULL;
  ALTER TABLE "search_rels" ADD COLUMN "posts_id" uuid;
  ALTER TABLE "search_rels" ADD COLUMN "delta_id" uuid;
  ALTER TABLE "search_rels" ADD COLUMN "albums_id" uuid;
  ALTER TABLE "search_rels" ADD COLUMN "users_id" uuid;
  ALTER TABLE "search_rels" ADD CONSTRAINT "search_rels_posts_fk" FOREIGN KEY ("posts_id") REFERENCES "public"."posts"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "search_rels" ADD CONSTRAINT "search_rels_delta_fk" FOREIGN KEY ("delta_id") REFERENCES "public"."delta"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "search_rels" ADD CONSTRAINT "search_rels_albums_fk" FOREIGN KEY ("albums_id") REFERENCES "public"."albums"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "search_rels" ADD CONSTRAINT "search_rels_users_fk" FOREIGN KEY ("users_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
  CREATE INDEX "search_rels_posts_id_idx" ON "search_rels" USING btree ("posts_id");
  CREATE INDEX "search_rels_delta_id_idx" ON "search_rels" USING btree ("delta_id");
  CREATE INDEX "search_rels_albums_id_idx" ON "search_rels" USING btree ("albums_id");
  CREATE INDEX "search_rels_users_id_idx" ON "search_rels" USING btree ("users_id");`)
}

export async function down({ db, payload, req }: MigrateDownArgs): Promise<void> {
  await db.execute(sql`
   ALTER TABLE "search_rels" DROP CONSTRAINT "search_rels_posts_fk";
  
  ALTER TABLE "search_rels" DROP CONSTRAINT "search_rels_delta_fk";
  
  ALTER TABLE "search_rels" DROP CONSTRAINT "search_rels_albums_fk";
  
  ALTER TABLE "search_rels" DROP CONSTRAINT "search_rels_users_fk";
  
  DROP INDEX "search_rels_posts_id_idx";
  DROP INDEX "search_rels_delta_id_idx";
  DROP INDEX "search_rels_albums_id_idx";
  DROP INDEX "search_rels_users_id_idx";
  ALTER TABLE "search_tags" ALTER COLUMN "tag_title" DROP NOT NULL;
  ALTER TABLE "search_tags" ALTER COLUMN "tag_key" DROP NOT NULL;
  ALTER TABLE "search_tags" ALTER COLUMN "weight" DROP NOT NULL;
  ALTER TABLE "search" ALTER COLUMN "slug" DROP NOT NULL;
  CREATE INDEX "search_tags_tag_key_idx" ON "search_tags" USING btree ("tag_key");
  CREATE INDEX "search_tags_weight_idx" ON "search_tags" USING btree ("weight");
  ALTER TABLE "search_rels" DROP COLUMN "posts_id";
  ALTER TABLE "search_rels" DROP COLUMN "delta_id";
  ALTER TABLE "search_rels" DROP COLUMN "albums_id";
  ALTER TABLE "search_rels" DROP COLUMN "users_id";`)
}
