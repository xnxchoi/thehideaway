import * as migration_20250829_163805 from "./20250829_163805";
import * as migration_20250901_184900 from "./20250901_184900";
import * as migration_20250902_032249 from "./20250902_032249";
import * as migration_20250909_063018 from "./20250909_063018";
import * as migration_20250912_150418 from "./20250912_150418";

export const migrations = [
  {
    up: migration_20250829_163805.up,
    down: migration_20250829_163805.down,
    name: "20250829_163805"
  },
  {
    up: migration_20250901_184900.up,
    down: migration_20250901_184900.down,
    name: "20250901_184900"
  },
  {
    up: migration_20250902_032249.up,
    down: migration_20250902_032249.down,
    name: "20250902_032249"
  },
  {
    up: migration_20250909_063018.up,
    down: migration_20250909_063018.down,
    name: "20250909_063018"
  },
  {
    up: migration_20250912_150418.up,
    down: migration_20250912_150418.down,
    name: "20250912_150418"
  }
];
