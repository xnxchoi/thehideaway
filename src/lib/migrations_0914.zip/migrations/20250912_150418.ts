import { MigrateUpArgs, MigrateDownArgs, sql } from '@payloadcms/db-postgres'

export async function up({ db, payload, req }: MigrateUpArgs): Promise<void> {
  await db.execute(sql`
   CREATE TYPE "public"."enum_deferred_emails_category" AS ENUM('notifications', 'alerts', 'validators', 'authenticators', 'misc');
  CREATE TYPE "public"."enum_deferred_emails_status" AS ENUM('pending', 'sent', 'failed');
  CREATE TABLE "email_quota" (
  	"id" uuid PRIMARY KEY DEFAULT uuidv7() NOT NULL,
  	"date" varchar NOT NULL,
  	"used" numeric DEFAULT 0 NOT NULL,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  CREATE TABLE "deferred_emails" (
  	"id" uuid PRIMARY KEY DEFAULT uuidv7() NOT NULL,
  	"email_data" varchar NOT NULL,
  	"category" "enum_deferred_emails_category" NOT NULL,
  	"scheduled_for" timestamp(3) with time zone NOT NULL,
  	"attempts" numeric DEFAULT 0 NOT NULL,
  	"status" "enum_deferred_emails_status" DEFAULT 'pending' NOT NULL,
  	"sent_at" timestamp(3) with time zone,
  	"last_error" varchar,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL
  );
  
  ALTER TABLE "payload_locked_documents_rels" ADD COLUMN "email_quota_id" uuid;
  ALTER TABLE "payload_locked_documents_rels" ADD COLUMN "deferred_emails_id" uuid;
  CREATE UNIQUE INDEX "email_quota_date_idx" ON "email_quota" USING btree ("date");
  CREATE INDEX "email_quota_updated_at_idx" ON "email_quota" USING btree ("updated_at");
  CREATE INDEX "email_quota_created_at_idx" ON "email_quota" USING btree ("created_at");
  CREATE INDEX "deferred_emails_updated_at_idx" ON "deferred_emails" USING btree ("updated_at");
  CREATE INDEX "deferred_emails_created_at_idx" ON "deferred_emails" USING btree ("created_at");
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_email_quota_fk" FOREIGN KEY ("email_quota_id") REFERENCES "public"."email_quota"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_deferred_emails_fk" FOREIGN KEY ("deferred_emails_id") REFERENCES "public"."deferred_emails"("id") ON DELETE cascade ON UPDATE no action;
  CREATE INDEX "payload_locked_documents_rels_email_quota_id_idx" ON "payload_locked_documents_rels" USING btree ("email_quota_id");
  CREATE INDEX "payload_locked_documents_rels_deferred_emails_id_idx" ON "payload_locked_documents_rels" USING btree ("deferred_emails_id");`)
}

export async function down({ db, payload, req }: MigrateDownArgs): Promise<void> {
  await db.execute(sql`
   ALTER TABLE "email_quota" DISABLE ROW LEVEL SECURITY;
  ALTER TABLE "deferred_emails" DISABLE ROW LEVEL SECURITY;
  DROP TABLE "email_quota" CASCADE;
  DROP TABLE "deferred_emails" CASCADE;
  ALTER TABLE "payload_locked_documents_rels" DROP CONSTRAINT "payload_locked_documents_rels_email_quota_fk";
  
  ALTER TABLE "payload_locked_documents_rels" DROP CONSTRAINT "payload_locked_documents_rels_deferred_emails_fk";
  
  DROP INDEX "payload_locked_documents_rels_email_quota_id_idx";
  DROP INDEX "payload_locked_documents_rels_deferred_emails_id_idx";
  ALTER TABLE "payload_locked_documents_rels" DROP COLUMN "email_quota_id";
  ALTER TABLE "payload_locked_documents_rels" DROP COLUMN "deferred_emails_id";
  DROP TYPE "public"."enum_deferred_emails_category";
  DROP TYPE "public"."enum_deferred_emails_status";`)
}
