import { MigrateUpArgs, MigrateDownArgs, sql } from '@payloadcms/db-postgres'

export async function up({ db, payload, req }: MigrateUpArgs): Promise<void> {
  await db.execute(sql`
   CREATE TYPE "public"."enum_responses_status" AS ENUM('draft', 'published');
  CREATE TYPE "public"."enum__responses_v_version_status" AS ENUM('draft', 'published');
  CREATE TYPE "public"."enum__responses_v_published_locale" AS ENUM('en', 'ko');
  CREATE TABLE "responses" (
  	"id" uuid PRIMARY KEY DEFAULT uuidv7() NOT NULL,
  	"content" jsonb,
  	"author_id" uuid,
  	"is_edited" boolean DEFAULT false,
  	"depth" numeric DEFAULT 0,
  	"hash" varchar,
  	"parent_id" uuid,
  	"is_sticky" boolean DEFAULT false,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"_status" "enum_responses_status" DEFAULT 'draft'
  );
  
  CREATE TABLE "responses_rels" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"order" integer,
  	"parent_id" uuid NOT NULL,
  	"path" varchar NOT NULL,
  	"posts_id" uuid,
  	"delta_id" uuid,
  	"users_id" uuid
  );
  
  CREATE TABLE "_responses_v" (
  	"id" uuid PRIMARY KEY DEFAULT uuidv7() NOT NULL,
  	"parent_id" uuid,
  	"version_content" jsonb,
  	"version_author_id" uuid,
  	"version_is_edited" boolean DEFAULT false,
  	"version_depth" numeric DEFAULT 0,
  	"version_hash" varchar,
  	"version_parent_id" uuid,
  	"version_is_sticky" boolean,
  	"version_updated_at" timestamp(3) with time zone,
  	"version_created_at" timestamp(3) with time zone,
  	"version__status" "enum__responses_v_version_status" DEFAULT 'draft',
  	"created_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"updated_at" timestamp(3) with time zone DEFAULT now() NOT NULL,
  	"snapshot" boolean,
  	"published_locale" "enum__responses_v_published_locale",
  	"latest" boolean
  );
  
  CREATE TABLE "_responses_v_rels" (
  	"id" serial PRIMARY KEY NOT NULL,
  	"order" integer,
  	"parent_id" uuid NOT NULL,
  	"path" varchar NOT NULL,
  	"posts_id" uuid,
  	"delta_id" uuid,
  	"users_id" uuid
  );
  
  ALTER TABLE "search_rels" DROP CONSTRAINT "search_rels_posts_fk";
  
  ALTER TABLE "search_rels" DROP CONSTRAINT "search_rels_delta_fk";
  
  ALTER TABLE "search_rels" DROP CONSTRAINT "search_rels_users_fk";
  
  ALTER TABLE "search_rels" DROP CONSTRAINT "search_rels_albums_fk";
  
  ALTER TABLE "search_rels" DROP CONSTRAINT "search_rels_playlists_fk";
  
  ALTER TABLE "search_rels" DROP CONSTRAINT "search_rels_tracks_fk";
  
  DROP INDEX "search_rels_posts_id_idx";
  DROP INDEX "search_rels_delta_id_idx";
  DROP INDEX "search_rels_users_id_idx";
  DROP INDEX "search_rels_albums_id_idx";
  DROP INDEX "search_rels_playlists_id_idx";
  DROP INDEX "search_rels_tracks_id_idx";
  ALTER TABLE "posts" ADD COLUMN "comments_enabled" boolean;
  ALTER TABLE "_posts_v" ADD COLUMN "version_comments_enabled" boolean;
  ALTER TABLE "delta" ADD COLUMN "comments_enabled" boolean;
  ALTER TABLE "_delta_v" ADD COLUMN "version_comments_enabled" boolean;
  ALTER TABLE "payload_locked_documents_rels" ADD COLUMN "responses_id" uuid;
  ALTER TABLE "responses" ADD CONSTRAINT "responses_author_id_users_id_fk" FOREIGN KEY ("author_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "responses" ADD CONSTRAINT "responses_parent_id_responses_id_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."responses"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "responses_rels" ADD CONSTRAINT "responses_rels_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."responses"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "responses_rels" ADD CONSTRAINT "responses_rels_posts_fk" FOREIGN KEY ("posts_id") REFERENCES "public"."posts"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "responses_rels" ADD CONSTRAINT "responses_rels_delta_fk" FOREIGN KEY ("delta_id") REFERENCES "public"."delta"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "responses_rels" ADD CONSTRAINT "responses_rels_users_fk" FOREIGN KEY ("users_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "_responses_v" ADD CONSTRAINT "_responses_v_parent_id_responses_id_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."responses"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "_responses_v" ADD CONSTRAINT "_responses_v_version_author_id_users_id_fk" FOREIGN KEY ("version_author_id") REFERENCES "public"."users"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "_responses_v" ADD CONSTRAINT "_responses_v_version_parent_id_responses_id_fk" FOREIGN KEY ("version_parent_id") REFERENCES "public"."responses"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "_responses_v_rels" ADD CONSTRAINT "_responses_v_rels_parent_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."_responses_v"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "_responses_v_rels" ADD CONSTRAINT "_responses_v_rels_posts_fk" FOREIGN KEY ("posts_id") REFERENCES "public"."posts"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "_responses_v_rels" ADD CONSTRAINT "_responses_v_rels_delta_fk" FOREIGN KEY ("delta_id") REFERENCES "public"."delta"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "_responses_v_rels" ADD CONSTRAINT "_responses_v_rels_users_fk" FOREIGN KEY ("users_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
  CREATE INDEX "responses_author_idx" ON "responses" USING btree ("author_id");
  CREATE INDEX "responses_depth_idx" ON "responses" USING btree ("depth");
  CREATE INDEX "responses_hash_idx" ON "responses" USING btree ("hash");
  CREATE INDEX "responses_parent_idx" ON "responses" USING btree ("parent_id");
  CREATE INDEX "responses_is_sticky_idx" ON "responses" USING btree ("is_sticky");
  CREATE INDEX "responses_updated_at_idx" ON "responses" USING btree ("updated_at");
  CREATE INDEX "responses_created_at_idx" ON "responses" USING btree ("created_at");
  CREATE INDEX "responses__status_idx" ON "responses" USING btree ("_status");
  CREATE INDEX "responses_rels_order_idx" ON "responses_rels" USING btree ("order");
  CREATE INDEX "responses_rels_parent_idx" ON "responses_rels" USING btree ("parent_id");
  CREATE INDEX "responses_rels_path_idx" ON "responses_rels" USING btree ("path");
  CREATE INDEX "responses_rels_posts_id_idx" ON "responses_rels" USING btree ("posts_id");
  CREATE INDEX "responses_rels_delta_id_idx" ON "responses_rels" USING btree ("delta_id");
  CREATE INDEX "responses_rels_users_id_idx" ON "responses_rels" USING btree ("users_id");
  CREATE INDEX "_responses_v_parent_idx" ON "_responses_v" USING btree ("parent_id");
  CREATE INDEX "_responses_v_version_version_author_idx" ON "_responses_v" USING btree ("version_author_id");
  CREATE INDEX "_responses_v_version_version_depth_idx" ON "_responses_v" USING btree ("version_depth");
  CREATE INDEX "_responses_v_version_version_hash_idx" ON "_responses_v" USING btree ("version_hash");
  CREATE INDEX "_responses_v_version_version_parent_idx" ON "_responses_v" USING btree ("version_parent_id");
  CREATE INDEX "_responses_v_version_version_is_sticky_idx" ON "_responses_v" USING btree ("version_is_sticky");
  CREATE INDEX "_responses_v_version_version_updated_at_idx" ON "_responses_v" USING btree ("version_updated_at");
  CREATE INDEX "_responses_v_version_version_created_at_idx" ON "_responses_v" USING btree ("version_created_at");
  CREATE INDEX "_responses_v_version_version__status_idx" ON "_responses_v" USING btree ("version__status");
  CREATE INDEX "_responses_v_created_at_idx" ON "_responses_v" USING btree ("created_at");
  CREATE INDEX "_responses_v_updated_at_idx" ON "_responses_v" USING btree ("updated_at");
  CREATE INDEX "_responses_v_snapshot_idx" ON "_responses_v" USING btree ("snapshot");
  CREATE INDEX "_responses_v_published_locale_idx" ON "_responses_v" USING btree ("published_locale");
  CREATE INDEX "_responses_v_latest_idx" ON "_responses_v" USING btree ("latest");
  CREATE INDEX "_responses_v_rels_order_idx" ON "_responses_v_rels" USING btree ("order");
  CREATE INDEX "_responses_v_rels_parent_idx" ON "_responses_v_rels" USING btree ("parent_id");
  CREATE INDEX "_responses_v_rels_path_idx" ON "_responses_v_rels" USING btree ("path");
  CREATE INDEX "_responses_v_rels_posts_id_idx" ON "_responses_v_rels" USING btree ("posts_id");
  CREATE INDEX "_responses_v_rels_delta_id_idx" ON "_responses_v_rels" USING btree ("delta_id");
  CREATE INDEX "_responses_v_rels_users_id_idx" ON "_responses_v_rels" USING btree ("users_id");
  ALTER TABLE "payload_locked_documents_rels" ADD CONSTRAINT "payload_locked_documents_rels_responses_fk" FOREIGN KEY ("responses_id") REFERENCES "public"."responses"("id") ON DELETE cascade ON UPDATE no action;
  CREATE INDEX "posts_comments_enabled_idx" ON "posts" USING btree ("comments_enabled");
  CREATE INDEX "_posts_v_version_version_comments_enabled_idx" ON "_posts_v" USING btree ("version_comments_enabled");
  CREATE INDEX "delta_comments_enabled_idx" ON "delta" USING btree ("comments_enabled");
  CREATE INDEX "_delta_v_version_version_comments_enabled_idx" ON "_delta_v" USING btree ("version_comments_enabled");
  CREATE INDEX "payload_locked_documents_rels_responses_id_idx" ON "payload_locked_documents_rels" USING btree ("responses_id");
  ALTER TABLE "search_rels" DROP COLUMN "posts_id";
  ALTER TABLE "search_rels" DROP COLUMN "delta_id";
  ALTER TABLE "search_rels" DROP COLUMN "users_id";
  ALTER TABLE "search_rels" DROP COLUMN "albums_id";
  ALTER TABLE "search_rels" DROP COLUMN "playlists_id";
  ALTER TABLE "search_rels" DROP COLUMN "tracks_id";`)
}

export async function down({ db, payload, req }: MigrateDownArgs): Promise<void> {
  await db.execute(sql`
   ALTER TABLE "responses" DISABLE ROW LEVEL SECURITY;
  ALTER TABLE "responses_rels" DISABLE ROW LEVEL SECURITY;
  ALTER TABLE "_responses_v" DISABLE ROW LEVEL SECURITY;
  ALTER TABLE "_responses_v_rels" DISABLE ROW LEVEL SECURITY;
  DROP TABLE "responses" CASCADE;
  DROP TABLE "responses_rels" CASCADE;
  DROP TABLE "_responses_v" CASCADE;
  DROP TABLE "_responses_v_rels" CASCADE;
  ALTER TABLE "payload_locked_documents_rels" DROP CONSTRAINT "payload_locked_documents_rels_responses_fk";
  
  DROP INDEX "posts_comments_enabled_idx";
  DROP INDEX "_posts_v_version_version_comments_enabled_idx";
  DROP INDEX "delta_comments_enabled_idx";
  DROP INDEX "_delta_v_version_version_comments_enabled_idx";
  DROP INDEX "payload_locked_documents_rels_responses_id_idx";
  ALTER TABLE "search_rels" ADD COLUMN "posts_id" uuid;
  ALTER TABLE "search_rels" ADD COLUMN "delta_id" uuid;
  ALTER TABLE "search_rels" ADD COLUMN "users_id" uuid;
  ALTER TABLE "search_rels" ADD COLUMN "albums_id" uuid;
  ALTER TABLE "search_rels" ADD COLUMN "playlists_id" uuid;
  ALTER TABLE "search_rels" ADD COLUMN "tracks_id" uuid;
  ALTER TABLE "search_rels" ADD CONSTRAINT "search_rels_posts_fk" FOREIGN KEY ("posts_id") REFERENCES "public"."posts"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "search_rels" ADD CONSTRAINT "search_rels_delta_fk" FOREIGN KEY ("delta_id") REFERENCES "public"."delta"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "search_rels" ADD CONSTRAINT "search_rels_users_fk" FOREIGN KEY ("users_id") REFERENCES "public"."users"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "search_rels" ADD CONSTRAINT "search_rels_albums_fk" FOREIGN KEY ("albums_id") REFERENCES "public"."albums"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "search_rels" ADD CONSTRAINT "search_rels_playlists_fk" FOREIGN KEY ("playlists_id") REFERENCES "public"."playlists"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "search_rels" ADD CONSTRAINT "search_rels_tracks_fk" FOREIGN KEY ("tracks_id") REFERENCES "public"."tracks"("id") ON DELETE cascade ON UPDATE no action;
  CREATE INDEX "search_rels_posts_id_idx" ON "search_rels" USING btree ("posts_id");
  CREATE INDEX "search_rels_delta_id_idx" ON "search_rels" USING btree ("delta_id");
  CREATE INDEX "search_rels_users_id_idx" ON "search_rels" USING btree ("users_id");
  CREATE INDEX "search_rels_albums_id_idx" ON "search_rels" USING btree ("albums_id");
  CREATE INDEX "search_rels_playlists_id_idx" ON "search_rels" USING btree ("playlists_id");
  CREATE INDEX "search_rels_tracks_id_idx" ON "search_rels" USING btree ("tracks_id");
  ALTER TABLE "posts" DROP COLUMN "comments_enabled";
  ALTER TABLE "_posts_v" DROP COLUMN "version_comments_enabled";
  ALTER TABLE "delta" DROP COLUMN "comments_enabled";
  ALTER TABLE "_delta_v" DROP COLUMN "version_comments_enabled";
  ALTER TABLE "payload_locked_documents_rels" DROP COLUMN "responses_id";
  DROP TYPE "public"."enum_responses_status";
  DROP TYPE "public"."enum__responses_v_version_status";
  DROP TYPE "public"."enum__responses_v_published_locale";`)
}
