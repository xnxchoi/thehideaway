import { MigrateUpArgs, MigrateDownArgs, sql } from '@payloadcms/db-postgres'

export async function up({ db, payload, req }: MigrateUpArgs): Promise<void> {
  await db.execute(sql`
   ALTER TABLE "responses" DROP CONSTRAINT "responses_parent_id_responses_id_fk";
  
  ALTER TABLE "_responses_v" DROP CONSTRAINT "_responses_v_version_parent_id_responses_id_fk";
  
  DROP INDEX "responses_parent_idx";
  DROP INDEX "_responses_v_version_version_parent_idx";
  ALTER TABLE "responses_rels" ADD COLUMN "responses_id" uuid;
  ALTER TABLE "responses_rels" ADD COLUMN "citations_id" uuid;
  ALTER TABLE "_responses_v_rels" ADD COLUMN "responses_id" uuid;
  ALTER TABLE "_responses_v_rels" ADD COLUMN "citations_id" uuid;
  ALTER TABLE "responses_rels" ADD CONSTRAINT "responses_rels_responses_fk" FOREIGN KEY ("responses_id") REFERENCES "public"."responses"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "responses_rels" ADD CONSTRAINT "responses_rels_citations_fk" FOREIGN KEY ("citations_id") REFERENCES "public"."citations"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "_responses_v_rels" ADD CONSTRAINT "_responses_v_rels_responses_fk" FOREIGN KEY ("responses_id") REFERENCES "public"."responses"("id") ON DELETE cascade ON UPDATE no action;
  ALTER TABLE "_responses_v_rels" ADD CONSTRAINT "_responses_v_rels_citations_fk" FOREIGN KEY ("citations_id") REFERENCES "public"."citations"("id") ON DELETE cascade ON UPDATE no action;
  CREATE INDEX "responses_rels_responses_id_idx" ON "responses_rels" USING btree ("responses_id");
  CREATE INDEX "responses_rels_citations_id_idx" ON "responses_rels" USING btree ("citations_id");
  CREATE INDEX "_responses_v_rels_responses_id_idx" ON "_responses_v_rels" USING btree ("responses_id");
  CREATE INDEX "_responses_v_rels_citations_id_idx" ON "_responses_v_rels" USING btree ("citations_id");
  ALTER TABLE "responses" DROP COLUMN "parent_id";
  ALTER TABLE "_responses_v" DROP COLUMN "version_parent_id";`)
}

export async function down({ db, payload, req }: MigrateDownArgs): Promise<void> {
  await db.execute(sql`
   ALTER TABLE "responses_rels" DROP CONSTRAINT "responses_rels_responses_fk";
  
  ALTER TABLE "responses_rels" DROP CONSTRAINT "responses_rels_citations_fk";
  
  ALTER TABLE "_responses_v_rels" DROP CONSTRAINT "_responses_v_rels_responses_fk";
  
  ALTER TABLE "_responses_v_rels" DROP CONSTRAINT "_responses_v_rels_citations_fk";
  
  DROP INDEX "responses_rels_responses_id_idx";
  DROP INDEX "responses_rels_citations_id_idx";
  DROP INDEX "_responses_v_rels_responses_id_idx";
  DROP INDEX "_responses_v_rels_citations_id_idx";
  ALTER TABLE "responses" ADD COLUMN "parent_id" uuid;
  ALTER TABLE "_responses_v" ADD COLUMN "version_parent_id" uuid;
  ALTER TABLE "responses" ADD CONSTRAINT "responses_parent_id_responses_id_fk" FOREIGN KEY ("parent_id") REFERENCES "public"."responses"("id") ON DELETE set null ON UPDATE no action;
  ALTER TABLE "_responses_v" ADD CONSTRAINT "_responses_v_version_parent_id_responses_id_fk" FOREIGN KEY ("version_parent_id") REFERENCES "public"."responses"("id") ON DELETE set null ON UPDATE no action;
  CREATE INDEX "responses_parent_idx" ON "responses" USING btree ("parent_id");
  CREATE INDEX "_responses_v_version_version_parent_idx" ON "_responses_v" USING btree ("version_parent_id");
  ALTER TABLE "responses_rels" DROP COLUMN "responses_id";
  ALTER TABLE "responses_rels" DROP COLUMN "citations_id";
  ALTER TABLE "_responses_v_rels" DROP COLUMN "responses_id";
  ALTER TABLE "_responses_v_rels" DROP COLUMN "citations_id";`)
}
