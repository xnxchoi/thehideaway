'use client'
import { usePathname } from 'next/navigation'
import { CollectionSlug } from 'payload'
import { Category, Member, Page, Post, Surf } from '@/payload-types'
import { createStore } from 'zustand/vanilla'
import { createContext, ReactNode, useContext, useEffect, useRef } from 'react'
import { useStore } from 'zustand/index'
import { getMenuPagePreviewKey } from '@/utilities/Helpers'

export type RP_Voyage = {
  url: string
  pathName: string
  slug: string[]
  pageType: string | CollectionSlug
  is404: boolean
  isHome: boolean
  isArchive: boolean
  pageKey: string | -1
}

/**
 *  Type containing all possible **valid** page type information.
 *  null value has been omitted; subject to future modifications.
 *  Intended to be similar to the return value of usePathname().
 *  Admittedly,format is rather confusing as-is due to CollectionSlug literally containing the word 'slug'
 *
 *
 */
export type PageType = string | CollectionSlug
export type PageSlug = string[]
export type PageURL = {
  pageType: PageType
  slug: PageSlug
}

/**
 *
 * Type to extract Collections that have explicitly visible pages(archives, pagination,single pages, etc.)
 * Should be updated as site structure changes.
 * @todo confirm the collections are exhaustive & security vulnerabilities don't exist
 *
 */
type StandAloneCollections = Page | Member | Surf | Post | Category
type LinkedSACollections<Type extends StandAloneCollections> = Type & {
  pageType: PageType
  slug: PageSlug
}
export type RP_Voyaget = {
  setSlug: (l: string[]) => void
  setPageType: (l: PageType) => void
  setPage: (l: { pageType: string; slug: string[] }) => void
  setIs404: (l: boolean) => void
  setIsHome: (l: boolean) => void
  setIsArchive: (l: boolean) => void
  setUrl: (l: string) => void
  setPageKey: (l: string | -1) => void
  setPathName: (l: string) => void
}
export type RP_Voyages = RP_Voyage & RP_Voyaget
const initialState: RP_Voyage = {
  pageKey: -1, pageType: 'pages', slug: [], isArchive: false, is404: false, isHome: false, url: '/', pathName: '/',
}
export const createVoyageur = (initState: RP_Voyage = initialState) => {
  return createStore<RP_Voyages>()((set) => ({
    ...initState,
    setIs404: (l: boolean) => set((state) => ({ is404: l })),
    setIsArchive: (l: boolean) => set((state) => ({ isArchive: l })),
    setPageType: (l) => set((state) => ({ pageType: l })),
    setSlug: (l: string[]) => set((state) => ({ slug: l })),
    setIsHome: (l: boolean) => set((state) => ({ isHome: l })),
    setPageKey: (l: string | -1) => set((state) => ({ pageKey: l })),
    setUrl: (l: string) => set((state) => ({ url: l })),
    setPathName: (l: string) => set((state) => ({ pathName: l })),
    setPage: (l: { pageType: PageType; slug: string[] }) => set((state) => ({
      ...state, ...l, pageKey: l.slug.length > 0 ? getMenuPagePreviewKey(l.pageType, l.slug[0]) : -1,
    })),
  }))
}
export type VoyageAPI = ReturnType<typeof createVoyageur>

export const VoyageContext = createContext<VoyageAPI | undefined>(undefined)
export const VoyageurProvider = (l: { children: ReactNode }) => {
  const { children } = l
  const vy = useRef<VoyageAPI>(undefined!)
  if (!vy.current) {
    vy.current = createVoyageur()
  }


  return <VoyageContext.Provider value={vy.current}>{children}</VoyageContext.Provider>
}
export const useVoyageur = <T, >(selector: (store: RP_Voyages) => T): T => {
  const context = useContext(VoyageContext)
  if (context === undefined) {
    throw new Error('useVoyageur must be used within a VoyageurProvider')
  }

  return useStore(context, selector)
}
const VB = ({children}:{children:ReactNode}) => {
  const setPathName=useVoyageur(l=>l.setPathName)
  const pathName=useVoyageur(l=>l.pathName)
  const   setIsHome  = useVoyageur(l => l.setIsHome)
  const pathname=usePathname()
  useEffect(() => {
    setPathName(pathname)
  }, [])
  useEffect(() => {
      setPathName(pathname)
  }, [pathname])
  useEffect(() => {
      setIsHome(pathName==='/'||pathName.startsWith('/home'))
  }, [pathName])
  return <>{children}</>
}
export const Voyageur=({children}:{children:ReactNode}) => {
  return <VoyageurProvider><VB>{children}</VB></VoyageurProvider>
}