'use client'

import { createStore } from 'zustand/vanilla'
import { CollectionSlug, SanitizedPermissions } from 'payload'
import type { Config, Footer, Header, Media, Member, Notification } from '@/payload-types'
import { RefObject } from 'react'
import { getMenuPagePreviewKey } from '@/utilities/Helpers'
import { Flatten } from '@/utilities/typeUtilities'
import { PageTransitionType } from '@/components/UX/Transition'
import { UAParser } from 'ua-parser-js'
import InAppSpy from 'inapp-spy'
import { BrowserNames, IASAppKeys, OSNames } from '@/providers/browserNames'
import { PayloadLinkProps } from 'src/components/UX/Link'
import { Theme } from '@/providers/Theme/types'

export type HA_RA = {
  playing: boolean
  autoPlayed: boolean
  playlist: {
    index: number
    time: number
    tracks: object
  }
  volume: number
  lastTime: {
    timestamp: number
    index: number
    time: number
  }
}
export type HA_RA_ACT = {
  setPlaying: (l: boolean) => void
  toggleRadio: () => void
  setAutoPlayed: (l: boolean) => void
  setTracks: (l: any) => void
  setTrack: (l: any) => void
  setVolume: (l: any) => void
  setLastTime: (l: any) => void
}

export type NavigationItemType = Flatten<Header['navItems']>
export type BasedCMSLink = PayloadLinkProps

type CommonLinkProps = Omit<BasedCMSLink, 'reference' | 'url' | 'type'>

export type ExternalLink = Required<{ type: 'custom' } & { url: string }> & CommonLinkProps
export type InternalLink = Required<{ type: 'reference' } & Pick<BasedCMSLink, 'reference'>> & CommonLinkProps
export type BackendLink<T extends BasedCMSLink> = T['type'] extends 'custom' ? ExternalLink : InternalLink
export type ColumnProps = {
  link: BackendLink<BasedCMSLink>
  id?: string | null | number
}

export type BackendLinkProps = {
  link: BasedCMSLink
} & NavigationItemType
export type NavigationProps = {
  navItems: BackendLinkProps[]
}
export type HA_UI = {
  globalSettings: {
    navigation: NavigationProps
    footer: Footer | null
  }
  notifications: RP_Notification[]
  headerTheme: string
  canInteract: boolean
  pageType: string | CollectionSlug
  pageSlug: string | CollectionSlug | null
  scrollDirection: 'up' | 'down' | string
  isScrolling: boolean
  cbMenu: string | boolean
  theme: Theme | string
  scrollY: number
  localStorageEnabled: boolean
  dropdownOpen: boolean
}
export type HA_UI_ACT = {
  setLocalStorageEnabled: (enabled: boolean) => void
  setHeaderTheme: (c: string) => void
  setNotifications: (c: RP_Notification[]) => void
  addNotification: (c: RP_Notification) => void
  deleteNotification: (c: number) => void
  setPageType: (l: CollectionSlug | string) => void
  setPageSlug: (l: CollectionSlug | string | null) => void
  setScroll: (l: { direction: number; isScrolling: boolean }) => void
  setTheme: (c: string) => void
  toggleTheme: () => void
  setCBmenu: (menu: string | boolean) => void
  setScrollY: (y: number) => void
  setCanInteract: (c: boolean) => void
  setGlobalSettings: (c: { navigation?: Partial<NavigationProps>; footer?: Footer }) => void
  setDropdownOpen: (c: boolean) => void
}

export type HA_MENU = {
  navIsOpenDebounced: boolean
  navIsOpen: boolean
  navImageExpanded: boolean
}
export type HA_MENU_ACT = {
  setNavIsOpenDebounced: (nextState: HA_MENU['navIsOpenDebounced']) => void
  setNavIsOpen: (nextState: HA_MENU['navIsOpen']) => void
  toggleMenu: () => void
  setNavImageExpanded: (c: boolean) => void
}
export type HA_PAGE = {
  pageThemes: {
    [url: string]: 'light' | 'dark'
  }
  videoPopoutSrc: null | string
  homepageHeroData: { [key: string]: any }
  homepageActivePortfolioItem: any
  homepageSelectedPortfolioItem: any
  homepageTheme: null | string
  homepageHoveringAllWork: boolean
  homepageSelectedAllWork: boolean
  homepageIsScrollingMobile: boolean
  caseStudyAnimatingDown: boolean
  allowCaseStudyPreviewKey: string | null
  footerLotties: {
    white: null | any
    black: null | any
  }
}
export type HA_PAGE_ACT = {
  setVideoPopoutSrc: (c: null | string) => void
  setFooterLotties: (l: { white?: any | null; black?: null | any }) => void
  setHomepageHeroData: (c: { [key: string]: any }) => void
  setHomepageActivePortfolioItem: (c: any) => void
  setPageThemes: (c: { theme: 'light' | 'dark'; url: string }) => void
  setHomepageSelectedPortfolioItem: (c: any) => void
  setHomepageTheme: (c: null | string) => void
  setHomepageHoveringAllWork: (c: boolean) => void
  setHomepageSelectedAllWork: (c: boolean) => void
  setHomepageIsScrollingMobile: (c: boolean) => void
  setCaseStudyAnimatingDown: (c: boolean) => void
  setAllowCaseStudyPreviewKey: (c: string) => void
}
export type HeaderTransitionType = 'fade' | 'slide' | null
export type HeaderTransitionSet={
  [x in 'in' | 'out']: GSAPTimeline|null
}
export type HA_ANIMATION = {
  navIsTransitioning: boolean
  transitionType: null | string | PageTransitionType
  transitionOutType: null | string | PageTransitionType
  isPreloader: boolean
  enablePreloaderAnimation: boolean
  preloaderAnimationType: string | null
  isAnimatingOutPreloader: boolean
  animateHeader: boolean
  headerAnimations: Partial<{
    [transition in NonNullable<HeaderTransitionType>]:HeaderTransitionSet
  }>|null
  currentHeaderAnimation: HeaderTransitionType
  pageIsTransitioning: boolean
  isTransitioningWipe: boolean
  navigationPageItemData: NavigationProps['navItems']
  navigationPageItemKeys: string[]
  navigationPageItemSelected: -1 | string
  navigationPageItemsToFetch: any[]
  navigationPreviewMediaByKey: {
    [key: string]: null | { desktop: Media | null; mobile: Media | null }
  }
  navigationPageItemHovered: -1 | string
  navigationPageIsTransitioning: boolean
}
export type HA_ANIMATION_ACT = {
  setNavIsTransitioning: (l: boolean) => void
  setPageIsTransitioning: (l: boolean) => void

  setTransitionType: (l: string | PageTransitionType) => void
  setIsPreloader: (isPreloader: boolean) => void
  togglePreloaderAnimation: (state: boolean) => void
  setHeaderAnimations: (c: Partial<{
    [type in NonNullable<HeaderTransitionType>]: { [direction in 'in' | 'out']: GSAPTimeline }
  }>) => void
setAnimateHeader: (c: boolean) => void
  setCurrentHeaderAnimation: (c: HeaderTransitionType) => void
  setIsAnimatingOutPreloader: (isAnimatingOutPreloader: boolean) => void
  setNavigationPageItemData: (c: Header['navItems']) => void
  setNavigationPageItemSelected: (c: -1 | string) => void
  setNavigationPageIsTransitioning: (c: boolean) => void
  setTransitionOutType: (c: null | string | PageTransitionType) => void
  setIsTransitioningWipe: (l: boolean) => void
  setNavigationPageItemsToFetch: (c: any[]) => void
  setNavigationPreviewMediaByKey: (c: { [key: string]: any }) => void
  setNavigationPageItemHovered: (c: -1 | string) => void
}

export type HA_DEVICE = {
  device: {
    type?: 'mobile' | 'tablet' | 'console' | 'smarttv' | 'wearable' | 'xr' | 'embedded'
    vendor?: string
    model?: string
  }
  browser: {
    name: BrowserNames | IASAppKeys
    version?: string
    major?: string
    type?: 'crawler' | 'cli' | 'email' | 'fetcher' | 'inapp' | 'mediaplayer' | 'library'
  } & {
    chrome: boolean
    firefox: boolean
    safari: boolean
    edge: boolean
    ie: boolean
    opera: boolean
    messenger: boolean
    node: boolean
    instagram: boolean
    pinterest: boolean
    facebook: boolean
    linkedIn: boolean
    snapchat: boolean
    whatsApp: boolean
    twitter: boolean
    weChat: boolean
    tikTok: boolean
    kakaotalk: boolean
    gsa: boolean
    threads: boolean
    line: boolean
    inApp: boolean
  }
  os: {
    name: OSNames
    version?: string
    ios: boolean
    android: boolean
    windowsPhone: boolean
    blackBerry: boolean
    mac: boolean
    windows: boolean
    linux: boolean
    chromeos: boolean
    node: boolean
  } & { name?: string; version?: string }
  bots: boolean
  isTouchDevice: boolean
  isMobile: boolean
}
export type RP_Patron = Partial<Omit<Member, 'notifications'>> & Required<Pick<Member, 'id' | 'slug' | 'name'>>
export type RP_Notification =
  Partial<Notification>
  & Pick<Notification, 'status' | 'title' | 'content' | 'type' | 'createdAt'>
export type HA_MEMBER = {
  user: RP_Patron | null
  permissions: SanitizedPermissions | null | Permissions
}
export type HA_MEMBER_ACT = {
  setUser: (l: RP_Patron) => void
  setPermissions: (l: SanitizedPermissions | null | Permissions) => void
}
const uiInitState: HA_UI = {
  notifications: [],
  localStorageEnabled: false,
  pageType: 'pages',
  pageSlug: null,
  scrollDirection: 'down',
  isScrolling: false,
  cbMenu: false,
  scrollY: 0,

  theme: 'dark',
  canInteract: true,
  globalSettings: {
    navigation: { navItems: [] }, footer: null,
  },
  headerTheme: '',
  dropdownOpen: false,
}
const rpIn = {
  playing: false, autoPlayed: false, volume: 0.5, lastTime: {
    timestamp: 0, index: 0, time: 0,
  }, playlist: {
    index: 0, time: 0, tracks: [],
  },
}

const navIn: HA_MENU = {
  navImageExpanded: false, navIsOpen: false, navIsOpenDebounced: false,
}
const transIn: HA_ANIMATION = {
  navIsTransitioning: false,
  transitionType: null,
  transitionOutType: null,
  preloaderAnimationType: null,
  isTransitioningWipe: false,
  isPreloader: false,
  pageIsTransitioning: false,
  isAnimatingOutPreloader: false,
  animateHeader: false,
  headerAnimations:null,
  currentHeaderAnimation: null,
  navigationPreviewMediaByKey: {},
  navigationPageItemsToFetch: [],
  navigationPageItemKeys: [],
  navigationPageItemData: [],
  navigationPageItemHovered: -1,
  navigationPageItemSelected: -1,
  navigationPageIsTransitioning: !1,
  enablePreloaderAnimation: true,
}
const userInitSt: HA_MEMBER = {
  user: null, permissions: null,
}
const pageInit: HA_PAGE = {
  allowCaseStudyPreviewKey: null,
  videoPopoutSrc: null,
  footerLotties: {
    white: null, black: null,
  },
  pageThemes: {},
  homepageHeroData: {},
  homepageActivePortfolioItem: null,
  homepageSelectedPortfolioItem: null,
  homepageTheme: null,
  homepageHoveringAllWork: !1,
  homepageSelectedAllWork: !1,
  homepageIsScrollingMobile: !1,
  caseStudyAnimatingDown: !1,
}
export type HA_VLT = HA_UI & HA_RA & HA_MEMBER & HA_MENU & HA_ANIMATION & HA_PAGE
export type HA_ACT = HA_UI_ACT & HA_RA_ACT & HA_MEMBER_ACT & HA_MENU_ACT & HA_ANIMATION_ACT & HA_PAGE_ACT
export type HA_VAULT = HA_VLT & HA_ACT
export const HA_INIT: HA_VLT = {
  ...uiInitState, ...userInitSt, ...navIn, ...transIn, ...rpIn, ...pageInit,
}
export type RafRaf = {
  raf: null | number | RefObject<number | null>
}
export type RafAct = {
  addToRaf: (l: { key: string; callback: (l?: any) => void }) => void
  removeFromRaf: (l: string) => void
}
export type RAF = RafRaf & RafAct
const rafInit = {
  raf: null,
}
export const createRafStore = (actions: Partial<RafAct> = {}, initState: RafRaf = rafInit) => {
  return createStore<RAF>()((set) => ({
    addToRaf: () => {
    }, removeFromRaf: () => {
    }, ...actions, ...initState,
  }))
}
export const createHAStore = (initState: HA_VLT = {
  ...uiInitState, ...userInitSt, ...navIn, ...transIn, ...rpIn, ...pageInit,
}) => {
  return createStore<HA_VAULT>()((set) => ({
    ...initState,
    setLocalStorageEnabled: (localStorageEnabled: boolean) => set({ localStorageEnabled }),
    setNotifications: (l: RP_Notification[]) => set((state) => ({ ...state, notifications: [...l] }), true),
    addNotification: (l: RP_Notification) => set((state) => ({ notifications: [...state.notifications, l] })),
    deleteNotification: (l: number) => set((state) => ({
      ...state, notifications: state.notifications.filter((i, index) => index !== l),
    }), true),
    setHeaderTheme: (c: string) => set((state) => ({ headerTheme: c })),
    setIsPreloader: (c: boolean) => set((state) => ({ isPreloader: c })),
    setIsAnimatingOutPreloader: (c: boolean) => set((state) => ({ isAnimatingOutPreloader: c })),
    togglePreloaderAnimation: (c: boolean) => set((state) => ({ enablePreloaderAnimation: c })),
    setCanInteract: (c: boolean) => set((state) => ({
      canInteract: c,
    })),
    setIsTransitioningWipe: (l: boolean) => set((state) => ({ isTransitioningWipe: l })),
    setGlobalSettings: (c: {
      navigation?: Partial<NavigationProps>
      footer?: Pick<Footer, keyof Footer> | null
    }) => set((l) => ({
      ...l, globalSettings: {
        ...l.globalSettings, footer: c?.footer ?? l.globalSettings.footer, navigation: {
          ...l.globalSettings.navigation, navItems: c?.navigation?.navItems ?? l.globalSettings.navigation.navItems,
        },
      },
    }), true),
    setNavIsTransitioning: (l: boolean) => set((state) => ({ navIsTransitioning: l })),
    setPageIsTransitioning: (l: boolean) => set((state) => ({ pageIsTransitioning: l })),
    setTransitionOutType: (l: string | PageTransitionType) => set((state) => ({ transitionOutType: l })),
    setTransitionType: (l: string | PageTransitionType) => set((state) => ({ transitionType: l })),
    setNavigationPageItemData: (c: Header['navItems']) => set((state) => ({
      ...state, navigationPageItemData: c, navigationPageItemKeys: c?.flatMap((l) => {
        if (!l?.link || !l?.link.type) return []
        let typee = l.link.type === 'custom' ? 'external' : 'internal'
        if (typee === 'external') {
          if (!l.link.url) return []
          let xxx = l.link.url.split('/')
          return getMenuPagePreviewKey('pages', xxx[0])
        }
        const link = l.link.reference && l.link.reference.value && (typeof l.link.reference.value === 'object' ? (l.link.reference.value.slug) : `${l.link.reference.value}`) || ''
        return getMenuPagePreviewKey(l.link?.reference?.relationTo ?? 'pages', link)
      }),
    }), true),
    setHeaderAnimations:(c)=>set(state=>({
      headerAnimations:{
        ...state.headerAnimations,
        fade:{
          ...state.headerAnimations?.fade,
          in:c.fade?.in??state.headerAnimations?.fade?.in??null,
          out:c.fade?.in??state.headerAnimations?.fade?.in??null,
        },
        slide:{
          ...state.headerAnimations?.slide,
          in:c.slide?.in??state.headerAnimations?.slide?.in??null,
          out:c.slide?.out??state.headerAnimations?.slide?.out??null,
        }
      }
    })),
    setAnimateHeader: (c: boolean) => set((state) => ({
      animateHeader:c
    })),
    setCurrentHeaderAnimation: (c: HeaderTransitionType) => set((state) => ({
      currentHeaderAnimation: c,
    })),
    setNavigationPreviewMediaByKey: (c) => set({
      navigationPreviewMediaByKey: c,
    }),
    setNavigationPageItemsToFetch: (c) => set({
      navigationPageItemsToFetch: c,
    }),
    setNavigationPageItemHovered: (c) => set({
      navigationPageItemHovered: c,
    }),
    setNavigationPageItemSelected: (c) => set({
      navigationPageItemSelected: c,
    }),
    setNavigationPageIsTransitioning: (c) => set({
      navigationPageIsTransitioning: c,
    }),
    setScrollY: (scrollY: number) => set((state) => ({ scrollY })),
    setCBmenu: (openMenu: boolean | string) => set((state) => ({ ...state, cbMenu: openMenu })),
    setScroll: (l) => set((state) => ({
      isScrolling: l.isScrolling, scrollDirection: l.direction > 0 ? 'down' : 'up',
    })),
    setVideoPopoutSrc: (l) => set((state) => ({ videoPopoutSrc: l })),
    setNavIsOpen: (navIsOpen) => set({ navIsOpen }),
    toggleMenu: () => set((state) => ({ ...state, navIsOpen: !state.navIsOpen })),
    setNavIsOpenDebounced: (l: boolean) => set((state) => ({ navIsOpenDebounced: l })),
    setTrack: (l) => set((state) => ({ playlist: { ...state.playlist, index: l.index, time: l.time } })),
    setAutoPlayed: (l) => set((state) => ({ autoPlayed: l })),
    setPlaying: (l) => set((state) => ({ playing: l })),
    toggleRadio: () => set((state) => ({ playing: !state.playing })),
    setLastTime: (l) => set((state) => ({
      lastTime: {
        ...state.lastTime, time: l.time, index: l.index, timestamp: l.timestamp,
      },
    })),
    setVolume: (l) => set((state) => ({ volume: l })),
    setTracks: (l) => set((state) => ({ playlist: { ...state.playlist, tracks: l } })),
    setPageType: (l) => {
      set((state) => ({ pageType: '' + l }))
    },
    setPageSlug: (l: string) => set((state) => ({ pageSlug: l })),
    setDropdownOpen: (l: boolean) => set((state) => ({ dropdownOpen: l })),
    setPageThemes: (c) => set((state) => {
      const d = state.pageThemes
      d[c.url] = c.theme
      return { ...state, pageThemes: d }
    }),
    setFooterLotties: (c: { white: string | null; black: string | null }) => set((state) => ({
      footerLotties: { ...state.footerLotties, white: c.white, black: c.black },
    })),
    setHomepageHeroData: (c: { [key: string]: any }) => set((state) => ({ homepageHeroData: c })),
    setHomepageActivePortfolioItem: (l: any) => set((state) => ({ homepageActivePortfolioItem: l })),
    setHomepageSelectedPortfolioItem: (l: any) => set((state) => ({ homepageSelectedPortfolioItem: l })),
    setHomepageTheme: (l: string) => set((state) => ({ homepageTheme: l })),
    setHomepageHoveringAllWork: (c: boolean) => set((state) => ({ homepageHoveringAllWork: c })),
    setHomepageSelectedAllWork: (c: boolean) => set((state) => ({ homepageSelectedAllWork: c })),
    setHomepageIsScrollingMobile: (c: boolean) => set((state) => ({ homepageIsScrollingMobile: c })),
    setCaseStudyAnimatingDown: (c: boolean) => set((state) => ({ caseStudyAnimatingDown: c })),
    setAllowCaseStudyPreviewKey: (c: string) => set((state) => ({ allowCaseStudyPreviewKey: c })),
    setNavImageExpanded: (c: boolean) => set((state) => ({ navImageExpanded: c })),
    setTheme: (l: string) => set((state) => ({ theme: l })),
    toggleTheme: () => set((state) => ({ ...state, theme: state.theme === 'light' ? 'dark' : 'light' })),

    setUser: (l) => {
      set((state) => ({ ...state, user: l }), true)
    },
    setPermissions: (l) => {
      set((state) => ({ ...state, permissions: l }), true)
    },
  }))
}

export const createDeviceStore = () => {
  const uap = new UAParser()
  const isSpoofedIpad = /iPad/.test(navigator.platform) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1)
  const supportedBots = ['facebookexternalhit', 'skypeuripreview', 'baiduspider', 'linkedinbot', 'ia_archiver', 'duckduckbot', 'twitterbot', 'googlebot', 'yandexbot', 'bingbot', 'facebot', 'tumblr', 'slurp', 'google (+https://developers.google.com/+/web/snippet/)', 'https://developers.google.com/+/web/snippet/']
  const browser = uap.getBrowser() as UAParser.IBrowser & {
    name: BrowserNames
  }
  const os = uap.getOS() as UAParser.IOS & { name: OSNames }
  const device = uap.getDevice()
  const { appKey, isInApp, appName } = InAppSpy()
  const l: HA_DEVICE = {
    device: { ...device },
    browser: {
      ...browser,
      name: appKey ?? browser.name,
      instagram: appKey === 'instagram',
      pinterest: /pinterest/i.test(navigator.userAgent),
      facebook: appKey === 'facebook',
      whatsApp: /whatsapp/i.test(navigator.userAgent),
      twitter: /twitter/i.test(navigator.userAgent),
      kakaotalk: browser.name === 'KakaoTalk',
      weChat: /wechat|micromessenger/i.test(navigator.userAgent),
      threads: appKey === 'threads',
      messenger: appKey === 'messenger',
      line: appKey === 'line',
      tikTok: appKey === 'tiktok',
      linkedIn: appKey === 'linkedin',
      snapchat: appKey === 'snapchat',
      gsa: appKey === 'gsa',
      chrome: browser.name === 'chrome',
      firefox: browser.name === 'firefox',
      safari: browser.name === 'safari',
      edge: browser.name === 'microsoft-edge',
      ie: browser.name === 'internet-explorer',
      opera: browser.name === 'opera',
      node: browser.name === 'node',
      inApp: false,
    },
    os: {
      ...os,
      name: isSpoofedIpad ? 'ios' : (os.name ?? ''),
      ios: os.name === 'iOS',
      android: os.name === 'Android',
      windowsPhone: os.name === 'Windows Phone',
      blackBerry: os.name === 'BlackBerry',
      mac: os.name === 'macOS',
      windows: os.name === 'Windows',
      linux: os.name === 'Linux',
      chromeos: os.name === 'Chrome OS',
      node: os.name === 'node',
    },
    isTouchDevice: navigator.maxTouchPoints > 0,
    isMobile: device.type === 'mobile',
    bots: !!supportedBots.filter((bot: string) => navigator.userAgent.toLowerCase().includes(bot.toLowerCase())).length,
  }
  l.browser.inApp = l.browser.kakaotalk || l.browser.instagram || l.browser.pinterest || l.browser.facebook || l.browser.linkedIn || l.browser.snapchat || l.browser.whatsApp || l.browser.twitter || l.browser.weChat || l.browser.tikTok || isInApp
  if (l.browser.inApp) {
    l.browser.type = 'inapp'
  }
  if (l.os.android || l.os.ios) {
    l.isMobile = true
  }
  return l
}
