import { NextAuthConfig } from 'next-auth'
import { PayloadAuthjsUser } from 'payload-authjs'
import { Admin } from '@/payload-types'

declare module 'next-auth' {
  interface User extends PayloadAuthjsUser<Admin> {
  }
}
export const authAdminsConfig: NextAuthConfig = {
  basePath: '/api/auth/admins', cookies: {
    sessionToken: {
      name: 'authjs.admin-session-token',
    }, csrfToken: {
      name: 'authjs.admin-csrf-token',
    }, callbackUrl: {
      name: 'authjs.admin-callback-url',
    },
  }, session: { strategy: 'database' }, providers: [], callbacks: {
    authorized: ({ auth }) => !!auth,
  },
}