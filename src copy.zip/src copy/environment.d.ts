declare global {
  namespace NodeJS {
    interface ProcessEnv {
      PAYLOAD_SECRET: string
      DATABASE_URI: string
      NEXT_PUBLIC_SERVER_URL: string
      VERCEL_PROJECT_PRODUCTION_URL: string
      AUTH_NAVER_ID: string
      AUTH_NAVER_SECRET: string
      AUTH_ADMINS_GOOGLE_ID: string
      AUTH_ADMINS_GOOGLE_SECRET: string
      AUTH_MEMBERS_GOOGLE_ID: string
      AUTH_MEMBERS_GOOGLE_SECRET: string
      AUTH_KAKAO_ID: string
      AUTH_KAKAO_SECRET: string
    }
  }
}

// If this file has no import/export statements (i.e. is a script)
// convert it into a module by adding an empty export statement.
export {}
