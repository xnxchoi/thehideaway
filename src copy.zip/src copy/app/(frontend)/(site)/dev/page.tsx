import configPromise from '@payload-config'
import { getPayload } from 'payload'
import { LoaderLottie } from '@/components/UX/Loader/LoaderLottie'
import './index.scss'
import { Locked } from '@/components/UX/Locked/Locked'
import { GradientModule } from '@/components/UX/Gradient/Gradient'
export default async function Page() {
  const payload = await getPayload({ config: configPromise })

  return (
    <section className={'w-full h-screen relative p-0 m-0 flex flex-col items-center justify-center '} >
<Locked />
      <GradientModule/>
      {/* <div className={"wrapper"} style={{zIndex: 251}}> <svg aria-hidden="true" >
        <defs>
          <filter id="goo-effect">
            <feGaussianBlur in="SourceGraphic" stdDeviation="5" result="blur" />
            <feColorMatrix
              in="blur"
              type="matrix"
              values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 18 -15"
              result="goo"
            />
            <feComposite in="SourceGraphic" in2="goo" operator="atop" />
          </filter>
        </defs>
      </svg>

       <div className="button-content"></div>
       </div> */}
    </section>
  )
}
