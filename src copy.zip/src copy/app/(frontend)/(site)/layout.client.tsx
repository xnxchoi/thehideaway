'use client'

import { ReactNode, useEffect, useRef } from 'react'
import { useRPStore } from '@/providers/RP_Pro'
import { useVoyageur } from '@/stores/RP_Voyageur'
import { AnimatePresence, motion } from 'motion/react'
import { LoaderLottie } from '@/components/UX/Loader/LoaderLottie'
import { usePayloadSession } from '@/(CMS)/auth/rp_auth/client'
import { RP_Notification, RP_Patron } from '@/stores/RP_Ui'

import { ScrollIndicator } from '@/components/UX/ScrollIndicator'

export function Layout(l: { children: ReactNode }) {
  const slugRef = useRef<string>(''), pageTypeRef = useRef<string>('')
  const { children } = l
  const pageType = useVoyageur((l) => l.pageType)
  const pageSlug = useVoyageur((l) => l.slug)


  const canInteract = useRPStore((l) => l.canInteract)
  const isPreloader = useRPStore((l) => l.isPreloader)
  const setUser = useRPStore(l => l.setUser)
  const setNotifications = useRPStore(l => l.setNotifications)

  useEffect(() => {
    if (isPreloader) {
      document.body.dataset.enableInteraction = 'false'
      return
    }
    document.body.dataset.enableInteraction = canInteract ? 'true' : 'false'
  }, [isPreloader, canInteract])


  const toRef = useRef<ReturnType<typeof setTimeout>>(null!)
  useEffect(() => {
    toRef.current && clearTimeout(toRef.current), (toRef.current = setTimeout(() => {
      slugRef.current = pageSlug.length > 1 ? pageSlug.reduce((previousValue, currentValue) => previousValue + '/' + currentValue, '') : (pageSlug[0] ?? '')
    }, 500))
  }, [pageSlug])
  useEffect(() => {
    pageTypeRef.current = pageType
  }, [pageType])
  const { status, session, refetch, refresh } = usePayloadSession()
  useEffect(() => {
    console.log('session', session)
    if (status === 'authenticated' && session?.user) {
      let {
        name, id, slug, notification, ...rest
      } = session.user
      if(!name){
        name='patron'
      }
      let finUser: RP_Patron = {
        name, id, slug, ...rest,
      }
      if (notification?.docs) {
        console.log(`notifications for ${name}:`, notification.docs)
        const notifications = notification.docs.flatMap((doc) => {
          if (typeof doc !== 'object') return []
          if (!doc.id || !doc.title || !doc.createdAt || !doc.status || !doc.type) return []
          let toReturn: RP_Notification = {
            title: doc.title,
            content: doc.content,
            id: doc.id,
            createdAt: doc.createdAt,
            status: doc.status,
            type: doc.type,
          }
          return toReturn
        })
        setNotifications(notifications)
      }
      setUser(finUser)


    }
  }, [status])
  return (<div className="rp-container" data-themed={'background-color'}>
    <AnimatePresence mode="sync" initial={false} key="navigation">
      <LoaderLottie />
      <motion.div key={pageType + pageSlug[0]}> {children}</motion.div>
    </AnimatePresence>
    <ScrollIndicator/>
  </div>)
}
