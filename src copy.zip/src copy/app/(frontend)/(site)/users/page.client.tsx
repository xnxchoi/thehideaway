'use client'

import React, { useEffect } from 'react'
import { useHeaderTheme } from '@/providers/HeaderTheme'
import { Member } from '@/payload-types'
import { PageTransition } from '@/components/UX/Transition'
import { motion } from 'motion/react'

const PageClient = (props: {
  user: Partial<Member> & Pick<Member, 'name' | 'slug' | 'location'>
}) => {
  /* Force the header to be dark mode while we have an image behind it */
  const { user } = props
  const { setHeaderTheme } = useHeaderTheme()

  useEffect(() => {
    setHeaderTheme('dark')
  }, [setHeaderTheme])
  useEffect(() => {
    if (!user) return
    document.title = `@${user.slug}`
  }, [user])
  return (<motion.div>welcome,{user.name}!</motion.div>)
}

export default PageClient
