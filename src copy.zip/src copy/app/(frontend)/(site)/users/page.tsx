import configPromise from '@payload-config'
import type { Metadata } from 'next'
import { draftMode } from 'next/headers'
import { getPayload } from 'payload'
import React, { cache, use } from 'react'
import { PayloadRedirects } from 'src/(CMS)/components/PayloadRedirects'
import { generateMeta } from '@/utilities/generateMeta'
import PageClient from '@/app/(frontend)/(site)/users/page.client'
import { PageTransition } from '@/components/UX/Transition'
import { Member } from '@/payload-types'

export async function generateStaticParams() {
  const payload = await getPayload({ config: configPromise })
  const users = await payload.find({
    collection: 'members', limit: 1000, overrideAccess: true, select: {
      slug: true, email: true, name: true, location: true, id: true,
    },
  })

  const params = users.docs.map(({ id, email, slug }) => {
    return { user: '@' + slug }
  })
  return params
}

type Args = {
  params: Promise<{
    user?: string
  }>
}

export default async function Page({ params: paramsPromise }: Args) {
  const { user = '@' } = await paramsPromise

  const url = user.startsWith('@') ? `${user}`.split('@')[1] : user

  let page: (Partial<Member> & Pick<Member, 'slug' | 'name' | 'profilePicture' | 'location'>) | null

  page = await queryUserPage({ user: url })

  if (!page) {
    return <PayloadRedirects url={'/404'} />
  }
  return (<PageTransition type="users" slug={[`@${page.slug ?? user}`]}>
    <PageClient user={page} />
  </PageTransition>)
}

export async function generateMetadata({ params: paramsPromise }): Promise<Metadata> {
  const { user = '' } = await paramsPromise
  const page = await queryUserPage({
    user,
  })

  return generateMeta({ doc: page })
}

const queryUserPage = cache(async ({ user }: { user: string }) => {
  const { isEnabled: draft } = await draftMode()

  const payload = await getPayload({ config: configPromise })

  const result = await payload.find({
    collection: 'members', draft, limit: 1, pagination: false, overrideAccess: true, select: {
      description: true,
      roles: true,
      updatedAt: true,
      createdAt: true,
      email: true,
      slug: true,
      location: true,
      name: true,
      firstName: true,
      lastName: true,
      photo: true,
    }, where: {
      slug: {
        equals: user,
      },
    },
  })

  return result.docs?.[0] || null
})
