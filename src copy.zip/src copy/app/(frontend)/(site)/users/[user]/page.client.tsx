'use client'

import React, { useEffect } from 'react'
import { useHeaderTheme } from '@/providers/HeaderTheme'
import { useVoyageur } from '@/stores/RP_Voyageur'
import { PageTransition } from '@/components/UX/Transition'
import { Member } from '@/payload-types'

const PageClient = (props: { user: Member }) => {
  /* Force the header to be dark mode while we have an image behind it */
  const { user } = props
  const { setHeaderTheme } = useHeaderTheme()

  const setPage = useVoyageur((state) => state.setPage)
  useEffect(() => {
    setHeaderTheme('dark')
  }, [setHeaderTheme])
  return (<PageTransition type="users" slug={[`@${user.slug}`]}>
    <div>welcome,{user.name}!</div>
  </PageTransition>)
}

export default PageClient
