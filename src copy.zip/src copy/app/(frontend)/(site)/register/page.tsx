import PageClient from './page.client'
import { PageTransition } from '@/components/UX/Transition'
import { SplitSection } from '@/components/sections/split-section/SplitSection'

export default async function SignUpPage() {

  return (<PageTransition key={'pages_register'} type="pages" slug={['register']}>
    <PageClient />
    <SplitSection />
  </PageTransition>)
}
