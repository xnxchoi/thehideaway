'use client'

import React, { useEffect } from 'react'
import { useRPStore } from '@/providers/RP_Pro'
import { useTheme } from '@/providers/Theme'

const PageClient: React.FC = () => {
  /* Force the header to be dark mode while we have an image behind it */
const {setPageTheme}=useTheme()
  useEffect(() => {
    setPageTheme('dark')
  }, [])
  return <></>
}

export default PageClient
