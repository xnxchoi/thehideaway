import { AppSidebar } from "@/components/app-sidebar"
import {
  Breadcrumb,
  BreadcrumbItem,
  BreadcrumbLink,
  BreadcrumbList,
  BreadcrumbPage,
  BreadcrumbSeparator,
} from "@/components/ui/breadcrumb"
import { Separator } from "@/components/ui/separator"
import {
  SidebarInset,
  SidebarProvider,
  SidebarTrigger,
} from "@/components/ui/sidebar"
import { PageTransition } from '@/components/UX/Transition'

export default function Page() {
  return (
    <PageTransition slug={['account']} type={'pages'}>

    <SidebarProvider>
      <AppSidebar />
      <SidebarInset>
        <header className="flex h-[64px] shrink-0 items-center gap-3">
          <div className="flex items-center gap-3 px-6">
            <SidebarTrigger className="-ml-1.5" />
            <Separator
              orientation="vertical"
              className="mr-5 data-[orientation=vertical]:h-9"
            />
            <Breadcrumb>
              <BreadcrumbList>
                <BreadcrumbItem className="hidden md:block">
                  <BreadcrumbLink href="#">
                    Your Account
                  </BreadcrumbLink>
                </BreadcrumbItem>
                <BreadcrumbSeparator className="hidden md:block" />
                <BreadcrumbItem>
                  <BreadcrumbPage>Data Fetching</BreadcrumbPage>
                </BreadcrumbItem>
              </BreadcrumbList>
            </Breadcrumb>
          </div>
        </header>
        <div className="flex flex-1 flex-col gap-6 p-6 pt-0">
          <div className="grid auto-rows-min gap-6 md:grid-cols-3">
            <div className="bg-[oklch(var(--muted-faded-bg)/.5)] aspect-video rounded-[4px]" />
            <div className="bg-[oklch(var(--muted-faded-bg)/.5)] aspect-video rounded-[4px]" />
            <div className="bg-[oklch(var(--muted-faded-bg)/.5)] aspect-video rounded-[4px]" />
          </div>
          <div className="bg-muted/50 min-h-[100vh] flex-1 rounded-[4px] md:min-h-min" />
        </div>
      </SidebarInset>
    </SidebarProvider></PageTransition>
  )
}
