'use client'

import React, { ReactNode, useEffect } from 'react'

import { useHeaderTheme } from '@/providers/HeaderTheme'
import { PageTransition } from '@/components/UX/Transition'
import { motion } from 'motion/react'

const PageClient = (props: { children: ReactNode }) => {
  /* Force the header to be dark mode while we have an image behind it */
  const { setHeaderTheme } = useHeaderTheme()

  useEffect(() => {
    setHeaderTheme('dark')
  }, [setHeaderTheme])

  return (
    <PageTransition type="search" slug={['search']}>
      <motion.div className="py-24"> {props.children}</motion.div>
    </PageTransition>
  )
}

export default PageClient
