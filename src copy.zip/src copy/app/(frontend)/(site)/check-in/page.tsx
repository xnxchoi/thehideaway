import { PageTransition } from '@/components/UX/Transition'
import { getPayloadSession } from '@/(CMS)/auth/rp_auth'
import { PayloadRedirects } from 'src/(CMS)/components/PayloadRedirects'
import { Link } from '@/components/UX/Link'
import { LoginForm } from '@/components/login-form'
import { Logo } from '@/components/UX/Logo'
import { GradientModule } from '@/components/UX/Gradient/Gradient'

export default async function CheckInPage() {
  const user = await getPayloadSession()
  if (user) {
    return <PayloadRedirects url={'/'} />
  }
  return (
    <PageTransition type={'pages'} slug={['check-in']}>
      <div className="relative flex min-h-svh flex-col items-center justify-center gap-10 p-9 md:p-16">
        <div
          className={
            'absolute inset-[35px] z-[120] bg-[oklch(var(--opaque-bg)/.54)] flex rounded-[50px] backdrop-blur-[54px]'
          }
        ></div>
        <div className="flex w-full max-w-[384px] flex-col gap-9 z-[120]">
          <Link href="/" className="flex items-center gap-3.5 self-center font-medium">
            <div className="bg-primary flex size-9 items-center justify-center rounded-lg">
              <Logo />
            </div>
            The Hideaway.
          </Link>
          <LoginForm />
        </div>
        <GradientModule />
      </div>
    </PageTransition>
  )
}
