import configPromise from '@payload-config'
import type { Metadata } from 'next'
import { draftMode } from 'next/headers'
import { getPayload } from 'payload'
import React, { cache } from 'react'

import { MoreLikeThis } from '@/(CMS)/blocks/RelatedPosts/Component'
import { PayloadRedirects } from 'src/(CMS)/components/PayloadRedirects'
import RichText from '@/(CMS)/fields/RichText'
import { generateMeta } from '@/utilities/generateMeta'

import PageClient from './page.client'
import { ArtHero } from '@/(CMS)/blocks/heros/ArtHero'
import { PageTransition } from '@/components/UX/Transition'
import { getPayloadSession } from '@/(CMS)/auth/rp_auth'
import { rolesToAuthority } from '@/(CMS)/plugins/locker/fields/authority/utils'

export async function generateStaticParams() {
  const payload = await getPayload({ config: configPromise })
  const posts = await payload.find({
    collection: 'posts', draft: false, limit: 1000, overrideAccess: false, select: {
      slug: true,
    },
  })

  const params = posts.docs.map(({ slug }) => {
    return { slug }
  })

  return params
}

type Args = {
  params: Promise<{
    slug?: string
  }>
}

export default async function Post({ params: paramsPromise }: Args) {
  const { slug = '' } = await paramsPromise
  const url = `/posts/${slug}`
  const post = await queryPostBySlug({ slug })

  if (!post) return <PayloadRedirects url={url} />

  return (<PageTransition type="posts" slug={[slug]}>
    <PageClient>
      {/* Allows redirects for valid pages too */}
      <PayloadRedirects disableNotFound url={url} />
      <ArtHero post={post} />
      <div className="py-[32px] px-0 w-full max-w-(--maxContainerWidth) ml-auto mr-auto mt-[28px] mb-[28px]">
        <div className="rp-content [&>*]:col-[main] [&>aside]:col-4">
          <RichText data={post.content} enableGutter={false} />
          <aside className="lg:mx-auto lg:my-0 lg:w-full lg:max-w-[350px] lg:col-4 lg:row-[2/span_20] z-[2]">
            <div className="side-card">
              <div className="story-side dzk">
                <div className="side-head">More Like This</div>
                {post.relatedPosts && post.relatedPosts.length > 0 && (
                  <MoreLikeThis docs={post.relatedPosts.filter((post) => typeof post === 'object')} />)}
              </div>
            </div>
          </aside>
        </div>
      </div>
      <div id={`${post.id}`} className="next-loader absolute inset-0" style={{ height: '15vh' }} />
      <div className="f-divider story-footer" />
    </PageClient>
  </PageTransition>)
}

export async function generateMetadata({ params: paramsPromise }: Args): Promise<Metadata> {
  const { slug = '' } = await paramsPromise
  const post = await queryPostBySlug({ slug })

  return generateMeta({ doc: post })
}

const queryPostBySlug = cache(async ({ slug }: { slug: string }) => {
  const { isEnabled: draft } = await draftMode()

  const payload = await getPayload({ config: configPromise })
  const user = await getPayloadSession({ userCollectionSlug: 'members' })
  let se = user?.user ?? null
  const result = await payload.find({
    collection: 'posts', draft, limit: 1, overrideAccess: true, pagination: false, where: {
      slug: {
        equals: slug,
      },
    }, select: {
      title: true,
      subtitle: true,
      content: true,
      slug: true,
      populatedAuthor: true,
      category: true,
      allowList: true,
      authority: true,
      author: true,
      publishedAt: true,
      locked: true,
      updatedAt: true,
      createdAt: true,
      relatedPosts: true,
      heroImage: true,
    },

  })
  if (result.docs && result.docs.length > 0) {
    const post = result.docs[0]
    if(post.author){
      let id=post.author.value
      if(typeof id!=='string'){
        id=id.id
      }
      const pp=await payload.findByID({
        collection:post.author.relationTo,
        id:id,select: {
          name:true,
          slug:true,
        }
      })
      post.populatedAuthor=[pp]
    }
    if (post.locked) {
      let auth = post.authority ?? 1
      if (se) {
        if (post.allowList?.some((r) => r.value === se.id)) {
          return post
        }
        if (se.roles) {
          if (rolesToAuthority(se.roles) >= auth) {
            return post
          }
        }
      }
      post.content = {
        root: {
          type: 'paragraph', children: [], direction: 'ltr', format: 'start', indent: 0, version: 0,
        },
      }
    }
    return post
  }
  return result.docs?.[0] || null
})
