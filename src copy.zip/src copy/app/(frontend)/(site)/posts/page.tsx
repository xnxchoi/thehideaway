import configPromise from '@payload-config'
import type { Metadata } from 'next/types'
import { getPayload } from 'payload'
import React from 'react'

import { CollectionArchive } from 'src/(CMS)/components/CollectionArchive'
import { PageRange } from 'src/(CMS)/components/PageRange'
import { Pagination } from 'src/(CMS)/components/Pagination'

import PageClient from './page.client'
import { orderedSlugs } from '@/hooks/useGetPageType'
import { PageTransition } from '@/components/UX/Transition'

export const dynamic = 'force-static'
export const revalidate = 600

export default async function Page() {
  const payload = await getPayload({ config: configPromise })

  const posts = await payload.find({
    collection: 'posts', depth: 1, limit: 12, overrideAccess: true, select: {
      title: true, slug: true, categories: true, meta: true,
    },where:{
      _status:{
        equals:'published'
      }
    }
  })

  return (<PageTransition key={`posts_${posts.totalPages}`} type="posts" slug={[posts.docs[0]?.slug ?? '']}>
      <PageClient>
        <div className="container mb-16">
          <div className="prose max-w-none dark:prose-invert">
            <h1>Posts</h1>
          </div>
        </div>
        <div className="container mb-8">
          <PageRange collection="posts" currentPage={posts.page} limit={12} totalDocs={posts.totalDocs} />
        </div>
        <CollectionArchive posts={posts.docs} />
        <div className="container">
          {posts.totalPages > 1 && posts.page && (<Pagination page={posts.page} totalPages={posts.totalPages} />)}
        </div>
      </PageClient></PageTransition>)
}

export function generateMetadata(): Metadata {
  return {
    title: `The Hideaway Posts`,
  }
}
