import configPromise from '@payload-config'
import { notFound } from 'next/navigation'
import type { Metadata } from 'next/types'
import { getPayload } from 'payload'
import React from 'react'

import { CollectionArchive } from 'src/(CMS)/components/CollectionArchive'
import { PageRange } from 'src/(CMS)/components/PageRange'
import { Pagination } from 'src/(CMS)/components/Pagination'

import PageClient from './page.client'
import { PageTransition } from '@/components/UX/Transition'

export const revalidate = 600

type Args = {
  params: Promise<{
    pageNumber: string
  }>
}

export default async function Page({ params: paramsPromise }: Args) {
  const { pageNumber } = await paramsPromise
  const payload = await getPayload({ config: configPromise })

  const sanitizedPageNumber = Number(pageNumber)

  if (!Number.isInteger(sanitizedPageNumber)) notFound()

  const posts = await payload.find({
    collection: 'posts', depth: 1, limit: 12, page: sanitizedPageNumber, overrideAccess: false,
  })

  return (<PageTransition type="posts" slug={[sanitizedPageNumber.toString()]}>
      <PageClient>
        <div className="container mb-16">
          <div className="prose max-w-none dark:prose-invert">
            <h1>Posts</h1>
          </div>
        </div>
        <div className="container mb-8">
          <PageRange collection="posts" currentPage={posts.page} limit={12} totalDocs={posts.totalDocs} />
        </div>
        <CollectionArchive posts={posts.docs} />
        <div className="container">
          {posts?.page && posts?.totalPages > 1 && (<Pagination page={posts.page} totalPages={posts.totalPages} />)}
        </div>
      </PageClient>
    </PageTransition>)
}

export async function generateMetadata({ params: paramsPromise }: Args): Promise<Metadata> {
  const { pageNumber } = await paramsPromise
  return {
    title: `The Hideaway Posts Page ${pageNumber || ''}`,
  }
}

export async function generateStaticParams() {
  const payload = await getPayload({ config: configPromise })
  const { totalDocs } = await payload.count({
    collection: 'posts', overrideAccess: false,
  })

  const totalPages = Math.ceil(totalDocs / 10)

  const pages: { pageNumber: string }[] = []

  for (let i = 1; i <= totalPages; i++) {
    pages.push({ pageNumber: String(i) })
  }

  return pages
}
