'use client'

import React, { ReactNode, useEffect } from 'react'

import { useHeaderTheme } from '@/providers/HeaderTheme'
import { orderedSlugs } from '@/hooks/useGetPageType'
import { PageTransition } from '@/components/UX/Transition'

const PageClient = (props: { children: ReactNode }) => {
  /* Force the header to be dark mode while we have an image behind it */
  const { setHeaderTheme } = useHeaderTheme()
  const slug = orderedSlugs()
  useEffect(() => {
    setHeaderTheme('dark')
  }, [setHeaderTheme])
  return (

    <div className="py-24"> {props.children}</div>)
}

export default PageClient
