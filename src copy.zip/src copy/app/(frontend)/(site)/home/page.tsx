import { HomeArticleLayout } from '@/components/layouts/HomeArticleLayout'
import { getPayload, Where } from 'payload'
import configPromise from '@payload-config'
import { getPayloadSession } from '@/(CMS)/auth/rp_auth'
import { rolesToAuthority } from '@/(CMS)/plugins/locker/fields/authority/utils'

export default async function HomePage() {
  const payload = await getPayload({ config: configPromise })
  const user = await getPayloadSession({ userCollectionSlug: 'members' })
  const query = {
    and: [{
      _status: {
        equals: 'published',
      },
    }, {
      or: [{
        locked: {
          not_equals: true,
        },
      }, {
        and: [{
          locked: {
            equals: true,
          },
        }],
      }],
    }],
  }
  const authorit = (user?.user && user?.user?.roles) && rolesToAuthority(user.user.roles) || 0
  const posts = await payload.find({
    collection: 'posts', sort: '-publishedAt', limit: 8, where: {
        _status: {
          equals: 'published',
        },
    }, select: {
      title: true,
      publishedAt: true,
      author: true,
      populatedAuthor: true,
      heroImage: true,
      slug: true,
      category: true,
    },
    overrideAccess:true
  })

  return (<div className="pb-10 pt-[23px] lg:pt-[100px]">
    <div className="my-0 mx-2.5 max-w-[600px] sm:mx-auto xl:max-w-[88vw]">
      <HomeArticleLayout posts={posts.docs} />
    </div>
  </div>)
}