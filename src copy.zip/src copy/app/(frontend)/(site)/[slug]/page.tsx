import configPromise from '@payload-config'
import type { Metadata } from 'next'
import { draftMode } from 'next/headers'
import { getPayload } from 'payload'
import React, { cache } from 'react'

import { RenderBlocks } from '@/(CMS)/blocks/RenderBlocks'
import { PayloadRedirects } from 'src/(CMS)/components/PayloadRedirects'
import { RenderHero } from '@/(CMS)/blocks/heros/RenderHero'
import type { Page as PageType } from '@/payload-types'
import { generateMeta } from '@/utilities/generateMeta'

import PageClient from './page.client'
import { RP_Footer } from '@/(CMS)/collections/Footer/Component.client'
import { PageTransition } from '@/components/UX/Transition'

export async function generateStaticParams() {
  const payload = await getPayload({ config: configPromise })
  const pages = await payload.find({
    collection: 'pages', draft: false, limit: 1000, overrideAccess: false, select: {
      slug: true,
    },
  })

  const params = pages.docs?.filter((doc) => {
    return doc.slug !== 'home'
  }).map(({ slug }) => {
    return { slug }
  })

  return params
}

type Args = {
  params: Promise<{
    slug?: string
  }>
}

export default async function Page({ params: paramsPromise }: Args) {
  const { slug = 'home' } = await paramsPromise
  const url = `/${slug}`
  if (slug.startsWith('@')) {
    return <PayloadRedirects url={`/users/${slug}`} />
  }

  let page: PageType | null

  page = await queryPageBySlug({
    slug,
  })

  if (!page) {
    return <PayloadRedirects url={url} />
  }

  const { hero, layout, pageLayout } = page

  return (<PageTransition type="pages" slug={[slug]}>
      {/* Allows redirects for valid pages too */}
      <PayloadRedirects disableNotFound url={url} />
      <PageClient>
        <RenderHero {...hero} />
        <RenderBlocks blocks={layout} />
        {pageLayout?.disableFooter !== true && pageLayout?.footerType && (
          <RP_Footer footerType={pageLayout.footerType} />)}
      </PageClient>
    </PageTransition>)
}

export async function generateMetadata({ params: paramsPromise }): Promise<Metadata> {
  const { slug = 'home' } = await paramsPromise
  const page = await queryPageBySlug({
    slug,
  })

  return generateMeta({ doc: page })
}

const queryPageBySlug = cache(async ({ slug }: { slug: string }) => {
  const { isEnabled: draft } = await draftMode()

  const payload = await getPayload({ config: configPromise })

  const result = await payload.find({
    collection: 'pages', draft, limit: 1, pagination: false, overrideAccess: draft, where: {
      slug: {
        equals: slug,
      },
    },
  })

  return result.docs?.[0] || null
})
