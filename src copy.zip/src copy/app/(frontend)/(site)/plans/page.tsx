import PageClient from './page.client'
import { PageTransition } from '@/components/UX/Transition'
import { FounderCard, PriceCard } from '@/components/sections/PriceCard/PriceCard'
import { Justification } from '@/components/UX/Justification/Justification'
import { RP_POLAROID } from '@/components/sections/Polaroid'

export default async function PlansPage() {

  return (<PageTransition type="pages" slug={['plans']}>
    <PageClient />
    <div className="px-[1.25em] pt-[10em] mx-auto relative w-full sm:pt-[15em] sm:px-[2em]">
      <div className="mb-[4.5em] text-center">
        <div className="w-full max-w-[44em] mx-auto">
          <div className="flex flex-col justify-start items-center gap-[1.25em]">
            <div>
              <div className="mb-[.75em]">
                <div className="uppercase font-normal leading-[1]" style={{ fontSize: '.75em' }}>
                  <div className="pb-[.1em] mb-[-.1em] overflow-hidden">
                    <div className="single-line">Membership</div>
                  </div>
                </div>
              </div>
              <h1 className="leading-[1] my-0">
                <div className="pb-[.1em] mb-[-.1em] overflow-hidden">Capture the spark.</div>
              </h1>
            </div>
            <div className="items-center w-full max-w-[35em]">
              <p aria-hidden="true" data-split="lines" data-reveal="load"
                 className="font-medium leading-[1.4] opacity-70" style={{ fontSize: '1em' }}>
                다른 크리에이터들과 인사이트와 아이디어를 나누세요. </p>
            </div>
          </div>
        </div>
      </div>
      <div className="mx-auto max-w-[72em] lg:max-w-[75vw] w-full">
        <div className="flex relative" style={{ flexFlow: 'wrap', gridRowGap: '3em' }}>
          <PriceCard type="standard" />
          <PriceCard type="pro" />
        </div>
        <div className="pt-[1.6rem] px-[.8rem]" data-theme="dark">
          <FounderCard />
        </div>
        <div className="price-bottom">
          <Justification posterEnabled={false} controls={false} loop={true} playsInline={true} muted={false}
                         autoPlay={true} restartOnEnter={true} objectFit="cover" backgroundColor="" volume={25}
                         startTime={0} />
        </div>
      </div>
    </div>
    <RP_POLAROID />
  </PageTransition>)
}
