'use client'
import './__plans.scss'
import React, { useEffect } from 'react'
import { useRPStore } from '@/providers/RP_Pro'

const PageClient: React.FC = () => {
  /* Force the header to be dark mode while we have an image behind it */

  return <></>
}

export default PageClient
