'use client'

import React, { ReactNode, Suspense, useEffect } from 'react'
import { useVoyageur } from '@/stores/RP_Voyageur'
import { useRPStore } from '@/providers/RP_Pro'
import { PageTransition } from '@/components/UX/Transition'
import { useTheme } from '@/providers/Theme'

const PageClient = (props: { children: ReactNode }) => {
  const { children } = props
  /* Force the header to be dark mode while we have an image behind it */
  const setPageTheme=useTheme(r=>r.setPageTheme)
  useEffect(() => {
    setPageTheme('dark',true)
  }, [])
  return (<Suspense>
    {children}
  </Suspense>)
}

export default PageClient
