import configPromise from '@payload-config'
import { Credits } from 'src/components/sections/Credits'
import PageClient from '@/app/(frontend)/(site)/the-team/page.client'
import { getPayload } from 'payload'
import { PageTransition } from '@/components/UX/Transition'

export default async function TheTeamPage() {
  const payload = await getPayload({ config: configPromise })
  const credits = await payload.find({
    collection: 'members', pagination: false, limit: 100, select: {
      name: true, slug: true, photo: true, occupation: true, roles: true,
    }, where: {
      roles: {
        contains: 'author',
      },
    },
  })
  return (<PageTransition type="pages" slug={['the-team']}>
    <PageClient>
      <Credits {...credits}></Credits>
    </PageClient>
  </PageTransition>)
}
