'use client'
import React, { Fragment } from 'react'

import config from '@payload-config'
import { Link } from 'src/components/UX/Link'
import { PageTransition } from '@/components/UX/Transition'

export default async function Account() {


  return (<Fragment>
    <PageTransition type="pages" slug={['account']}>
      <div className={'container'}>
        <h1>Account</h1>
        <p>Hello, {user.name}</p>
      </div>
    </PageTransition>
  </Fragment>)
}
