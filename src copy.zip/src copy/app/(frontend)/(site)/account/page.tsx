import { redirect } from 'next/navigation'
import React, { Fragment } from 'react'
import { PageTransition } from '@/components/UX/Transition'
import { getPayloadSession } from '@/(CMS)/auth/rp_auth'

export default async function Account() {
  const isAdmin=await getPayloadSession({userCollectionSlug: 'admins'})
  if(isAdmin!==null && isAdmin.user&&isAdmin.user?.id){
    redirect('/vault/account')
  }

 const session=await getPayloadSession({userCollectionSlug: 'members'})
  if (!session||!session?.user||!session?.user?.id) {
    redirect(`/check-in?error=${encodeURIComponent('You must be logged in to access your account.')}&redirect=/account`)
  }
const {user}=session
  return (<Fragment>
    <PageTransition type="pages" slug={['account']}>
      <div className={'container'}>
        <h1>Account</h1>
        <p>Hello, {user.name}</p>

      </div>
    </PageTransition>
  </Fragment>)
}
