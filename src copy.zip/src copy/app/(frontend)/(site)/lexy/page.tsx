import './index.scss'
import { LexicalServe } from '@/(CMS)/Lexical/lexicalServe'
export default async function Page() {
  return (
    <section className={'fffff'} >
      <LexicalServe/>
    </section>
  )
}
