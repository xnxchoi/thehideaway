import PageTemplate, { generateMetadata } from '@/app/(frontend)/(site)/[slug]/page'

export default PageTemplate

export { generateMetadata }
