import '../../styles/globals.css'
import './estate.scss'
import '@/styles/hideaway.scss'
import '@/styles/reading.scss'
import 'lenis/dist/lenis.css'

import { GeistMono } from 'geist/font/mono'
import { GeistSans } from 'geist/font/sans'
import type { Metadata } from 'next'
import { draftMode } from 'next/headers'
import { cn } from '@/lib/utils'
import { LivePreviewListener } from 'src/(CMS)/components/LivePreviewListener'
import { Header } from '@components/Header/Component'
import { Providers } from '@/providers'
import { InitTheme } from '@/providers/Theme/InitTheme'
import { getServerSideURL } from '@/utilities/getURL'
import { mergeOpenGraph } from '@/utilities/mergeOpenGraph'
import { ReactNode } from 'react'
import { TabMessenger } from '@/utilities/visibilityChange'
import { RP_Menu } from '@/components/UX/Menu'
import RP_Cursor from '@/components/UX/Cursor'
import { MenuMediaPreview } from '@/components/UX/MediaPreview/MenuMediaPreview'
import { PageTransitionPortal } from '@/components/UX/Transition'
import { ContentMask } from '@/components/UX/ContentMask'
import { EscapeInAppBrowser } from '@/components/UX/escapeInAppBrowser'
import { ReactLenis } from 'lenis/react'
import { Toaster } from '@/components/ui/sonner'
import { PayloadSessionProvider } from '@/(CMS)/auth/rp_auth/client'
import { getPayloadSession } from '@/(CMS)/auth/rp_auth'
import { getPayload } from 'payload'
import configPromise from '@payload-config'

export default async function RootLayout({ children }: { children: ReactNode }) {
  const { isEnabled } = await draftMode()
  const serverurl = getServerSideURL()
  const payload = await getPayload({ config: configPromise })

  // const isAdmins = await getPayloadSession({
  //   userCollectionSlug: 'admins',
  // })
  // if(isAdmins?.user){
  //   payload.logger.info({ message:'Admins session detected',user:isAdmins.user})
  //     let res=await fetch(`${serverurl}/api/admins/logout`, {
  //       method: 'POST', credentials: 'include', headers: {
  //         'Content-Type': 'application/json',
  //       },
  //     }).catch(e => payload.logger.error({message:'Admins session logout failed',error:e}))
  //   if(res){
  //     payload.logger.info({ message:'Admins session logged out',response:res})
  //   }
  // }
  return (<html className={cn(GeistSans.variable, GeistMono.variable)} lang="en" suppressHydrationWarning>
    <head>
      <InitTheme />
      <link href="/favicon.ico" rel="icon" sizes="32x32" />
      <link href="/favicon.svg" rel="icon" type="image/svg+xml" />
    </head>
    <body data-themed={'color, background-color'}>
      <Providers>
        <ReactLenis root={true}>
          <Toaster />
          <LivePreviewListener />
          <Header />
          <PayloadSessionProvider session={await getPayloadSession({ userCollectionSlug: 'members' })}>
            <EscapeInAppBrowser targetURL={process.env.NEXT_PUBLIC_SERVER_URL} />
            <TabMessenger />
            <RP_Menu />
            <RP_Cursor />
            <MenuMediaPreview />
            <ContentMask>{
            <>
            {children}

              </>
              }</ContentMask>
            <PageTransitionPortal />
          </PayloadSessionProvider>
          <div className="c-scroll-fx">
            <div className="html-embed-2 w-embed"></div>
            <div data-themed={'background-color'} className="bottom-fx soft"></div>
            <div data-themed={'background-color'} className="bottom-fx"></div>
            <div data-themed={'background-color'} className="bottom-fx-top"></div>
          </div>
        </ReactLenis>
      </Providers>
    </body>
  </html>)
}

export const metadata: Metadata = {
  metadataBase: new URL(getServerSideURL()), openGraph: mergeOpenGraph(), twitter: {
    card: 'summary_large_image', creator: '@',
  },
}
