import { handlers } from '@/auth.members' // Referring to the auth.ts we just created
export const { GET, POST } = handlers
