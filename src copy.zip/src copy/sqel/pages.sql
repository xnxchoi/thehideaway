INSERT INTO public.pages (id, title, hero_type, hero_rich_text, hero_media_id, page_layout_footer_type,
                          page_layout_visually_show_only_first_section, page_layout_disable_footer,
                          page_layout_video_loop_desktop_id, page_layout_video_loop_mobile_id, published_at, slug,
                          slug_lock, updated_at, created_at, _status, locked, authority)
VALUES (1, 'Reception', 'lowImpact',
        '{"root": {"type": "root", "format": "", "indent": 0, "version": 1, "children": [{"type": "paragraph", "format": "", "indent": 0, "version": 1, "children": [], "direction": null, "textStyle": "", "textFormat": 0}], "direction": null}}',
        null, 'standard', false, false, null, null, '2025-04-05 16:14:20.505 +00:00', 'home', false,
        '2025-04-05 16:21:57.942 +00:00', '2025-04-05 16:13:44.353 +00:00', 'published', false, 0);
INSERT INTO public.pages (id, title, hero_type, hero_rich_text, hero_media_id, page_layout_footer_type,
                          page_layout_visually_show_only_first_section, page_layout_disable_footer,
                          page_layout_video_loop_desktop_id, page_layout_video_loop_mobile_id, published_at, slug,
                          slug_lock, updated_at, created_at, _status, locked, authority)
VALUES (2, 'The Team', 'none', null, null, 'standard', false, false, null, null, '2025-04-05 16:24:20.254 +00:00',
        'the-team', true, '2025-04-05 16:24:20.256 +00:00', '2025-04-05 16:24:00.421 +00:00', 'published', false, 0);
INSERT INTO public.pages (id, title, hero_type, hero_rich_text, hero_media_id, page_layout_footer_type,
                          page_layout_visually_show_only_first_section, page_layout_disable_footer,
                          page_layout_video_loop_desktop_id, page_layout_video_loop_mobile_id, published_at, slug,
                          slug_lock, updated_at, created_at, _status, locked, authority)
VALUES (3, 'LOSTINSEOUL', 'none', null, null, 'standard', false, false, null, null, '2025-04-05 16:24:43.168 +00:00',
        'lostinseoul', true, '2025-04-05 16:24:43.170 +00:00', '2025-04-05 16:24:28.938 +00:00', 'published', false, 0);
INSERT INTO public.pages (id, title, hero_type, hero_rich_text, hero_media_id, page_layout_footer_type,
                          page_layout_visually_show_only_first_section, page_layout_disable_footer,
                          page_layout_video_loop_desktop_id, page_layout_video_loop_mobile_id, published_at, slug,
                          slug_lock, updated_at, created_at, _status, locked, authority)
VALUES (4, 'Plans', 'none', null, null, 'standard', false, false, null, null, '2025-04-05 16:30:14.168 +00:00', 'plans',
        true, '2025-04-05 16:30:14.169 +00:00', '2025-04-05 16:30:03.500 +00:00', 'published', false, 0);
INSERT INTO public.pages (id, title, hero_type, hero_rich_text, hero_media_id, page_layout_footer_type,
                          page_layout_visually_show_only_first_section, page_layout_disable_footer,
                          page_layout_video_loop_desktop_id, page_layout_video_loop_mobile_id, published_at, slug,
                          slug_lock, updated_at, created_at, _status, locked, authority)
VALUES (5, 'Register', 'lowImpact', null, null, 'standard', false, false, null, null, '2025-04-05 16:30:32.069 +00:00',
        'register', true, '2025-04-05 16:30:32.071 +00:00', '2025-04-05 16:30:18.360 +00:00', 'published', false, 0);
