import payloadConfig from '@payload-config'
import NextAuth from 'next-auth'
import { authAdminsConfig } from './auth.admins.config'
import { withHideaway } from '@/(CMS)/auth/rp_auth/withHideaway'

export const { handlers, signIn, signOut, auth } = NextAuth(withHideaway(authAdminsConfig, {
  userCollectionSlug: 'admins', payloadConfig,
}))