// storage-adapter-import-placeholder
import path from 'path'
import { postgresAdapter } from '@payloadcms/db-postgres'
import { buildConfig } from 'payload'
import sharp from 'sharp'
import { fileURLToPath } from 'url'

import { defaultLexical } from '@/(CMS)/Lexical/defaultLexical'
import { Footer } from '@/(CMS)/collections/Footer/config'
import { Header } from '@/(CMS)/collections/Header'
import { plugins } from '@/(CMS)/plugins'
import { getServerSideURL } from './utilities/getURL'
import { authjsPlugin } from '@/(CMS)/auth/rp_auth/payload/plugin'
import { authAdminsConfig } from '@/auth.admins.config'
import { collections } from '@/(CMS)/collections'
import { authMembersConfig } from '@/auth.members.config'
import { Members } from '@/(CMS)/collections/Members'
import { Admins } from '@/(CMS)/collections/Admins'
import { lockerPlugin } from '@/(CMS)/plugins/locker/plugin'

const filename = fileURLToPath(import.meta.url)
const dirname = path.dirname(filename)

export default buildConfig({
  localization: { defaultLocale: 'ko', locales: [ 'ko','en'], fallback: true },
  i18n:{},
  admin: {
    components: {
      // The `BeforeLogin` component renders a message that you see while logging into your admin panel.
      // Feel free to delete this at any time. Simply remove the line below and the import `BeforeLogin` statement on line 15.
      beforeLogin: ['@components/BeforeLogin'], // The `BeforeDashboard` component renders the 'welcome' block that you see after logging into your admin panel.
      // Feel free to delete this at any time. Simply remove the line below and the import `BeforeDashboard` statement on line 15.
      graphics: {
        Logo: '@/graphics/Logo/index.tsx#Logo',
        Icon: '@/graphics/Icon/index.tsx#Icon',
      },
    },
  user:'admins',
    importMap: {
      baseDir: path.resolve(dirname),
    },
    livePreview: {
      collections: ['posts', 'pages'],
      breakpoints: [
        {
          label: 'Mobile',
          name: 'mobile',
          width: 375,
          height: 667,
        },
        {
          label: 'Tablet',
          name: 'tablet',
          width: 768,
          height: 1024,
        },
        {
          label: 'Desktop',
          name: 'desktop',
          width: 1440,
          height: 900,
        },
      ],
    },
    meta: {
      title: 'PRIVATE AREA',
      titleSuffix: '- The Hideaway',
      icons: [
        {
          type: 'image/png',
          rel: 'icon',
          url: '/assets/favicon.svg',
        },
      ],
    },
  }, // This config helps us configure global or default features that the other editors can inherit
  editor: defaultLexical, // db: mongooseAdapter({
  //   url: process.env.DATABASE_URI,
  // }),
  db: postgresAdapter({
    pool: {
      connectionString: process.env.DATABASE_URI,
    },
  }),
  collections: [Members, Admins, ...collections],
  cors: [getServerSideURL()].filter(Boolean),
  globals: [Header, Footer],
  plugins: [
    ...plugins,
    authjsPlugin({
      enabled: true,
      userCollectionSlug: 'admins',
      authjsConfig: authAdminsConfig,
      enableLocalStrategy: true,
    }),
    authjsPlugin({
      enabled: true,
      userCollectionSlug: 'members',
      authjsConfig: authMembersConfig,
    }),
    lockerPlugin({
      enabled: true,
      userCollections: ['members', 'admins'],
      targetCollections: ['pages', 'surf', 'posts', 'media'],
    }),
  ],
  bin:[ {
    scriptPath: path.resolve(dirname, 'seed.ts'),
    key: 'seed',
  },],
  secret: process.env.PAYLOAD_SECRET,
  sharp,

  typescript: {
    outputFile: path.resolve(dirname, 'payload-types.ts'),
  },
  routes: {
    admin: '/vault',
  },
})
