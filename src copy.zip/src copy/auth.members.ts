import payloadConfig from '@payload-config'
import NextAuth from 'next-auth'
import { withPayload } from '@/(CMS)/auth/rp_auth'
import { authMembersConfig } from '@/auth.members.config'

export const { handlers, signIn, signOut, auth } = NextAuth({
  ...withPayload(authMembersConfig, {
    userCollectionSlug: 'members', payloadConfig,
  }), debug: true,
})
