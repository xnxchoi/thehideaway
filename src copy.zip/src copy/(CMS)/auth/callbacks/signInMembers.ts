import { PayloadAuthJSEventMap } from '@/(CMS)/auth/rp_auth/authjs/withPayload'

export const signInMembers:PayloadAuthJSEventMap['signIn']=async (params)=>{
  const {adapter,account,payload,profile,user}=params

}