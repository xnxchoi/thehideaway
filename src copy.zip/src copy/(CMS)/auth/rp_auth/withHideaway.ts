import type { NextAuthConfig } from 'next-auth'
import type { Adapter } from 'next-auth/adapters'
import type { Payload } from 'payload'
import { withPayload, WithPayloadOptions } from '@/(CMS)/auth/rp_auth/authjs/withPayload'

type CustomEvent<T extends keyof NonNullable<NextAuthConfig['events']>> = (message: {
  /**
   * The Auth.js database adapter
   */
  adapter: Adapter; /**
   * The payload instance
   */
  payload?: Payload;
} & Parameters<NonNullable<NonNullable<NextAuthConfig['events']>[T]>>[0]) => void | PromiseLike<void>;



/**
 * Wraps the Auth.js configuration
 *
 * @example
 * import { config } from "./auth.config";
 *
 * export const { handlers, signIn, signOut, auth } = NextAuth(
 *   withPayload(config, { payloadConfig }),
 * );
 */
export function withHideaway(authjsConfig: NextAuthConfig, options: WithPayloadOptions): NextAuthConfig {

  const wrappedJS = withPayload(authjsConfig, options)

  const { signIn, ...callbacks } = wrappedJS.callbacks ?? {}

  async function checkIfUserIsCleared(params: Parameters<NonNullable<typeof signIn>>[0]): Promise<boolean> {
    // Call the original signIn callback
    if ((await signIn?.(params)) === false) {
      return false
    }
    const userObject = { ...params.user, isAnExistingUser: false }
    if (params.user.email || params.user.id) {
      if (params.user.id) {
        try {
          const currentUser = await wrappedJS.adapter?.getUser?.(params.user.id)
          if (currentUser) {
            userObject.isAnExistingUser = true
          }
        } catch {

        }
      } else if (params.user.email) {
        try {

          const currentUser = await wrappedJS.adapter?.getUserByEmail?.(params.user.email)
          if (currentUser) {
            userObject.isAnExistingUser = true
          }
        } catch {

        }
      }
      if (userObject.isAnExistingUser) {
        return true
      }
    }
    return false
  }

  wrappedJS.callbacks = {
    ...callbacks, signIn: signIn?.name !== 'checkIfUserIsCleared' ? checkIfUserIsCleared : signIn,
  }
  return wrappedJS
}
