import type { Access, CollectionConfig } from 'payload'
import { Admin, Member } from '@/payload-types'

const myselfAccess: Access<Member> = ({ req: { user } }) => {
  // User is required
  if (!user) {
    return false
  }
  if (user?.collection === 'admins') return true
  // Only allow to read, update and delete current user
  return {
    id: {
      equals: user?.id,
    },
  }
}, adminMyselfAccess: Access<Admin> = ({ req: { user } }) => {
  if (user?.collection === 'admins') {
    return {
      id: {
        equals: user?.id,
      },
    }
  }
  return false
}, editorMyselfAccess: Access<Member> = ({ req: { user } }) => {
  if (user?.collection === 'admins') {
    return true
  }
  if (user?.roles?.some(v=>v==='editor')) return true
  return {
    id: {
      equals: user?.id,
    },
  }
}

/**
 * Override the default access control.
 * Only allow users to read, update and delete their own user
 */
export const memberDefaultAccess: CollectionConfig['access'] = {
  read: editorMyselfAccess, readVersions: () => false, create: ()=>true, update: myselfAccess, delete: myselfAccess, unlock: () => false,
}
/**
 * Override the default access control.
 * Only allow users to read, update and delete their own user
 */
export const adminDefaultAccess: CollectionConfig['access'] = {
  read: adminMyselfAccess,
  readVersions: () => false,
  create: () => false,
  update: adminMyselfAccess,
  delete: adminMyselfAccess,
  unlock: () => false,
}
