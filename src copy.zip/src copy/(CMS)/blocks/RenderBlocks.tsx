import React, { Fragment } from 'react'

import { ArchiveBlock } from '@/(CMS)/blocks/ArchiveBlock/Component'
import { CallToActionBlock } from '@/(CMS)/blocks/CallToAction/Component'
import { ContentBlock } from '@/(CMS)/blocks/Content/Component'
import { FormBlock } from '@/(CMS)/blocks/Form/Component'
import { MediaBlock } from '@/(CMS)/blocks/MediaBlock/Component'
import type { Page } from '@/payload-types'
import { FOTDBlock } from '@/(CMS)/blocks/FOTD/Component'
import { HeroSquareBlock } from '@/(CMS)/blocks/HeroSquareBlock/Component'
import { Flatten } from '@/utilities/typeUtilities'

const blockComponents = {
  archive: ArchiveBlock,
  content: ContentBlock,
  cta: CallToActionBlock,
  formBlock: FormBlock,
  mediaBlock: MediaBlock,
  fotd: FOTDBlock,
  heroSquare: HeroSquareBlock,
}
type BlockLayout = Flatten<NonNullable<Page['layout']>>
export const RenderBlocks: React.FC<{
  blocks: NonNullable<Page['layout']> | undefined | null
}> = (props) => {
  const { blocks } = props

  const hasBlocks = blocks && Array.isArray(blocks) && blocks.length > 0

  if (hasBlocks) {
    return (
      <>
        {blocks.map((block, index) => {
          const { blockType } = block

          if (blockType && blockType in blockComponents) {
            const Block = blockComponents[blockType]

            if (Block) {
              return (
                <div className="my-16" key={index}>
                  <Block {...(block as any)} />
                </div>
              )
            }
          }
          return null
        })}
      </>
    )
  }

  return null
}
