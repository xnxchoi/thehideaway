import configPromise from '@payload-config'
import { getPayload } from 'payload'
import React from 'react'

import { HomeArticleLayout } from '@/components/layouts/HomeArticleLayout'
import type { HeroSquareBlock as HeroSquareBlockProps, Post } from '@/payload-types'

export const HeroSquareBlock: React.FC<
  {
    id?: string
  } & HeroSquareBlockProps
> = async (props) => {
  const { id, categories, introContent, limit: limitFromProps, populateBy, selectedDocs } = props
  const limit = limitFromProps || 8
  let posts: Partial<Post>[] = []

  if (populateBy === 'collection') {
    const payload = await getPayload({ config: configPromise })
    const flattenedCategories = categories?.map((category) => {
      if (typeof category === 'object') return category.id
      return category
    })
    const fetchedPosts = await payload.find({
      collection: 'posts',
      depth: 1,
      sort: '-publishedAt',
      limit: limitFromProps || 8,
      where: {
        _status: {
          equals: 'published',
        },
      },
      select: {
        title: true,
        publishedAt: true,
        populatedAuthor: true,
        subtitle: true,
        category: true,
        heroImage: true,
        slug: true,
      },
    })
    posts = fetchedPosts.docs
  } else if (selectedDocs?.length) {
    const filteredSelectedPosts = selectedDocs.map((post) => {
      if (typeof post.value === 'object') return post.value
    }) as Post[]
    posts = filteredSelectedPosts
  }
  return <HomeArticleLayout posts={posts} />
}
