import React from 'react'
import { formatDateTime } from '@/utilities/formatDateTime'
import type { Post } from '@/payload-types'
import '@/styles/__archives.scss'
import { FrontImage } from '@/components/UX/Media/FrontImage'
import { cn } from '@/lib/utils'
import { blase, narcissianNectare } from '../../../../../fonts'

export const ArtHero: React.FC<{
  post: Post
}> = ({ post }) => {
  const { category, meta: { image: metaImage } = {}, heroImage, populatedAuthor, publishedAt, title, subtitle } = post

  return (<>
    <div className="p-0 order-1">
      <div className="relative w-full h-full">
        <div className="cover_card _split">

          <div className="rp_title-card title-grid">
            <div className="rp_title-tag">
                <span className="rp_tag">
                {(typeof category === 'object' && category !== null && category.title) ? category.title : 'Untitled category'}
                </span>
            </div>
            <div className={cn(narcissianNectare.className,'rp-title rRO it9')}>
              <h1 className="tracking-[-.01em] font-medium uppercase m-0">{title}</h1>
            </div>
            <div className={cn(narcissianNectare.className,'text-[14.4px] md:text-[17.6px] font-(family-name:--rp-sans) leading-[1.3] row-4 md:mt-[20px] rp__sub-t uRt mt-[5px] lg:pr-[20px] 2xl:pr-[40px]')}>
              <p className={'m-0'}>{subtitle} ✷ </p>
            </div>
            <address className="rp_author--info aTF">
              <div className="rp__a-m">
                <em>by</em>
                {populatedAuthor && (<div>{populatedAuthor?.at(0)?.name}</div>)}
              </div>
            </address>
            <div className="font-(family-name:--rp-sans) text-[11.7px] md:text-[14px] leading-[1.17] uppercase row-6 col-span-1 mt-[10px]">
              {publishedAt && (<div>
                <time dateTime={publishedAt}>{formatDateTime(publishedAt)}</time>
              </div>)}
            </div>
          </div>
          <div
            className="relative overflow-hidden rounded-xl row-start-2 row-end-2 col-start-1 col-end-1 md:row-start-1 md:row-end-1 md:col-start-2 md:col-end-2">
            <div className="rp_pxf rp_img">
              {heroImage && (typeof heroImage === 'number' ? (
                  <FrontImage fill priority={false} loading="lazy" imgClassName="rp_lazy thumb css-filter size-large"
                              resource={{
                                id: heroImage, createdAt: '', updatedAt: '', url: `/media/${heroImage}`,
                              }} />) : (
                  <FrontImage fill priority={false} loading="lazy" imgClassName="rp_lazy thumb css-filter size-large"
                              resource={heroImage} />)) ||
                <div className="rp_lazy thumb css-filter size-large bg-[oklch(var(--faded-fg)/0.2)]" />}
            </div>
          </div>
          <span className="rp_caption cap_grid">
              <a target="_blank" rel="noreferrer" href="" data-state="FOCUS">
                THE HIDEAWAY
              </a>
            </span>
        </div>
      </div>
    </div>
  </>)
}
