import React from 'react'
import { formatDateTime } from '@/utilities/formatDateTime'
import type { Post } from '@/payload-types'
import { FrontImage } from '@/components/UX/Media/FrontImage'

export const PostHero: React.FC<{
  post: Post
}> = ({ post }) => {
  const { categories, meta: { image: metaImage } = {}, populatedAuthor, publishedAt, title } = post

  return (<div className="relative -mt-[10.4rem] flex items-end">
    <div className="container relative z-10 pb-8 text-white lg:grid lg:grid-cols-[1fr_48rem_1fr]">
      <div className="col-span-1 col-start-1 md:col-span-2 md:col-start-2">
        <div className="mb-6 text-sm uppercase">
          {categories?.map((category, index) => {
            if (typeof category === 'object' && category !== null) {
              const { title: categoryTitle } = category

              const titleToUse = categoryTitle || 'Untitled category'

              const isLast = index === categories.length - 1

              return (<React.Fragment key={index}>
                {titleToUse}
                {!isLast && <>, &nbsp;</>}
              </React.Fragment>)
            }
            return null
          })}
        </div>
        <div className="">
          <h1 className="mb-6 text-3xl md:text-5xl lg:text-6xl">{title}</h1>
        </div>
        <div className="flex flex-col gap-4 md:flex-row md:gap-16">
          <div className="flex flex-col gap-4">
            {populatedAuthor && (<div className="flex flex-col gap-1">
              <p className="text-sm">Author</p>
              {populatedAuthor.map((author, index) => {
                const { name } = author

                const isLast = index === populatedAuthor.length - 1
                const secondToLast = index === populatedAuthor.length - 2

                return (<React.Fragment key={index}>
                  {name}
                  {secondToLast && populatedAuthor.length > 2 && <>, </>}
                  {secondToLast && populatedAuthor.length === 2 && <> </>}
                  {!isLast && populatedAuthor.length > 1 && <>and </>}
                </React.Fragment>)
              })}
            </div>)}
          </div>
          {publishedAt && (<div className="flex flex-col gap-1">
            <p className="text-sm">Date Published</p>
            <time dateTime={publishedAt}>{formatDateTime(publishedAt)}</time>
          </div>)}
        </div>
      </div>
    </div>
    <div className="min-h-[80vh] select-none">
      {metaImage && (
        <FrontImage fill priority={false} loading="lazy" imgClassName="-z-10 object-cover" resource={metaImage} />)}
      <div
        className="pointer-events-none absolute bottom-0 left-0 h-1/2 w-full bg-linear-to-t from-black to-transparent" />
    </div>
  </div>)
}
