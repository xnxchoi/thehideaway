import clsx from 'clsx'
import React from 'react'

import RichText from '@/(CMS)/fields/RichText'
import type { Post } from '@/payload-types'

import { RPCard } from 'src/(CMS)/components/Card'
import { cn } from '@/lib/utils'

export type RelatedPostsProps = {
  className?: string
  docs?: Post['relatedPosts']
  introContent?: any
}

export const MoreLikeThis: React.FC<RelatedPostsProps> = (props) => {
  const { className, docs, introContent } = props
  return (
    <div className="fZb">
      {docs?.map((doc, index) => {
        return typeof doc !== 'number' ? (
          <RPCard
            key={index}
            doc={doc}
            relationTo="posts"
            className={cn('col-span-6', 'col-span-' + 12 / docs.length)}
          />
        ) : null
      }) || null}
    </div>
  )
}
