import type { TextField } from 'payload'
import { formatUserHandleHook } from '@/(CMS)/fields/handle/formatUserHandle'
import { isAdmin, isEditor } from '@/(CMS)/plugins/locker/access/accessCheckers'

type Overrides = {
  userHandleOverrides?: Partial<TextField>
}

type UserHandle = (overrides?: Overrides) => [TextField]

export const userHandleField: UserHandle = (overrides = {}) => {
  const { userHandleOverrides } = overrides

  // Expect ts error here because of typescript mismatching Partial<TextField> with TextField
  // @ts-expect-error
  const userHandleField: TextField = {
    name: 'slug', unique: true, required: true, type: 'text', index: true, label: 'Handle', access: {
      create: ({ req }) => Boolean(isEditor || isAdmin), update: ({ req }) => Boolean(isEditor || isAdmin),
    }, saveToJWT: true, ...(userHandleOverrides || {}), hooks: {
      // Kept this in for hook or API based updates
      beforeValidate: [formatUserHandleHook(crypto.randomUUID())],
    }, admin: {
      position: 'sidebar', readOnly: true, ...(userHandleOverrides?.admin || {}), components: {
        Field: {
          path: '@/(CMS)/fields/handle/HandleComponent#HandleComponent', clientProps: {
            path: 'name',
          },
        },
      },
    },
  }

  return [userHandleField]
}
