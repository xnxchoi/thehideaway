import type { FieldHook } from 'payload'

export const formatUserHandle = (val: string): string => val.replace(/ /g, '-').replace(/[^\w-]+/g, '').toLowerCase()

export const formatUserHandleHook = (fallback: string): FieldHook => ({
  data, operation, siblingData, originalDoc, value,
}) => {
  if (typeof value === 'string') {
    return formatUserHandle(value)
  }

  if (operation === 'create' || !data?.slug) {
    const fallbackData = siblingData?.name || originalDoc?.name || originalDoc?.slug || fallback
    if (fallbackData && typeof fallbackData === 'string') {
      return formatUserHandle(fallbackData)
    }
  }

  return '@' + value
}
