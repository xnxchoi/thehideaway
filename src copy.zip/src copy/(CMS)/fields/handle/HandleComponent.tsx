'use client'

import './index.scss'

import { FieldLabel, TextInput, useField, useFormFields } from '@payloadcms/ui'
import type { TextFieldClientProps } from 'payload'
import React, { useEffect } from 'react'

import { formatUserHandle } from './formatUserHandle'

type UserHandleComponentProps = {
  fieldToUse: string
} & TextFieldClientProps

export const HandleComponent: React.FC<UserHandleComponentProps> = ({
  field,
  fieldToUse = 'name',
  path,
  readOnly: readOnlyFromProps,
}) => {
  const { label } = field

  const { value, setValue } = useField<string>({ path: path || field.name })

  // The value of the field we're listening to for the slug
  const targetFieldValue = useFormFields(([fields]) => {
    return fields[fieldToUse]?.value as string
  })

  useEffect(() => {
    if (targetFieldValue) {
      const formattedUserHandle = formatUserHandle(targetFieldValue)

      if (value !== formattedUserHandle) setValue(formattedUserHandle)
    } else if (value !== '') setValue('')
  }, [targetFieldValue, setValue, value])

  const readOnly = readOnlyFromProps ?? true

  return (
    <div className="field-type handle-field-component">
      <div className="label-wrapper">
        <FieldLabel htmlFor={`field-${path}`} label={label} />
      </div>
      <TextInput value={value} onChange={setValue} path={path || field.name} readOnly={readOnly} />
    </div>
  )
}
