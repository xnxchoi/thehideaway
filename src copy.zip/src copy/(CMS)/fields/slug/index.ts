import type { CheckboxField, TextField } from 'payload'

import { formatSlugHook } from './formatSlug'
import { isHangul } from '@/utilities/rp_utils'

type Overrides = {
  slugOverrides?: Partial<TextField>
  checkboxOverrides?: Partial<CheckboxField>
}

type Slug = (fieldToUse?: string, overrides?: Overrides) => [TextField, CheckboxField]

export const slugField: Slug = (fieldToUse = 'title', overrides = {}) => {
  const { slugOverrides, checkboxOverrides } = overrides

  const checkBoxField: CheckboxField = {
    name: 'slugLock', type: 'checkbox', defaultValue: true, admin: {
      hidden: true, position: 'sidebar',
    }, ...checkboxOverrides,
  }

  // Expect ts error here because of typescript mismatching Partial<TextField> with TextField
  // @ts-expect-error
  const slugField: TextField = {
    name: 'slug', type: 'text', index: true, label: 'Slug', unique: true,

    ...(slugOverrides || {}), hooks: {
      // Kept this in for hook or API based updates
      beforeValidate: [formatSlugHook(fieldToUse)], beforeChange: [({ data, operation, originalDoc, value }) => {
        if (isHangul(value)) {
          return encodeURIComponent(value)
        }
        return value
      }],
    }, admin: {
      position: 'sidebar', ...(slugOverrides?.admin || {}), components: {
        Field: {
          path: '@/(CMS)/fields/slug/SlugComponent#SlugComponent', clientProps: {
            fieldToUse, checkboxFieldPath: checkBoxField.name,
          },
        },
      },
    },
  }

  return [slugField, checkBoxField]
}
