import type { FieldHook } from 'payload'
import { isHangul } from '@/utilities/rp_utils'
import { DateTime } from 'luxon'

export const formatSlug = (val: string): string => {
  let res = val.replace(/ /g, '-').replace(/[^\w-]+/g, '')
  return encodeURIComponent(isHangul(val) ? res : res.toLowerCase())
}

export const formatSlugHook = (fallback: string): FieldHook => ({ data, operation, originalDoc, value }) => {
  if (typeof value === 'number') {
    return formatSlug('' + value)
  }
  if (typeof value === 'string') {
    return formatSlug(value)
  }

  if (operation === 'create' || !data?.slug) {
    const fallbackData = data?.[fallback] || data?.[fallback]

    if (fallbackData) {
      typeof fallbackData === 'number' ? formatSlug(fallbackData + '') : typeof fallbackData === 'string' ? formatSlug(fallbackData) : formatSlug(`reflection-${DateTime.now().toISODate()}`)
    }
  }

  return value
}
