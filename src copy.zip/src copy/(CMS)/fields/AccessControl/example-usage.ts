/**
 * This is an example of how to use the AccessControl field in a PayloadCMS collection
 *
 * Example Collection:
 *
 * ```typescript
 * import { CollectionConfig } from 'payload'
 * import accessControlField from '@/(CMS)/fields/AccessControl'
 *
 * const Posts: CollectionConfig = {
 *   slug: 'posts',
 *   admin: {
 *     useAsTitle: 'title',
 *   },
 *   // Example access control logic - implement according to your needs
 *   access: {
 *     read: ({ req }) => {
 *       // Always allow in admin panel
 *       if (req.originalUrl?.includes('/admin')) return true
 *
 *       // Public posts are always readable
 *       if (!req.data?.accessControl?.locked) return true
 *
 *       // If user is logged in
 *       if (req.user) {
 *         // User is admin or post author
 *         if (req.user.roles?.includes('admin') || req.user.id === req.data.author) return true
 *
 *         // Check authority level
 *         if (req.data.accessControl.authority?.enabled && req.data.accessControl.authority.value) {
 *           const level = req.data.accessControl.authority.value
 *
 *           // Level 1: Members
 *           if (level === 1 && req.user.roles?.includes('member')) return true
 *
 *           // Level 2: Patrons
 *           if (level === 2 && req.user.roles?.includes('patron')) return true
 *
 *           // Level 3: Authors
 *           if (level === 3 && req.user.roles?.includes('author')) return true
 *         }
 *
 *         // Check allowList
 *         if (req.data.accessControl.allowList?.enabled) {
 *           const allowedUsers = req.data.accessControl.allowList.relations || []
 *           return allowedUsers.some(rel => rel.id === req.user.id)
 *         }
 *       }
 *
 *       return false
 *     }
 *   },
 *   fields: [
 *     {
 *       name: 'title',
 *       type: 'text',
 *       required: true,
 *     },
 *     {
 *       name: 'content',
 *       type: 'richText',
 *     },
 *     {
 *       name: 'author',
 *       type: 'relationship',
 *       relationTo: 'users',
 *     },
 *     // Add the AccessControl field
 *     accessControlField({
 *       admin: {
 *         description: 'Control who can see this post',
 *         position: 'sidebar',
 *       },
 *     }),
 *   ],
 * }
 *
 * export default Posts
 * ```
 */

import accessControlField from './index'

// Export the access control field
export default accessControlField
