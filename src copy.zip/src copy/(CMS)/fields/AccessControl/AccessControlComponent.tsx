'use client'

import './index.scss'

import React, { useEffect, useState } from 'react'
import {
  useField,
  FieldDescription,
  TextInput,
  Button,
  FieldLabel,
  useDocumentInfo,
} from '@payloadcms/ui'

// Authority level options
const authorityLevels = [
  { label: 'Registered Members', value: 1, role: 'member' },
  { label: 'Subscribed Patrons', value: 2, role: 'patron' },
  { label: 'Authors', value: 3, role: 'author' },
]

const AccessControlComponent: React.FC<any> = (props) => {
  // Get the locked field value
  const { value: locked, setValue: setLocked } = useField<boolean>({ path: 'locked' })

  // Authority field values
  const { value: authorityEnabled, setValue: setAuthorityEnabled } = useField<boolean>({
    path: 'authority.enabled',
  })
  const { value: authorityValue, setValue: setAuthorityValue } = useField<number>({
    path: 'authority.value',
  })

  // AllowList field values
  const { value: allowListEnabled, setValue: setAllowListEnabled } = useField<boolean>({
    path: 'allowList.enabled',
  })
  const { value: allowListRelations, setValue: setAllowListRelations } = useField<any[]>({
    path: 'allowList.relations',
  })

  // State for the access status text
  const [accessState, setAccessState] = useState<string>('This post will be visible to you only.')
  const [transitioning, setTransitioning] = useState<boolean>(false)
  const [showResetConfirm, setShowResetConfirm] = useState<boolean>(false)

  // Handle authority button selection
  const handleAuthoritySelect = (value: number) => {
    setAuthorityValue(value)
    setAuthorityEnabled(true)
  }

  // Handle allowList reset
  const handleResetAllowList = () => {
    if (!showResetConfirm) {
      setShowResetConfirm(true)
      return
    }

    setAllowListRelations([])
    setShowResetConfirm(false)
  }

  // Update the access state text when values change
  useEffect(() => {
    if (!locked) return

    // Start transition
    setTransitioning(true)

    // Determine the access state text
    let newAccessState = 'This post will be visible to you only.'

    const parts: string[] = []

    // Check allowList
    if (allowListEnabled && Array.isArray(allowListRelations) && allowListRelations.length > 0) {
      const userNames = allowListRelations.map((relation) => {
        if (relation && relation.value) {
          const user = relation.value
          if (user.name && user.slug) {
            return `<a href="/${user.slug}" target="_blank">${user.name}</a>`
          }
          return 'selected user'
        }
        return 'selected user'
      })

      parts.push(userNames.join(', '))
    }

    // Check authority
    if (authorityEnabled && authorityValue) {
      const authority = authorityLevels.find((level) => level.value === authorityValue)
      if (authority) {
        parts.push(authority.label.toLowerCase())
      }
    }

    if (parts.length > 0) {
      newAccessState = `This post will be visible to ${parts.join(' and ')}.`
    }

    // Apply the new state after a brief delay for transition
    const timeout = setTimeout(() => {
      setAccessState(newAccessState)
      setTransitioning(false)
    }, 300)

    return () => clearTimeout(timeout)
  }, [locked, allowListEnabled, allowListRelations, authorityEnabled, authorityValue])

  // Reset fields when locked is false
  useEffect(() => {
    if (!locked) {
      // Don't reset the values, just don't show them
      setTransitioning(false)
    }
  }, [locked])

  return (
    <div className="access-control-field">
      {/* Locked Checkbox */}
      <div className="flex items-center gap-2 mb-2">
        <input
          type="checkbox"
          id="locked"
          checked={locked}
          onChange={(e) => setLocked(e.target.checked)}
        />
        <label htmlFor="locked">Locked</label>
      </div>

      {/* Fields visible only when locked is true */}
      <div className={`hidden-fields ${locked ? 'visible' : ''}`}>
        {/* Text label indicating access state */}
        <div
          className={`access-state ${transitioning ? 'transitioning' : ''}`}
          dangerouslySetInnerHTML={{ __html: accessState }}
        />

        {/* Authority selection */}
        <div className="mb-4">
          <div className="mb-2">Authority Level</div>
          <div
            className={`authority-buttons ${!authorityEnabled && !authorityValue ? 'disabled' : ''}`}
          >
            {authorityLevels.map((level) => (
              <button
                key={level.value}
                type="button"
                className={authorityValue === level.value ? 'selected' : ''}
                onClick={() => handleAuthoritySelect(level.value)}
              >
                {level.label}
              </button>
            ))}
          </div>
        </div>

        {/* Allow List */}
        <div className="mt-4">
          <div className="flex items-center gap-2 mb-2">
            <input
              type="checkbox"
              id="allowList-enabled"
              checked={allowListEnabled}
              onChange={(e) => setAllowListEnabled(e.target.checked)}
            />
            <label htmlFor="allowList-enabled">Enable Allow List</label>
          </div>

          <div className={`relationship-field ${allowListEnabled ? 'enabled' : ''}`}>
            {/* This would need to be replaced with a proper relationship field component */}
            <div className="relationship-field-placeholder border p-2 rounded">
              Relationship field would go here. This is a placeholder as we'd need to implement a
              custom version of the PayloadCMS relationship field.
            </div>

            {Array.isArray(allowListRelations) && allowListRelations.length > 0 && (
              <button
                type="button"
                className={`reset-button ${showResetConfirm ? 'confirm' : ''}`}
                onClick={handleResetAllowList}
              >
                {showResetConfirm ? 'Confirm Reset' : 'Reset'}
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default AccessControlComponent
