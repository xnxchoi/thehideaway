import deepMerge from '@/utilities/deepMerge'

type AccessControlOptions = {
  admin?: Record<string, any>
  overrides?: Record<string, any>
}

const accessControlField = (options: AccessControlOptions = {}) => {
  const { admin = {}, overrides = {} } = options

  const field: any = {
    name: 'accessControl',
    type: 'group',
    admin: {
      description: 'Control who can access this content',
      ...admin,
      components: {
        Field: {
          path: '@/(CMS)/fields/AccessControl/AccessControlComponent',
        },
      },
    },
    fields: [
      {
        name: 'locked',
        type: 'checkbox',
        defaultValue: false,
        label: 'Locked',
      },
      {
        name: 'textLabel',
        type: 'text',
        admin: {
          hidden: true,
        },
        defaultValue: 'This post will be visible to you only.',
      },
      {
        name: 'authority',
        type: 'group',
        admin: {
          hidden: true,
        },
        fields: [
          {
            name: 'enabled',
            type: 'checkbox',
            defaultValue: false,
          },
          {
            name: 'value',
            type: 'number',
          },
        ],
      },
      {
        name: 'allowList',
        type: 'group',
        admin: {
          hidden: true,
        },
        fields: [
          {
            name: 'enabled',
            type: 'checkbox',
            defaultValue: false,
          },
          {
            name: 'relations',
            type: 'relationship',
            relationTo: 'members',
            hasMany: true,
          },
        ],
      },
    ],
  }

  return deepMerge(field, overrides)
}

export default accessControlField
