import { LexicalFrontendEditor } from '@/(CMS)/Lexical/lexicalinstance'
import { defaultEditorLexicalConfig } from '@payloadcms/richtext-lexical'

export const LexicalServe = async () => {

  return (<LexicalFrontendEditor config={defaultEditorLexicalConfig}  />)

}