// frontendEditorConfig.ts
import { editorConfigFactory } from '@payloadcms/richtext-lexical';
import type { Config } from 'payload';

import payloadConfig from '@payload-config'

export const getEditorConfig = async () => {

  const config = await payloadConfig.then(async(r)=>await editorConfigFactory.default({ config:  r}));
  return config;
};