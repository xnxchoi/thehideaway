import { mention } from './Comments/mentions'
import { processMentions } from './Comments/hooks/processMentions'
import { Member } from '@/payload-types'
import { Access, CollectionConfig, CollectionSlug, FieldAccess } from 'payload'

// Types for our Comments Collection
export interface Comment {
  id: string;
  content: string;
  author: string | Member;
  collection: {
    relationTo: Extract<CollectionSlug, 'posts' | 'surf'>; value: string; // The ID of the related document
  } | string; // Collection relationship
  createdAt: string;
  updatedAt: string;
  isEdited: boolean;
  isReply: boolean;
  parentComment?: string | Comment; // Reference to parent comment if this is a reply
  mentions: Array<string | Member>; // Array of mentioned users
  isSticky: boolean;
  likes: Array<string | Member>; // Array of users who liked the comment
}

// Access control functions
const isAdminOrAuthor: Access = ({ req: { user } }) => {
  if (!user) return false
  if (user.collection === 'admins') return true
  if (user.roles && (user.roles.some(role => role === 'editor'))) return true

  return {
    author: {
      equals: user.id,
    },
  }
}

// Check if comments are enabled for the referenced document
const areCommentsEnabled: Access = async ({ req, data, id }) => {
  const { payload } = req

  // For existing comments, get collection and documentId from saved data
  let collectionValue = null
  let documentId = data?.documentId

  // Extract collection information
  if (data?.collection) {
    if (typeof data.collection === 'object' && data.collection.relationTo && data.collection.value) {
      // It's a relationship object
      collectionValue = data.collection.relationTo
      // documentId is already set above
    } else {
      // It's a string (legacy format or just the collection name)
      collectionValue = data.collection
    }
  }

  // If editing an existing comment and we don't have data yet, fetch it
  if ((!collectionValue || !documentId) && id) {
    try {
      const comment = await payload.findByID({
        collection: 'comments', id,
      })

      if (typeof comment.collection === 'object' && comment.collection.relationTo) {
        collectionValue = comment.collection.relationTo
      } else {
        collectionValue = comment.collection
      }

      documentId = comment.documentId
    } catch (error) {
      console.error(`Error fetching comment ${id}:`, error)
      return false
    }
  }

  // If we have collection and documentId, check if comments are enabled
  if (collectionValue && documentId) {
    try {
      const document = await payload.findByID({
        collection: collectionValue as CollectionSlug, id: documentId,
      })

      // If commentsEnabled is explicitly false, block access
      if (document.commentsEnabled === false) {
        // Allow admins and editors to still see the comments even if disabled
        if (req.user && req.user.roles && (req.user.roles.includes('admin') || req.user.roles.includes('editor'))) {
          return true
        }

        // Check if user is an author of the post
        if (req.user && req.user.roles && req.user.roles.includes('author') && Array.isArray(document.authors)) {
          const isAuthor = document.authors?.some(authorId => {
            if (typeof authorId === 'object' && authorId.id) {
              return authorId.id === req.user.id
            }
            return authorId === req.user.id
          })

          if (isAuthor) {
            return true
          }
        }

        // Not admin, editor, or author - deny access
        return false
      }

      // Comments are enabled, grant access
      return true
    } catch (error) {
      console.error(`Error checking commentsEnabled for ${collectionValue}/${documentId}:`, error)
      // If we can't determine, default to allowing access
      return true
    }
  }

  // If we can't determine, default to allowing access
  return true
}

// Field-level access for sticky functionality
// Only allow collection admins or content author to make sticky
const canMakeSticky: FieldAccess = ({ req: { user }, data }) => {
  if (!user) return false
  if (user.collection === 'admins') return true
  if (user.roles && (user.roles.some(role => role === 'editor'))) return true
  if (data?.author && data?.author.id === user.id) return true
  // Check if the user is the author of the content being commented on
  // This requires additional logic in an actual hook
  return false
}

// Comments Collection Config
const Comments: CollectionConfig = {
  slug: 'comments', admin: {
    useAsTitle: 'content', defaultColumns: ['content', 'author', 'collection', 'createdAt', 'isSticky'],
  }, access: {
    read: areCommentsEnabled, create: (args) => {
      const { req: { user } } = args
      if (!user) return false
      // Check if comments are enabled before allowing creation
      return areCommentsEnabled(args)
    }, update: async (args) => {
      // Must be admin/author AND comments must be enabled
      const canEdit = isAdminOrAuthor(args)
      if (!canEdit) return false

      return areCommentsEnabled(args)
    }, delete: async (args) => {
      // Must be admin/author AND comments must be enabled
      const canDelete = isAdminOrAuthor(args)
      if (!canDelete) return false

      return areCommentsEnabled(args)
    },
  }, hooks: {
    beforeChange: [// Process mentions from content
      processMentions, // Set isEdited flag when content is updated after creation
      ({ data, originalDoc }) => {
        if (originalDoc && data.content !== originalDoc.content) {
          data.isEdited = true
        }
        return data
      }],
  }, fields: [{
    name: 'content', type: 'richText', required: true, admin: {},
  }, {
    name: 'author', type: 'relationship', relationTo: 'members', hasMany: false, maxDepth: 1, required: true, admin: {
      position: 'sidebar',
    },
  }, {
    name: 'document', label: 'Document', type: 'relationship', relationTo: ['posts', 'surf'], // Add more collections as needed
    required: true, admin: {
      position: 'sidebar', description: 'Which document this comment belongs to',
    }, hasMany: false, maxDepth: 1,
  }, {
    name: 'isEdited', label: 'Edited', type: 'checkbox', admin: {
      position: 'sidebar', readOnly: true,
    }, defaultValue: false,
  }, {
    name: 'isReply', label: 'Is Reply', type: 'checkbox', admin: {
      position: 'sidebar',
    }, defaultValue: false, // },
    // {
    //   name: 'parentComment', label: 'Parent Comment', type: 'relationship', relationTo: 'comments', admin: {
    //     condition: (data) => data.isReply, position: 'sidebar', description: 'Select which comment this is a reply to',
    //   }, // Filter to only show comments from the same document
    //   filterOptions: ({ data }) => {
    //     if (!data?.collection || !data?.documentId) return {} // No filter if no collection/document
    //
    //     // Handle relationship format with relationTo and value properties
    //     const collectionValue = typeof data.collection === 'object' && data.collection.relationTo ? data.collection.relationTo : data.collection
    //
    //     return {
    //       and: [{
    //         collection: {
    //           relationTo: collectionValue,
    //         },
    //       }, {
    //         documentId: {
    //           equals: data.documentId,
    //         },
    //       }, {
    //         isReply: {
    //           equals: false, // Only top-level comments can be parents
    //         },
    //       }],
    //     }
    //   },
  }, {
    name: 'mentions', label: 'Mentions', type: 'array', admin: {
      initCollapsed: true,
    }, fields: [// Using custom mention field
      mention({
        relationTo: 'members', label: 'Member',
      })],
  }, {
    name: 'isSticky', label: 'Sticky Comment', type: 'checkbox', defaultValue: false, access: {
      update: canMakeSticky,
    }, admin: {
      position: 'sidebar', description: 'Pin this comment to the top',
    },
  }, {
    name: 'likes', label: 'Likes', type: 'relationship', relationTo: 'members', hasMany: true, admin: {
      description: 'Users who liked this comment', readOnly: true, // Users will like via API, not admin panel
    },
  }], timestamps: true,
}

export default Comments