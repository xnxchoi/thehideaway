import { CollectionConfig, FilterOptionsProps, Where } from 'payload'
import { isHangul } from '@/utilities/rp_utils'
import { MetaDescriptionField, MetaImageField, MetaTitleField, OverviewField } from '@payloadcms/plugin-seo/fields'
import { userHandleField } from '@/(CMS)/fields/handle'
import { Media } from '@/payload-types'
import { onlySelfOrAdmin } from '@/(CMS)/plugins/locker/access/accessCheckers'
import { memberDefaultAccess } from '@/(CMS)/auth/rp_auth/payload/collection/access'
import { DateTime } from 'luxon'

export const Members: CollectionConfig = {
  slug: 'members', defaultPopulate: {
    name: true, slug: true, firstName: true, lastName: true, email: true, profilePicture: true, meta: true,
  },
  admin:{
    hidden:({user})=>{
      if(user?.collection==='admins')return false
      return true
    }
 ,
    useAsTitle: 'email',

  }, access: memberDefaultAccess, fields: [{
    name: 'name', type: 'text', defaultValue: () => crypto.randomUUID(), index: true,
  },

    {
      name: 'profilePicture',
      type: 'upload',
      relationTo: 'media',
      filterOptions: ({ req, user }: FilterOptionsProps<Media>) => {
        let w: Where = {
          and: [{
            filesize: {
              less_than: 2560000,
            },
          }, {
            'author.value': {
              equals: user?.id,
            },
          }, {
            mimeType: {
              contains: 'image',
            },
          }],
        }
        return w
      },
      admin: {
        description: 'Upload your profile picture here.',
      },
      access: {
        read: () => true, update: ({ req, data }) => {
          if (!req.user) return false
          return req.user?.id === data?.id
        },
      },
    },

    {
      type: 'row', fields: [{
        name: 'firstName', type: 'text', label: 'First Name', index: true, defaultValue: 'R', hooks: {
          beforeChange: [({ siblingData, value, operation }) => {
            if (!value || typeof value !== 'string' || value.length === 0) {
              if (siblingData.name) {
                if (typeof siblingData.name === 'string') {
                  let name = siblingData.name.trim()
                  if (name.length > 0) {
                    if (isHangul(name.charAt(0))) {
                      if (name.length > 4) {
                        return name.slice(0, 2)
                      }
                      return name.slice(0, 1)
                    }
                    let firstName = name.indexOf(' ') > 0 ? name.split(' ')[0] : name.indexOf('-') ? name.split('-')[0] : name
                    return (firstName.slice(0, 1).toUpperCase() + firstName.slice(1).toLowerCase())
                  }
                }
              }
              return (siblingData.email.split('@')[0].slice(0, 1).toUpperCase() + siblingData.email.split('@')[0].slice(1).toLowerCase())
            }
            return isHangul(value.charAt(0)) ? value : value.slice(0, 1).toUpperCase() + value.slice(1).toLowerCase()
          }],
        },
      }, {
        name: 'lastName', type: 'text', label: 'Last Name', index: true, defaultValue: 'P', hooks: {
          beforeChange: [({ siblingData, value, operation }) => {
            if (!value || typeof value !== 'string' || value.length === 0) {
              if (siblingData.name) {
                if (typeof siblingData.name === 'string') {
                  let name = siblingData.name.trim()
                  if (name.length > 0) {
                    if (isHangul(name.charAt(0))) {
                      if (name.length > 3) {
                        return name.slice(2)
                      }
                      return name.slice(1)
                    }
                    let lastName = name.indexOf(' ') > 0 ? name.split(' ')[1] : name.indexOf('-') ? name.split('-')[1] : name
                    return lastName.slice(0, 1).toUpperCase() + lastName.slice(1).toLowerCase()
                  }
                }
              }
              return (siblingData.email.split('@')[0].slice(0, 1).toUpperCase() + siblingData.email.split('@')[0].slice(1).toLowerCase())
            }
            return isHangul(value.charAt(0)) ? value : value.slice(0, 1).toUpperCase() + value.slice(1).toLowerCase()
          }],
        },
      }],
    },

    {
      name: 'link', type: 'text', admin: {
        description: 'Your Personal Link- anything from your website to your twitter handle',
      },
    },

    {
      name: 'description',
      type: 'text',
      index: true,
      label: 'Intro',
      defaultValue: 'A Patron of The Hideaway.',
      admin: {
        description: 'A short description of yourself, your passion, work, interest, anything- just keep it interesting.',
      },
    }, {
      name: 'resume', type: 'upload', relationTo: 'media', label: 'Resumé', admin: {
        position: 'sidebar',
        description: 'Upload your resume here to make it available for download on your profile page. PDF only.',
        disabled: !onlySelfOrAdmin,
      }, filterOptions: ({ req, user }) => {
        if (!user) return false
        let w: Where = {
          and: [{
            'author.value': {
              equals: user?.id,
            },
          }, {
            mimeType: {
              contains: 'pdf',
            },
          }, {
            filesize: {
              less_than: 5560000,
            },
          }],
        }
        return w
      },
    },

    {
      name: 'favourites', type: 'relationship', relationTo: ['posts', 'surf'], hasMany: true, admin: {
        readOnly: true, description: 'Posts and Surfs you have liked.',
      }, index: true, defaultValue: [], label: 'Liked',
    }, {
      name: 'notification', type: 'join', on: 'recipient', collection: 'notifications', admin: {
        description: 'Notifications you have received.',
      },
    }, {
      name: 'location', type: 'text', index: true, defaultValue: 'Seoul, Korea', admin: {
        position: 'sidebar',
      }, label: 'Location',
    }, {
      name: 'protected', type: 'checkbox', defaultValue: false, admin: {
        position: 'sidebar',
      }, index: true,
    }, {
      name: 'verified', type: 'checkbox', defaultValue: false, admin: {
        position: 'sidebar', condition: ({ user }) => user?.collection === 'admins',
      }, index: true,
    }, {
      type: 'group', name: 'meta', label: 'SEO', fields: [OverviewField({
        titlePath: 'meta.title', descriptionPath: 'meta.description', imagePath: 'meta.image',
      }), MetaTitleField({
        hasGenerateFn: true,
      }), MetaImageField({
        relationTo: 'media', overrides: {
          maxDepth: 2, filterOptions: ({ req, siblingData, user }) => {
            if (!user) {
              return false
            }
            const w: Where = {
              and: [{
                'author.value': {
                  equals: user?.id,
                },
              }, {
                mimeType: {
                  contains: 'image',
                },
              }, {
                filesize: {
                  less_than: 2560000,
                },
              }],
            }
            return w
          },
        },
      }), MetaDescriptionField({})],
    }, ...userHandleField(), {
      name: 'memberNumber',
      type: 'text',
      unique: true,
      defaultValue: () => Math.floor(Math.random() * 1000000).toString(),
      access: {
        create: () => false, update: () => false,
      },
    }, {
      name: 'onboarded', type: 'checkbox', defaultValue: false, admin: {
        position: 'sidebar', readOnly:true
      }, index: true, access: {
        create: () => false, update: () => false,
      },
    }], hooks: {
    afterLogin: [async ({ req, token, user, collection }) => {
      const { payload } = req
      payload.logger.info({
        message:'inside afterLogin hook'
      })
      if (user) {
        if (user.onboarded !== true) {
          try {
            await payload.create({
              collection: 'notifications', data: {
                recipient: [{
                  value: user.id, relationTo: 'members',
                }],
                type: 'system',
                read: false,
                createdAt: DateTime.now().toISODate(),
                updatedAt: DateTime.now().toISODate(),
                content: `Welcome to Hideaway, ${user.name}!`,
                importance: 'normal',
                status: 'unread',
                title: 'First day?',
                actionLink: {
                  type: 'custom', url: '/profile', newTab: false, label: 'Go to your profile',
                },
              },
            })
            try {
              let res = await payload.update({
                collection: 'members', id: user.id, data: {
                  onboarded: true,
                }, overrideAccess: true,
              })
              user.onboarded = res.onboarded
            } catch (e) {
              payload.logger.error({
                message: `error while trying to update onboarded field value for ${user.id}`, error: e,
              })
            }
          } catch (e) {
            payload.logger.error({
              message: `error while creating notifications for user ${user?.id}`, error: e,
            })

          }
        }
      }
      try {
        await payload.find({
          collection: 'notifications', where: {
            'recipient.value': {
              equals: user?.id,
            },
          }, select: {
            actionLink: true, title: true, content: true, status: true, read: true,
          }, overrideAccess: true,
        }).then((notifications) => {
          if (notifications.totalDocs > 0) {
            user.notification = notifications
          }
        })
      } catch (e) {
        payload.logger.error({
          message: `error while attempting to find notifications for user ${user?.id}`, error: e,
        })
      }
      return user
    }],
  },
}
