import { CollectionConfig } from 'payload'
import { link } from '@/(CMS)/fields/link'


/**
 * Notifications Collection Configuration
 *
 * This collection handles all types of user notifications in a social networking context.
 * It includes relations to users, content types, and various metadata to support
 * a robust notification system similar to major platforms.
 */
export const Notifications: CollectionConfig = {
  slug: 'notifications', admin: {
    useAsTitle: 'title',
    defaultColumns: ['content', 'recipient', 'type', 'status', 'createdAt'],
    description: 'User notifications for system events and social interactions',
  }, access: {
    read: ({ req: { user } }) => {
      // Users can only read their own notifications
        if (user?.collection === 'admins') return true
        return {
          'recipient.value':{
            equals:user?.id
          },
        }
    }, create:({req:{user}})=>{
      if(user?.collection==='admins')return true
      return false
    },
  }, fields: [// Target user (recipient)
    {
      name: 'recipient', type: 'relationship', relationTo: ['members', 'admins'], required: true, index: true, admin: {
        position: 'sidebar',
        hidden: true,
      }, hasMany: true,
      defaultValue: [],
    },

    // Actor (user who triggered the notification, if applicable)
    {
      name: 'actor', type: 'relationship', relationTo: ['posts', 'surf', 'members'], admin: {
        position: 'sidebar', description: 'User who triggered this notification (if applicable)',
      },
    }, {
      name: 'thumbnail', type: 'relationship', relationTo: 'media', admin: {
        position: 'sidebar', description: 'Thumbnail for the notification',
      },
    },

    // Related content (polymorphic relationship)
    {
      name: 'relatedContent', type: 'relationship', relationTo: ['posts', 'surf', 'members'], // Add your content types here
      hasMany: true, admin: {
        description: 'Content this notification refers to',
        position: 'sidebar',

      },
      access: {
        read: ({ req: { user }, data }) => {
          if (user) {
            if (user.collection === 'admins' || user.roles?.some(r => r === 'editor')) return true
            if (data?.recipient?.some(r => r.value === user.id)) return true
          }
          return false
        },
      },
      defaultValue: [],

    },

    // Notification type
    {
      name: 'type',
      type: 'select',
      required: true,
      options: [{ label: 'Comment', value: 'comment' }, { label: 'Like', value: 'like' }, {
        label: 'Message', value: 'message',
      }, { label: 'Friend Request', value: 'friend_request' }, { label: 'Tag', value: 'tag' }, {
        label: 'Mention', value: 'mention',
      }, { label: 'System', value: 'system' }, { label: 'Access', value: 'access' }// Add more notification types as needed
      ],
      admin: {
        position: 'sidebar',
      },
    },

    // Importance level
    {
      name: 'importance',
      type: 'select',
      required: true,
      defaultValue: 'normal',
      options: [{ label: 'High', value: 'high' }, { label: 'Normal', value: 'normal' }, {
        label: 'Low', value: 'low',
      }],
      admin: {
        position: 'sidebar',
      },
    },

    // Status
    {
      name: 'status',
      type: 'select',
      required: true,
      defaultValue: 'unread',
      options: [{ label: 'Unread', value: 'unread' }, { label: 'Read', value: 'read' }, {
        label: 'Dismissed', value: 'dismissed',
      }],
      admin: {},
    }, {
      name: 'read', type: 'checkbox', required: true, defaultValue: false, index: true, admin: {
        position: 'sidebar',
      },
    },

    // Date read
    {
      name: 'readAt', type: 'date', admin: {
        position: 'sidebar', description: 'When the notification was read', condition: (data) => data.status === 'read',
      },
    },

    // Sticky notification
    {
      name: 'isSticky', type: 'checkbox', defaultValue: false, label: 'Pin to top', admin: {
        description: 'Pin this notification to the top of the list', position: 'sidebar',
      },
    },

    // Notification summary (for admin display)
    {
      name: 'title', type: 'text', required: true, admin: {
        description: 'Brief description of the notification',
      },
    },

    // Detailed content
    {
      name: 'content', type: 'textarea', admin: {
        description: 'Full notification content with formatting',
      },
    }, link({
      overrides: {
        name: 'actionLink',

      },
    }), // Group identifier (for grouping similar notifications)
    {
      name: 'groupId', type: 'text', admin: {
        description: 'Used to group similar notifications (e.g., multiple likes on the same post)',
      },
    }], timestamps: true, // Automatically adds createdAt and updatedAt
  hooks: {
    beforeChange: [({ data, operation }) => {
      // Set readAt timestamp when status changes to 'read'
      if (operation === 'update' && data.read && !data.readAt) {
        data.readAt = new Date().toISOString()
      }
      return data
    }],
  },
}
