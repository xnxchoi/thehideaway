import type { CollectionConfig } from 'payload'
import { isAdmin, authenticated, standardUpdateAccess, standardCreateAccess } from '@/(CMS)/plugins/locker/access/accessCheckers'

export const Occupations: CollectionConfig = {
  slug: 'occupations', access: {
    create: standardCreateAccess, delete: isAdmin, read: authenticated, update: standardUpdateAccess,
  }, admin: {
    useAsTitle: 'title',
  }, defaultPopulate: {
    title: true,
  }, fields: [{
    name: 'title', type: 'text', required: true, unique: true, index: true,
  }, {
    name: 'author', type: 'relationship', relationTo: 'members', admin: { readOnly: true }, index: true, hooks: {
      beforeChange: [({ req, data, siblingData, operation, value, originalDoc }) => {
        if (!req.user) throw new Error('Not logged in')
        if (!req.user.id) throw new Error('No user id')
        if (operation === 'create') return req.user.id
        return originalDoc.author.id
      }],
    },
  }, {
    name: 'members', type: 'relationship', relationTo: 'members', hasMany: true, admin: {
      position: 'sidebar',
    }, virtual: true, index: true,
  }],
}
