import {
  MetaDescriptionField, MetaImageField, MetaTitleField, OverviewField, PreviewField,
} from '@payloadcms/plugin-seo/fields'
import {
  FixedToolbarFeature, HorizontalRuleFeature, InlineToolbarFeature, lexicalEditor,
} from '@payloadcms/richtext-lexical'
import type { CollectionConfig } from 'payload'

import { slugField } from '@/(CMS)/fields/slug'
import { getServerSideURL } from '@/utilities/getURL'

import { generatePreviewPath } from '../../../utilities/generatePreviewPath'
import { populateAuthors } from './hooks/populateAuthors'
import { validateSurf } from '@/(CMS)/collections/Surfs/hooks/validateSurf'
import { surfsAccess } from '@/(CMS)/plugins/locker/access'

export const Surf: CollectionConfig = {
  slug: 'surf',
  access:surfsAccess,
  // This config controls what's populated by default when a post is referenced
  // https://payloadcms.com/docs/queries/select#defaultpopulate-collection-config-property
  // Type safe if the collection slug generic is passed to `CollectionConfig` - `CollectionConfig<'surfs'>
  defaultPopulate: {
    title: true,
    slug: true,
    categories: true,
    meta: {
      image: true,
      description: true,
    },
    _status: true,
  },
  admin: {
    defaultColumns: ['title', 'slug', 'updatedAt'],
    livePreview: {
      url: ({ data }) => {
        const path = generatePreviewPath({
          slug: typeof data?.slug === 'string' ? data.slug : '',
          collection: 'surf',
        })

        return `${getServerSideURL()}${path}`
      },
    },
    preview: (data) => {
      const path = generatePreviewPath({
        slug: typeof data?.slug === 'string' ? data.slug : '',
        collection: 'surf',
      })

      return `${getServerSideURL()}${path}`
    },
    useAsTitle: 'title',
  },
  fields: [
    {
      name: 'title',
      type: 'text',
      required: true,
    },


    {
      type: 'tabs',
      tabs: [
        {
          fields: [
            {
              name: 'surfspot',
              type: 'text',
              required: true,
              label: 'Link',
              admin: {
                description: 'Provide the surf spot.',
              },
            },
            {
              name: 'content',
              type: 'richText',
              editor: lexicalEditor({
                features: ({ rootFeatures }) => {
                  return [
                    ...rootFeatures,
                    FixedToolbarFeature(),
                    InlineToolbarFeature(),
                    HorizontalRuleFeature(),
                  ]
                },
              }),
              label: false,
              required: true,
            },
          ],
          label: 'Content',
        },
        {
          fields: [
            {
              name: 'relatedPosts',
              type: 'relationship',
              admin: {
                position: 'sidebar',
              },
              label: 'Related Surfs',
              filterOptions: ({ id }) => {
                return {
                  id: {
                    not_in: [id],
                  },
                }
              },
              hasMany: true,
              relationTo: 'surf',
              maxDepth: 1,
            },
            {
              name: 'category',
              type: 'relationship',
              admin: {
                position: 'sidebar',
              },
              hasMany: false,
              relationTo: 'categories',
            },
            {
              name: 'state',
              type: 'select',
              hasMany: false,
              index: true,
              options: ['public', 'private'],
              defaultValue: 'private',
              admin: {
                position: 'sidebar',
                condition: (siblingData ) => {
                  if (!siblingData || !siblingData._status) return false
                  return siblingData._status === 'published'
                },
              },
              hooks: {
                beforeValidate: [
                  async ({ req, data, siblingData, value, originalDoc }) => {
                    let res =
                      (req.user &&
                        (req.user.collection === 'admins' ||
                          req.user.id === siblingData.author.id)) ||
                      false
                    if (res) {
                      if (siblingData._status === 'published') {
                        if (value !== 'private' && value !== 'public') {
                          return 'public'
                        }
                        return value
                      } else if (siblingData._status === 'draft') {
                        return 'private'
                      }
                      return 'private'
                    } else {
                      return originalDoc.state
                    }
                  },
                ],
              },
            },
          ],
          label: 'Meta',
        },
        {
          name: 'meta',
          label: 'SEO',
          fields: [
            OverviewField({
              titlePath: 'meta.title',
              descriptionPath: 'meta.description',
              imagePath: 'meta.image',
            }),
            MetaTitleField({
              hasGenerateFn: true,
            }),
            MetaImageField({
              relationTo: 'media',
            }),

            MetaDescriptionField({}),
            PreviewField({
              // if the `generateUrl` function is configured
              hasGenerateFn: true,

              // field paths to match the target field for data
              titlePath: 'meta.title',
              descriptionPath: 'meta.description',
            }),
          ],
        },
      ],
    },
    {
      name: 'publishedAt',
      type: 'date',
      admin: {
        date: {
          pickerAppearance: 'dayAndTime',
        },
        position: 'sidebar',
      },
      hooks: {
        beforeChange: [
          ({ siblingData, value }) => {
            if (siblingData._status === 'published' && !value) {
              return new Date()
            }
            return value
          },
        ],
      },
    },
    {
      name: 'author',
      type: 'relationship',
      maxDepth: 1,
      admin: {
        position: 'sidebar',
      },
      hasMany: false,
      relationTo: ['members','admins'],
    }, // This field is only used to populate the user data via the `populateAuthors` hook
    // This is because the `user` collection has access control locked to protect user privacy
    // GraphQL will also not return mutated user data that differs from the underlying schema
    {
      name: 'populatedAuthor',
      type: 'array',
      access: {
        update: () => false,
      },
      admin: {
        disabled: true,
        readOnly: true,
      },
      fields: [
        {
          name: 'id',
          type: 'text',
        },
        {
          name: 'name',
          type: 'text',
        },
      ],
    },
    ...slugField(),
  ],
  hooks: {
    afterChange: [validateSurf],
    afterRead: [populateAuthors],
  },
  versions: {
    drafts: {
      autosave: {
        interval: 100, // We set this interval for optimal live preview
      },
    },
    maxPerDoc: 50,
  },
}
