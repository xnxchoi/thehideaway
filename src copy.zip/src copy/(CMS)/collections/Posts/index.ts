import { AccessArgs, CollectionConfig, Where } from 'payload'

import {
  BlocksFeature, FixedToolbarFeature, HeadingFeature, HorizontalRuleFeature, InlineToolbarFeature, lexicalEditor,
} from '@payloadcms/richtext-lexical'
import { Banner } from '@/(CMS)/blocks/Banner/config'
import { Code } from '@/(CMS)/blocks/Code/config'
import { MediaBlock } from '@/(CMS)/blocks/MediaBlock/config'
import { generatePreviewPath } from '@/utilities/generatePreviewPath'
import { populateAuthors } from './hooks/populateAuthors'
import { revalidateDelete, revalidatePost } from './hooks/revalidatePost'

import {
  MetaDescriptionField, MetaImageField, MetaTitleField, OverviewField, PreviewField,
} from '@payloadcms/plugin-seo/fields'
import { slugField } from '@/(CMS)/fields/slug'
import { Post } from '@/payload-types'
import { createStdRelFieldAccess } from '@/(CMS)/plugins/locker/fields/access'
import { rolesToAuthority } from '@/(CMS)/plugins/locker/fields/authority/utils'

export const Posts: CollectionConfig<'posts'> = {
  slug: 'posts', // This config controls what's populated by default when a post is referenced
  // https://payloadcms.com/docs/queries/select#defaultpopulate-collection-config-property
  // Type safe if the collection slug generic is passed to `CollectionConfig` - `CollectionConfig<'posts'>
  access: {
    create: ({ req: { user } }) => {

      if (user?.collection === 'admins') return true
      if (user?.roles?.some((role) => role === 'author' || role === 'editor')) return true
      return false
    }, update: ({ req: { user } }) => {
      if (!user) return false
      if (user?.collection === 'admins') return true
      if (user?.roles?.some((role) => role === 'editor')) return true
      return ({
        'author.value': {
          equals: user?.id,
        },
      })
    }, delete: ({ req: { user } }) => {
      if (!user) return false
      if (user?.collection === 'admins') return true
      if (user?.roles?.some((role) => role === 'editor')) return true
      return ({
        'author.value': {
          equals: user?.id,
        },
      })
    }, read: (args: AccessArgs) => {
      const { req } = args
      const { user } = req
      if (user?.collection === 'admins') {
        return true
      }
      if (user?.roles?.some((role) => role === 'editor')) {
        return true
      }
      return {
        'author.value':{
          equals:user?.id
        }
      }

    },
  }, defaultPopulate: {
    title: true, meta: {
      image: true, description: true,
    }, slug: true, category: true, populatedAuthor: true,
  }, admin: {

    defaultColumns: ['title', 'slug', 'updatedAt'], livePreview: {
      url: ({ data, req }) => {
        const path = generatePreviewPath({
          slug: typeof data?.slug === 'string' ? data.slug : '', collection: 'posts',
        })

        return path
      },
    }, preview: (data, { req }) => generatePreviewPath({
      slug: typeof data?.slug === 'string' ? data.slug : '', collection: 'posts',
    }), useAsTitle: 'title',
  }, fields: [{
    name: 'title', type: 'text', required: true,
  }, { name: 'subtitle', type: 'text', required: true }, {
    type: 'tabs', tabs: [{
      fields: [{
        name: 'heroImage', type: 'upload', relationTo: 'media',
      }, {
        name: 'content', type: 'richText', editor: lexicalEditor({
          features: ({ rootFeatures }) => {
            return [...rootFeatures, HeadingFeature({ enabledHeadingSizes: ['h1', 'h2', 'h3', 'h4'] }), BlocksFeature({ blocks: [Banner, Code, MediaBlock] }), FixedToolbarFeature(), InlineToolbarFeature(), HorizontalRuleFeature()]
          },
        }), label: false, required: true,
      }], label: 'Content',access:{
        read:({ siblingData, data, doc, req }) => {
          const { user, payload } = req
          const idc = doc as Post
          if (idc._status !== 'published') {
            if (!user) {
              return false
            }
            return user.id === idc.author?.value

          }
          if (idc.locked) {
            if(!user){
              return false
            }
            //locked related stuff
            if (user && user.collection === 'admins') {
              return true
            }
            const authLevel = idc.authority ?? 0
            const allowed = idc.allowList ?? []
            if (authLevel > 0) {
              if (rolesToAuthority(user?.roles ?? []) >= authLevel) {
                return true
              }
            }
            return allowed.some(all => all.value === user?.id)

          } else {

            return true
          }
        }
      }
    }, {
      fields: [ {
        name: 'relatedPosts', type: 'relationship', admin: {
          position: 'sidebar',
        }, filterOptions: ({ req, id }) => {
          return {

            _status: {
              equals: 'published',
            },

          }
        }, hasMany: true, maxRows: 5, relationTo: 'posts',
      }, {
        name: 'category', type: 'relationship', admin: {

        }, hasMany: false, relationTo: 'categories',
      }], label: 'Meta',
    }, {
      name: 'meta', label: 'SEO', fields: [OverviewField({
        titlePath: 'meta.title', descriptionPath: 'meta.description', imagePath: 'meta.image',
      }), MetaTitleField({
        hasGenerateFn: true,
      }), MetaImageField({
        relationTo: 'media',
      }),

        MetaDescriptionField({}), PreviewField({
          // if the `generateUrl` function is configured
          hasGenerateFn: true,

          // field paths to match the target field for data
          titlePath: 'meta.title', descriptionPath: 'meta.description',
        })],
    }],
  }, {
    name: 'publishedAt', type: 'date', admin: {
      date: {
        pickerAppearance: 'dayAndTime',
      }, position: 'sidebar',
    }, hooks: {
      beforeChange: [({ siblingData, value }) => {
        if (siblingData?._status === 'published' && !value) {
          return new Date()
        }
        return value
      }],
    },
  }, {
    name: 'author', type: 'relationship', admin: {
      position: 'sidebar',
    }, access: {
      read: () => true, create: createStdRelFieldAccess, update: createStdRelFieldAccess,
    }, hasMany: false, relationTo: ['members', 'admins'], defaultValue: ({ user }) => {
      if (!user) return []
      return [{
        value: user?.id, relationTo: user?.collection,
      }]
    },
  }, // This field is only used to populate the user data via the `populateAuthors` hook
    // This is because the `user` collection has access control locked to protect user privacy
    // GraphQL will also not return mutated user data that differs from the underlying schema
    {
      name: 'populatedAuthor', type: 'array', access: {}, admin: {
        disabled: true, readOnly: true,
      }, fields: [{
        name: 'id', type: 'text',
      }, {
        name: 'name', type: 'text',
      }],
    }, ...slugField()], hooks: {
    beforeChange: [({ data, operation, originalDoc }) => {
      let datum = data as Partial<Post>
      if (!datum.subtitle) {
        if (operation === 'create') {
          data.subtitle = datum?.content?.blocks?.[0]?.text ?? ''
        } else {
          data.subtitle = originalDoc.subtitle ?? datum?.content?.blocks?.[0]?.text ?? ''
        }
      }
      return data
    }], afterChange: [revalidatePost], afterRead: [populateAuthors], afterDelete: [revalidateDelete],
  }, versions: {
    drafts: {
      autosave: {
        interval: 100, // We set this interval for optimal live preview
      }, schedulePublish: true,
    }, maxPerDoc: 50,
  },
}