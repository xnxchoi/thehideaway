import { FieldAccessArgs } from 'node_modules/payload/dist/fields/config/types'
import { FieldAccess } from 'payload'
import { Post } from '@/payload-types'
import { rolesToAuthority } from '@/(CMS)/plugins/locker/fields/authority/utils'

const contentReadAccess: FieldAccess = ({ siblingData, data, doc, req }: FieldAccessArgs) => {
  const { user, payload } = req
  const idc = doc as Post
  if (idc._status !== 'published') {
    if (!user) {
      return false
    }
    return user.id === idc.author?.value

  }
  if (idc.locked) {
    //locked related stuff
    if (user && user.collection === 'admins') {
      return true
    }
    const authLevel = idc.authority ?? 0
    const allowed = idc.allowList ?? []
    if (authLevel > 0) {
      if (rolesToAuthority(user?.roles ?? []) >= authLevel) {
        return true
      }
    }
    return allowed.some(all => all.value === user?.id)

  } else {

    return true
  }
}