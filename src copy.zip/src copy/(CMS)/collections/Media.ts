import type { CollectionConfig } from 'payload'

import { FixedToolbarFeature, InlineToolbarFeature, lexicalEditor } from '@payloadcms/richtext-lexical'
import path from 'path'
import { fileURLToPath } from 'url'
import { updateStdCheckboxFieldAccess } from '@/(CMS)/plugins/locker/fields/access'
import { extractImageInfo } from '@/utilities/extractImageInfo'
import { mediaAccess } from '@/(CMS)/plugins/locker/access'

const filename = fileURLToPath(import.meta.url)
const dirname = path.dirname(filename)

export const Media: CollectionConfig = {
  slug: 'media', defaultPopulate: {
    filename: true, url: true, author: true, width: true, height: true, darkmode: true,

  }, access: mediaAccess, fields: [{
    name: 'alt', type: 'text', //required: true,
  }, {
    name: 'caption', type: 'richText', editor: lexicalEditor({
      features: ({ rootFeatures }) => {
        return [...rootFeatures, FixedToolbarFeature(), InlineToolbarFeature()]
      },
    }),
  }, {
    name: 'darkmode', type: 'checkbox', defaultValue: false, index: true, admin: {
      condition: (data,siblingData,{user})=>{
        if (!user) return false
        if (user?.collection === 'admins') return true
        if (user?.roles?.some((role) => role === 'editor')) return true
        return !!data?.author?.some((au) => {
          if (au.value === user?.id && au.relationTo === user?.collection) return true
        })
      },
    }, access: {
      update: updateStdCheckboxFieldAccess, create: () => false,
    },
  }, {
    name: 'author',
    type: 'relationship',
    relationTo: ['members', 'admins'],
    hasMany: false,
    defaultValue: ({ user }) => {
      if (!user) return []
      return [{ value: user.id, relationTo: user.collection }]
    },
    index: true,

  }], upload: {
    // Upload to the public/media directory in Next.js making them publicly accessible even outside of Payload
    staticDir: path.resolve(dirname, '../../public/media'),
    adminThumbnail: 'thumbnail',
    focalPoint: true,
    imageSizes: [{
      name: 'thumbnail', width: 300,
    }, {
      name: 'square', width: 500, height: 500,
    }, {
      name: 'small', width: 600,
    }, {
      name: 'medium', width: 900,
    }, {
      name: 'large', width: 1400,
    }, {
      name: 'xlarge', width: 1920,
    }, {
      name: 'og', width: 1200, height: 630, crop: 'center',
    }],
  }, hooks: {
    beforeChange: [async ({ data, collection, operation, req }) => {
      if (operation === 'create') {
        if (req.file) {
          if (req.file.mimetype.indexOf('image') > -1) {
            const newd = await extractImageInfo({ req })
            if (newd) {
              let { width, height, darkmode } = newd
              data.darkmode = darkmode
              data.width = width
              data.height = height
            }
          }
        }
        if (req.user) {
          data.author = [{
            value: req.user?.id, relationTo: req.user?.collection,
          }]
        }

      }
      return data
    }],
  }, versions: {
    drafts: {
      autosave: {
        interval: 100, // We set this interval for optimal live preview
      }, schedulePublish: true,
    }, maxPerDoc: 10,
  }
}