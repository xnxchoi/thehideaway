import {
  MetaDescriptionField,
  MetaImageField,
  MetaTitleField,
  OverviewField,
  PreviewField,
} from '@payloadcms/plugin-seo/fields'
import type { CollectionConfig, FilterOptionsProps, Where } from 'payload'

import { slugField } from '@/(CMS)/fields/slug'
import { hero } from '@/(CMS)/blocks/heros/config'
import { getServerSideURL } from '@/utilities/getURL'
import { Archive } from '@/(CMS)/blocks/ArchiveBlock/config'
import { CallToAction } from '@/(CMS)/blocks/CallToAction/config'
import { Content } from '@/(CMS)/blocks/Content/config'
import { FormBlock } from '@/(CMS)/blocks/Form/config'
import { MediaBlock } from '@/(CMS)/blocks/MediaBlock/config'
import { populatePublishedAt } from '@/hooks/populatePublishedAt'
import { generatePreviewPath } from '@/utilities/generatePreviewPath'
import { revalidatePage } from './hooks/revalidatePage'
import { Media } from '@/payload-types'
import { FOTD } from '@/(CMS)/blocks/FOTD/config'
import { HeroSquare } from '@/(CMS)/blocks/HeroSquareBlock/config'
import { pagesAccess } from '@/(CMS)/plugins/locker/access'

export const Pages: CollectionConfig<'pages'> = {
  slug: 'pages',
  access: pagesAccess, // This config controls what's populated by default when a page is referenced
  // https://payloadcms.com/docs/queries/select#defaultpopulate-collection-config-property
  // Type safe if the collection slug generic is passed to `CollectionConfig` - `CollectionConfig<'pagess'>
  defaultPopulate: {
    title: true,
    slug: true,
    _status: true,
    meta: {
      image: true,
    },
  },
  admin: {
    defaultColumns: ['title', 'slug', 'updatedAt'],
    livePreview: {
      url: ({ data }) => {
        const path = generatePreviewPath({
          slug: typeof data?.slug === 'string' ? data.slug : '',
          collection: 'pages',
        })

        return `${getServerSideURL()}${path}`
      },
    },
    preview: (data) => {
      const path = generatePreviewPath({
        slug: typeof data?.slug === 'string' ? data.slug : '',
        collection: 'pages',
      })

      return `${getServerSideURL()}${path}`
    },
    useAsTitle: 'title',
    hidden:({user})=>{
      if(user?.collection==='admins')return false
      return true
    }
  },
  fields: [
    {
      name: 'title',
      type: 'text',
      required: true,
      index: true,
    },
    {
      type: 'tabs',
      tabs: [
        {
          fields: [hero],
          label: 'Hero',
        },
        {
          fields: [
            {
              name: 'layout',
              type: 'blocks',
              blocks: [CallToAction, Content, MediaBlock, Archive, FormBlock, FOTD, HeroSquare],
            },
          ],
          label: 'Content',
        },
        {
          name: 'pageLayout',
          label: 'Layout',
          fields: [
            {
              name: 'footerType',
              type: 'select',
              options: ['standard', 'linksOnly', 'hidden'],
              defaultValue: 'standard',
              label: 'Footer Type',
              admin: {
                condition: (data, siblingData) => {
                  return !Boolean(data?.['disableFooter']?.value)
                },
              },

              index: true,
            },
            {
              name: 'visuallyShowOnlyFirstSection',
              label: 'Show First Section Only',
              type: 'checkbox',
              defaultValue: false,
              index: true,
              admin: {
                condition: (data, siblingData) => {
                  return siblingData?.['hero.type']?.value !== 'none'
                },
              },
            },
            {
              name: 'disableFooter',
              type: 'checkbox',
              defaultValue: false,
              label: 'Disable Footer',
              admin: {},
              index: true,
            },
            {
              name: 'videoLoop',
              type: 'group',
              index: true,
              fields: [
                {
                  name: 'desktop',
                  type: 'relationship',
                  relationTo: 'media',
                  hasMany: false,
                  index: true,
                  filterOptions: ({ data, siblingData }: FilterOptionsProps<Media>): Where => {
                    return {
                      and: [
                        {
                          filesize: {
                            less_than: 76000000,
                          },
                        },
                        {
                          mimeType: {
                            contains: 'video',
                          },
                        },
                      ],
                    }
                  },
                },
                {
                  name: 'mobile',
                  type: 'relationship',
                  relationTo: 'media',
                  hasMany: false,
                  index: true,
                  filterOptions: ({ data, siblingData }: FilterOptionsProps<Media>): Where => {
                    return {
                      and: [
                        {
                          filesize: {
                            less_than: 76000000,
                          },
                        },
                        {
                          mimeType: {
                            contains: 'video',
                          },
                        },
                      ],
                    }
                  },
                },
              ],
              label: 'Video Loop',
            },
          ],
        },
        {
          name: 'meta',
          label: 'SEO',
          fields: [
            OverviewField({
              titlePath: 'meta.title',
              descriptionPath: 'meta.description',
              imagePath: 'meta.image',
            }),
            MetaTitleField({
              hasGenerateFn: true,
            }),
            MetaImageField({
              relationTo: 'media',
            }),

            MetaDescriptionField({}),
            PreviewField({
              // if the `generateUrl` function is configured
              hasGenerateFn: true,

              // field paths to match the target field for data
              titlePath: 'meta.title',
              descriptionPath: 'meta.description',
            }),
          ],
        },
      ],
    },
    {
      name: 'publishedAt',
      type: 'date',
      admin: {
        position: 'sidebar',
      },
    },
    ...slugField('title', { slugOverrides: { required: true } }),
  ],
  hooks: {
    afterChange: [revalidatePage],
    beforeChange: [populatePublishedAt],
  },
  versions: {
    drafts: {
      autosave: {
        interval: 100, // We set this interval for optimal live preview
      },
    },
    maxPerDoc: 50,
  },
}
