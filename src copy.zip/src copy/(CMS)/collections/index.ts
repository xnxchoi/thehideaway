import { Categories } from '@/(CMS)/collections/Categories'
import { Media } from '@/(CMS)/collections/Media'
import { Pages } from '@/(CMS)/collections/Pages'
import { Posts } from '@/(CMS)/collections/Posts'
import { Surf } from '@/(CMS)/collections/Surfs'
import { CollectionConfig } from 'payload'
import { Notifications } from '@/(CMS)/collections/Notification'

export const collections: CollectionConfig[] = [Categories, Media, Notifications, Pages, Posts, Surf]