import type { CollectionConfig } from 'payload'

import { isAdmin, anyone, authenticated, isEditor } from '@/(CMS)/plugins/locker/access/accessCheckers'

export const Occupations: CollectionConfig = {
  slug: 'occupations', access: {
    create: authenticated, delete: isEditor || isAdmin, read: anyone, update: isAdmin || isEditor,
  }, admin: {
    useAsTitle: 'title',
  }, defaultPopulate: {
    title: true,
  }, fields: [{
    name: 'title', type: 'text', required: true, unique: true, index: true,
  }, {
    name: 'members', type: 'relationship', relationTo: 'members', hasMany: true, admin: {
      position: 'sidebar',
    }, virtual: true, index: true,
  }],
}
