// ensure there is always a `member` role
// do not let non-admins change roles
import type { Member } from '@/payload-types'
import { FieldHook, FieldHookArgs, SanitizedCollectionConfig } from 'payload'

export const protectRoles: FieldHook<Member> = ({ value, req: { user }, previousValue, operation }: FieldHookArgs & {
  collection: SanitizedCollectionConfig
}) => {
  if (!user) {
    if (operation === 'create') {
      return ['member']
    }
    return previousValue
  }
  if (user?.collection !== 'admins') {
    return operation === 'create' ? ['member'] : [...new Set(previousValue)]
  }
  const userRoles = new Set(value)
  userRoles.add('member')
  if (userRoles.has('editor')) userRoles.add('author')
  return [...userRoles]
}
