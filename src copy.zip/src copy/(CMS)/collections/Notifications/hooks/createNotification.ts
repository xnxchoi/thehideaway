import { getPayload } from 'payload'
import config from '@payload-config'
import { Notification } from '@/payload-types'

export type NotificationProps = Partial<Notification> & Pick<Notification, 'recipient' | 'content' | 'title' | 'actor'>

export const createNotification = async (options: NotificationProps) => {
  const payload = await getPayload({ config })
  try {
    // Set default values
    const notificationData: Omit<Notification, 'createdAt' | 'id' | 'updatedAt' | 'actionLink'> & Partial<Pick<Notification, 'actionLink'>> = {
      recipient: options.recipient,
      type: options.type || 'system',
      title: options.title,
      read: false,
      status: 'unread',
      importance: options.importance || 'normal',
      isSticky: options.isSticky || false,
    }
    if (options.thumbnail) notificationData.thumbnail = options.thumbnail
    if (options.actor) notificationData.actor = options.actor
    if (options.relatedContent) notificationData.relatedContent = options.relatedContent
    if (options.content) notificationData.content = options.content
    if (options.actionLink) notificationData.actionLink = options.actionLink
    if (options.groupId) notificationData.groupId = options.groupId
    // Create the notification
    const notification = await payload.create({
      collection: 'notifications', data: notificationData as Notification,
    })

    return notification
  } catch (error) {
    payload.logger.error(error, 'Error creating notification')
  }
}
