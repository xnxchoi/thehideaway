import type { CollectionConfig, Where } from 'payload'
import { slugField } from '@/(CMS)/fields/slug'
import { isAdmin, authenticated, isWriter, isEditor, standardUpdateAccess } from '@/(CMS)/plugins/locker/access/accessCheckers'

export const Categories: CollectionConfig = {
  slug: 'categories', access: {
    create: standardUpdateAccess, delete: standardUpdateAccess, read: authenticated, update: standardUpdateAccess,
  }, admin: {
    useAsTitle: 'title',
    hidden:({user})=>{
      if(!user)return true
      if(user?.collection==='admins')return false
      return true
    }
  }, defaultPopulate: {
    title: true,
  }, fields: [{
    name: 'title', type: 'text', required: true, index: true,
  }, {
    name: 'relatedCategories',
    type: 'relationship',
    relationTo: 'categories',
    hasMany: true,
    defaultValue: [],
    index: true,
  }, {
    name: 'author',
    type: 'relationship',
    relationTo: ['members','admins'],

    defaultValue: ({ req }) => {
      if (!req.user) {
        return []
      }
      return [{
        value:req.user?.id,
        relationTo:req.user?.collection
      }]
    },
    hasMany: false,
    index: true,
  }, {
    name: 'populatedAuthor', type: 'array', access: {
      update: () => false,
    }, admin: {
      disabled: true, readOnly: true,
    }, fields: [{
      name: 'id', type: 'text',
    }, {
      name: 'name', type: 'text',
    }],
  }, ...slugField('title', {
    checkboxOverrides: {
      admin: {
        readOnly: !(isWriter || isAdmin || isEditor),
      },
    },
  })],
}
