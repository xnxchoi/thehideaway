'use client'
import { useRPStore } from '@/providers/RP_Pro'
import { getMenuPagePreviewKey } from '@/utilities/Helpers'
import { useEffect } from 'react'

export const InitiateHeader = ({ header }) => {
  const setGlobalSettings = useRPStore((store) => store.setGlobalSettings)
  const setNavigationItems = useRPStore((store) => store.setNavigationPageItemData)
  const setNavigationPreviewMediaByKey = useRPStore((store) => store.setNavigationPreviewMediaByKey)
  useEffect(() => {
    if (header.navItems) {
      setGlobalSettings({ navigation: { navItems: header.navItems } })
      setNavigationItems(header.navItems)
      let k = {}
      header.navItems.forEach((l, index) => {
        if (!l.link || !l.link.type) return
        let ketu = ''
        if (l.link.type === 'custom') {
          if (!l.link.url) {
            console.error('link is external, but has no url', l)
            return
          }
          ketu = getMenuPagePreviewKey('pages', l.link.url.split('/')[1])
        } else {
          if (!l.link.reference || !l.link.reference.relationTo || !l.link.reference.value) {
            console.error('link is internal, but has invalid reference', l)
            return
          }
          ketu = getMenuPagePreviewKey(
            l.link.reference.relationTo,
            typeof l.link.reference.value === 'object'
              ? l.link.reference.value.slug
              : l.link.reference.value,
          )
        }
        k[ketu] = l.previewMedia
      })
      setNavigationPreviewMediaByKey(k)
    }
  }, [])
  return <></>
}
