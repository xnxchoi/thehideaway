import { useEffect, useState } from 'react'
import { useVoyageur } from '@/stores/RP_Voyageur'
import { useGSAP } from '@gsap/react'
import { Link } from '@/components/UX/Link'
import gsap from 'gsap'

export const CheckInButton = () => {
  const [isCheckInPage, setIsCheckInPage] = useState(false)
  const pathName = useVoyageur((state) => state.pathName)
  useEffect(() => {
    setIsCheckInPage(pathName.includes('check-in'))
  }, [pathName])
  useGSAP(() => {
      gsap.to('#checker',{
        autoAlpha:isCheckInPage?0:1,
        duration:0.3,
        ease:'Power4.easeInOut'
      })
  }, [isCheckInPage])
  return <Link id={'checker'} className={'rp_btn bt_sm text-[12px]'} href={'/check-in'}>Check In</Link>
}