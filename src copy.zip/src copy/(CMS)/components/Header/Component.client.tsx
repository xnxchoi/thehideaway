'use client'

import React, { useEffect, useRef, useState } from 'react'

import { Link, RP_Btn } from '@/components/UX/Link'
import { Logo } from '@/components/UX/Logo'
import { MenuButton } from '@/components/UX/Menu/MenuButton'
import type { Header } from '@/payload-types'
import { useHeaderTheme } from '@/providers/HeaderTheme'
import { useRPStore } from '@/providers/RP_Pro'
import { cn } from '@/lib/utils'
import { useLenis } from 'lenis/react'
import { useGSAP } from '@gsap/react'
import gsap from 'gsap'
import { useCurrentPage } from '@/hooks/useCurrentPage'
import { DarkmodeButton } from '@/components/UX/DarkMode/Darkmode'
import { SearchBar } from '@/components/UX/CommandKey/SearchBar'
import { InitiateHeader } from '@components/Header/InitiateHeader'
import { NotificationButton } from '@/components/UX/ExpandButton/notificationButton'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { RPTooltip } from '@/components/UX/tooltip'
import { concat } from 'lodash'
import { UserDropdown } from '@/components/UX/Dropdown/RPDropDown'
import { useTheme } from '@/providers/Theme'
import { useVoyageur } from '@/stores/RP_Voyageur'
import { CheckInButton } from '@components/Header/CheckInButton'
import { HeaderTransitionType } from '@/stores/RP_Ui'

interface HeaderClientProps {
  header: Header
}

export const HeaderClient: React.FC<HeaderClientProps> = (props) => {
  let { header } = props

  /* Storing the value in a useState to avoid hydration errors */
  const main = useRef<HTMLElement>(null!)
  const animateHeader = useRPStore((store) => store.animateHeader)
  const setHeaderAnimations=useRPStore((store)=>store.setHeaderAnimations)
  const theme =useTheme(r=>r.theme)
  const [the,setTheme]=useState(theme)
  const user = useRPStore(l => l.user)
  const notifications = useRPStore(l => l.notifications)
  const { headerTheme, setHeaderTheme } = useHeaderTheme()
  const setIsScrolling = useRPStore((l) => l.setScroll)

  useLenis((lenis)=>{
    setIsScrolling({ isScrolling: Boolean(lenis.isScrolling), direction: lenis.direction })
  })
  const inner = useRef<HTMLDivElement>(null!), l = useRef<HTMLDivElement>(null!), r = useRef<HTMLDivElement>(null!),
    c = useRef<HTMLAnchorElement>(null!)
  const scrollDirection = useRPStore((store) => store.scrollDirection)
  const isScrolling = useRPStore((store) => store.isScrolling)

  const navIsOpen = useRPStore((store) => store.navIsOpen)
  const [count, setCount] = useState(0)
  const slug=useVoyageur(r=>r.slug)
  const pageIsTransitioning=useRPStore(r=>r.pageIsTransitioning)

  const resetTL = useRef<GSAPTimeline>(null!)

  const headerAnimations=useRPStore(l=>l.headerAnimations)
  useEffect(() => {
    notifications.length > 0 ? setCount(notifications.length) : setCount(0)
  }, [notifications])
  useEffect(() => {
    notifications.length > 0 ? setCount(notifications.length) : setCount(0)
    setHeaderTheme(null)
  }, [])
  const [transitionType,setTransitionType]=useState<HeaderTransitionType>(null)
  useEffect(() => {
    console.log('setting transition type',slug)
      setTransitionType(slug.some(r=>r.includes('account')||r.includes('dashboard'))?'slide':null)
  }, [slug])
  useGSAP(() => {
    console.log(`animating header for ${slug}, page is transitioning?`,pageIsTransitioning)
   if(pageIsTransitioning){
     transitionType&&gsap.to([l.current,c.current,r.current],{   autoAlpha: 0, duration: 0.4, ease: 'Power4.easeInOut',})
     transitionType==='slide'&&gsap.to(inner.current,{duration: 0.4, ease: 'Power4.easeInOut', y: '-100%' ,delay:0.4})
     transitionType==='slide'&&(gsap.to(l.current, {duration: 0.4, ease: 'Power4.easeInOut',
       x: '-100%', y: '-100%',
     }),gsap.to(c.current, {duration: 0.4, ease: 'Power4.easeInOut', y: '-100%' }),gsap.to(r.current, {duration: 0.4, ease: 'Power4.easeInOut',
       x: '100%', y: '-100%',
     }))
   }else{
     if(!transitionType){

     gsap.killTweensOf([inner.current, l.current,c.current,r.current])
     gsap.to([inner.current,l.current,c.current,r.current],{autoAlpha: 1, x: 0, y: 0,duration: 0.4, ease: 'Power4.easeInOut'})
     }
   }
  }, { scope: main ,dependencies:[pageIsTransitioning]})
  useGSAP(() => {
    gsap.to(main.current, {
      duration: 0.4, zIndex: navIsOpen ? 249 : 245, delay: navIsOpen ? 0 : 0.2, ease: 'Power4.easeInOut',
    })
    gsap.to(fxRef.current, {
      duration: 0.4,
      ease: 'Power4.easeInOut',
      left: navIsOpen ? 0 : 10,
      right: navIsOpen ? 0 : 10,
      top: navIsOpen ? -20 : -10,
      delay: navIsOpen ? 0 : 0.2,
    })
  }, [navIsOpen])
  useEffect(() => {
    headerTheme && setTheme(headerTheme)||setTheme(theme)
  }, [headerTheme,theme])

  const fxRef = useRef<HTMLDivElement>(null!)
  return (
    <header data-theme={the} ref={main} id="rp-header" className={cn('sticky', { scrolling: isScrolling })} data-scroll={scrollDirection}
            data-themed={'background-color,color.z-index'}>
      <InitiateHeader header={header} />
      <div className="header-inner" ref={inner}>
        <div ref={fxRef}
             className="fixed pointer-events-none mx-auto right-[10px] left-[10px] top-[-10px] bottom-0 z-10">
          <div data-themed={'background-color'} className="top-fx-soft" />
          <div data-themed={'background-color'} className="top-fx" />
          <div data-themed={'background-color'} className="top-fx-bottom" />
        </div>
        <div id="l-side" className="z-20" ref={l}>
          <div className="flex">
            <MenuButton />
          </div>
        </div>
        <Link ref={c} id="c-side" href="/public" aria-label={'Logo'} className="header-main__logo z-20" style={{
          transform: 'translate(-50%, 0%)',
        }}>
          <Logo />
        </Link>
        <div id="r-side" ref={r} className="z-20">
          {user&&(<UserDropdown user={user}/>)||(<CheckInButton />)}
          <SearchBar />
          <NotificationButton count={count} />
          <DarkmodeButton />

        </div>
      </div>
    </header>)
}
