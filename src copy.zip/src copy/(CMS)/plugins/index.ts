import { formBuilderPlugin } from '@payloadcms/plugin-form-builder'
import { nestedDocsPlugin } from '@payloadcms/plugin-nested-docs'
import { redirectsPlugin } from '@payloadcms/plugin-redirects'
import { searchPlugin } from '@payloadcms/plugin-search'
import { seoPlugin } from '@payloadcms/plugin-seo'
import type { GenerateTitle, GenerateURL } from '@payloadcms/plugin-seo/types'
import { FixedToolbarFeature, HeadingFeature, lexicalEditor } from '@payloadcms/richtext-lexical'
import type { Plugin } from 'payload'

import { revalidateRedirects } from '@/hooks/revalidateRedirects'
import type { Member, Page, Post, Surf } from '@/payload-types'
import { beforeSyncWithSearch } from '@/(CMS)/search/beforeSync'
import { searchFields } from '@/(CMS)/search/fieldOverrides'
import { getServerSideURL } from '@/utilities/getURL'

const generateTitle: GenerateTitle<Post | Page | Surf | Member> = ({ doc }) => {
  if (doc) {
    if ('name' in doc && doc?.name) {
      return `${doc.name}`
    }
    if ('title' in doc && doc?.title) {
      return `${doc.title} | The Hideaway`
    }
  }
  return 'The Hideaway'
}

const generateURL: GenerateURL<Post | Page | Surf | Member> = ({ doc }) => {
  const url = getServerSideURL()
  if (doc) {
    if ('slug' in doc && doc?.slug) {
      if ('name' in doc) {
        return `${url}/@${doc.slug}`
      }
      return `${url}/${doc.slug}`
    }
  }
  return url
}

export const plugins: Plugin[] = [
  redirectsPlugin({
    collections: ['pages', 'posts'],
    overrides: {
      access:{
        create:({req:{user}})=>{
          if(user?.collection==='admins')return true
          return false
        },
        read:()=>true,
        update:({req:{user}})=>{
          if(user?.collection==='admins')return true
          return false
        },
      },
      admin:{
        hidden:({user})=>{
          if(user?.collection==='admins')return false
          return true
        }
      },
      // @ts-expect-error
      fields: ({ defaultFields }) => {
        return defaultFields.map((field) => {
          if ('name' in field && field.name === 'from') {
            return {
              ...field,
              admin: {
                description: 'You will need to rebuild the website when changing this field.',
              },
            }
          }
          return field
        })
      },
      hooks: {
        afterChange: [revalidateRedirects],
      },
    },
  }),

  seoPlugin({
    generateTitle,
    generateURL,
  }),
  formBuilderPlugin({
    fields: {
      payment: false,
    },
    formSubmissionOverrides:{
      access:{
        read:()=>true,

      },
      admin:{
        hidden:({user})=>{
          if(user?.collection==='admins')return false
          return true
        }
      },
    },
    formOverrides: {
      access:{
        create:({req:{user}})=>{
          if(user?.collection==='admins')return true
          return false
        },
        read:()=>true,
        update:({req:{user}})=>{
          if(user?.collection==='admins')return true
          return false
        },
      },
      admin:{
        hidden:({user})=>{
          if(user?.collection==='admins')return false
          return true
        }
      },
      fields: ({ defaultFields }) => {
        return defaultFields.map((field) => {
          if ('name' in field && field.name === 'confirmationMessage') {
            return {
              ...field,
              editor: lexicalEditor({
                features: ({ rootFeatures }) => {
                  return [
                    ...rootFeatures,
                    FixedToolbarFeature(),
                    HeadingFeature({ enabledHeadingSizes: ['h1', 'h2', 'h3', 'h4'] }),
                  ]
                },
              }),
            }
          }
          return field
        })
      },
    },
  }),
  searchPlugin({
    collections: ['posts', 'surf', 'members', 'categories', 'pages'],
    beforeSync: beforeSyncWithSearch,
    searchOverrides: {
      fields: ({ defaultFields }) => {
        return [...defaultFields, ...searchFields]
      },
      access:{

        read:()=>true,
        update:({req:{user}})=>{
          if(user?.collection==='admins')return true
          return false
        },
      },
      admin:{
        hidden:({user})=>{
          if(user?.collection==='admins')return false
          return true
        }
      },
    },
  }),
]
