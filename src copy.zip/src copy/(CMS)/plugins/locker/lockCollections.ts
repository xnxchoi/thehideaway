import {
  Access,
  AccessArgs,
  AccessResult,
  CheckboxField,
  CollectionConfig,
  CollectionSlug,
  deepCopyObjectSimple,
  deepMerge,
  type Field,
  JoinField,
  PolymorphicRelationshipField,
  RelationshipField,
  TabsField,
  Where,
} from 'payload'
import { LockerPluginConfig } from '@/(CMS)/plugins/locker/plugin'
import { findFieldByName, mergeFields } from '@/(CMS)/auth/rp_auth/payload/utils/mergeFields'
import { AllAccess } from './access'
import { lockBoxField } from '@/(CMS)/plugins/locker/fields/lockbox/ index'
import { allowListField } from '@/(CMS)/plugins/locker/fields/allowlist'
import { rolesToAuthority } from './fields/authority/utils'
import { authorityField } from '@/(CMS)/plugins/locker/fields/authority'
import { collections } from '@/(CMS)/collections'

const authorlessLockedReadAccess = (args: { slug: CollectionSlug }) => {
  const { slug } = args

  if (slug === 'pages') {
    return (args: AccessArgs): AccessResult => {
      const { req } = args
      const { user } = req
      if (user?.collection === 'admins') {
        return true
      }
      if (!user) {
        return {
          and: [{
            _status: {
              equals: 'published',
            },
          }, {
            or: [{
              locked: {
                not_equals: true,
              },
            }, {
              locked: {
                exists: false,
              },
            }, {
              authority: {
                exists: false,
              },
            }, {
              and: [{
                locked: {
                  equals: true,
                },
              }, {
                authority: {
                  less_than: 1,
                },
              }],
            }],
          }],
        }
      }
      let authorized = (user?.roles && rolesToAuthority(user.roles)) || 0
      const finalRead: Where & { or: Where[] } = {
        or: [{
          and: [{
            _status: {
              equals: 'published',
            },
          },

            {
              or: [{
                locked: {
                  not_equals: true,
                },
              }, {
                locked: {
                  exists: false,
                },
              }, {
                authority: {
                  exists: false,
                },
              }, {
                and: [{
                  locked: {
                    equals: true,
                  },
                }, {
                  or: [{
                    authority: {
                      less_than: authorized + 1,
                    },
                  }, {
                    'allowList.value': {
                      equals:user?.id,
                    },
                  }],
                }],
              }],
            }],
        }],
      }
      return finalRead
    }
  } else {
    return (args: AccessArgs): AccessResult => {
      const { req } = args
      const { user } = req
      if (user?.collection === 'admins') {
        return true
      }
      if (user?.roles?.some((role) => role === 'editor')) {
        return true
      }
      const authorized = (user?.roles && rolesToAuthority(user.roles)) || 0
      const finalRead: Where & { or: Where[] } = {
        or: [{
          and: [{
            _status: {
              equals: 'published',
            },
          }, {
            or: [{
              locked: {
                exists: false,
              },
            }, {
              locked: {
                equals: false,
              },
            }, {
              and: [{
                locked: {
                  equals: true,
                },
              }, {
                or: [{
                  'allowList.value': {
                      equals:user?.id,
                  },
                }, {
                  authority: {
                    less_than_equal: authorized,
                  },
                }],
              },

              ],
            }],
          }],
        }],
      }
      return finalRead
    }
  }
}
const standardLockedReadAccess = (args: { slug: CollectionSlug }): Access => {
  const { slug } = args
  return (args: AccessArgs): AccessResult => {
    const { req } = args
    const { user } = req
    if (!user) return {
      and: [{
        _status: {
          equals: 'published',
        },
      }, {
        or: [{
          locked: {
            not_equals: true,
          },
        }, {
          and: [{
            locked: {
              equals: true,
            },
          }, {
            or: [{
              authority: {
                less_than: 1,
              },
            }],
          }],
        }],
      }],
    }
    if (user?.collection === 'admins') {
      return true
    }
    if (user?.roles?.some((role) => role === 'editor')) {
      return true
    }
    const authorized = (user?.roles && rolesToAuthority(user.roles)) || 0

    const reader: Where & { or: Where[] } = {
      or: [{
        and: [{
          _status: {
            equals: 'published',
          },
        }, {
          or: [{
            locked: {
              not_equals: true,
            },
          },

            {
              and: [{
                locked: {
                  equals: true,
                },
              }, {
                or: [{
                  authority: {
                    less_than: authorized + 1,
                  },
                }, {
                  'allowList.value': {
                    equals:user?.id,
                  },
                }],
              }],
            }],
        }],
      }],
    }
    if (user?.roles?.some((role) => role === 'author')) {
      reader.or.push({
        and: [{
          'author.value': {
            equals: user?.id,
          },
        }, {
          'author.relationTo': {
            equals: user?.collection,
          },
        }],
      })
    }
    return reader
  }
}
const lockedReadAccess = (args: { collection: CollectionConfig }): Access => {
  const { collection } = args
  if ('author' in collection.fields) {
    return standardLockedReadAccess({ slug: collection.slug as CollectionSlug })
  } else {
    return authorlessLockedReadAccess({ slug: collection.slug as CollectionSlug })
  }
}

export const lockCollections = (collections: CollectionConfig[], pluginOptions: LockerPluginConfig): void => {
  // Get or create users collection
  const targetCollectionSlugs = pluginOptions.targetCollections || []
  const usersCollection = pluginOptions.userCollections || ['members', 'admins']

  if (!targetCollectionSlugs.some((slug) => slug === 'pages')) {
    targetCollectionSlugs.push('pages')
  }
  const implementedCollections: CollectionSlug[] = []
  targetCollectionSlugs.forEach((slug) => {
    let collection = collections?.find((c) => c.slug === slug)
    if (!collection) {
      collection = {
        slug: slug, admin: {
          useAsTitle: 'name',
        }, fields: [],
      }
      collections.push(collection)
    }
    const access = AllAccess[slug]
    const { mergedFields, restFields } = mergeFields({
      path: slug, baseFields: [lockBoxField({
        collection: slug,
      }), allowListField({
        collection: slug,
      }), authorityField({
        collection: slug,
      })], patchFields: collection.fields, // User defined fields
    })
    collection.fields = [...mergedFields, ...restFields]

    implementedCollections.push(slug)
  })
}
