import { AccessArgs, AccessResult, CollectionSlug, Where } from 'payload'
import { LockedAccessCollection } from '@/(CMS)/plugins/locker/access/index'

export const lockedOrQ = ({ req: { user } }: AccessArgs): boolean | Where[] => {
  const orArgs: Where[] = [
    {
      locked: {
        equals: false,
      },
    },
    {
      locked: {
        exists: false,
      },
    },
  ]
  if (user) {
    if (user.collection === 'admins') {
      return true
    }

    orArgs.push({
      and: [
        {
          locked: {
            equals: true,
          },
        },
        {
          'allowList.value': {
            equals:user?.id,
          },
        },
      ],
    })
  }
  return orArgs
}
export const lockedRead = (
  props: AccessArgs & { collection: LockedAccessCollection},
): AccessResult => {
  const { req, collection } = props
  const { user } = req

  const orArgs: Where[] = [
    {
      locked: {
        equals: false,
      },
    },
    {
      locked: {
        exists: false,
      },
    },
  ]
  if (user) {
    if (user.collection === 'admins') {
      return true
    }

    if (collection !== 'pages') {
      if (user?.roles?.some((role) => role === 'editor')) {
        return true
      }
    }

    orArgs.push({
      and: [
        {
          locked: {
            equals: true,
          },
        },
        {
          'allowList.value':{
            equals:user?.id
          }
        },
      ],
    })
  }
  return {
    or: [
      {
        and: [
          {
            _status: {
              equals: 'published',
            },
          },
          {
            or: orArgs,
          },
        ],
      },
      (collection !== 'pages' &&
        user?.roles?.some((role) => role === 'author') && {
          'author.value': {
              equals: user?.id,
          },
        }) ||
        {},
    ],
  }
}
