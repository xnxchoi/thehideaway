import {
  isAdmin,
  authenticated,
  isWriter,
  standardUpdateAccess,
  standardCreateAccess,
  standardReadAccess,
  anyone,
  onlySelfOrAdmin,
  isAdminOrEditor,
} from '@/(CMS)/plugins/locker/access/accessCheckers'
import { CollectionConfig, CollectionSlug, Where } from 'payload'
import { rolesToAuthority } from '../fields/authority/utils'

export const pagesAccess: CollectionConfig['access'] = {
  create: isAdmin, delete: isAdmin, update: isAdmin, read: anyone,
}
export const postsAccess: CollectionConfig['access'] = {
  create: standardCreateAccess, delete: standardUpdateAccess, read: standardReadAccess, update: standardUpdateAccess,
}
export const surfsAccess: CollectionConfig['access'] = {
  create: standardCreateAccess, delete: standardUpdateAccess, read: standardReadAccess, update: standardUpdateAccess,

}
export const mediaAccess: CollectionConfig['access'] = {
  create: authenticated, delete: standardUpdateAccess, read: ({ req: { user } }) => {
    if (user?.collection === 'admins') return true
    return {
      or: [{
        and: [{ _status: { equals: 'published' } }, {
          or: [{
            locked: {
              not_equals: 'true',
            },
          }, {
            and: [{
              locked: {
                equals: true,
              },
            }, {
              or: [{
                'allowList.value': {
                  equals: user?.id,
                },
              }, {
                authority: {
                  less_than: (user && user.roles && rolesToAuthority(user.roles) || 0) + 1,
                },
              }],
            }],
          }],
        }],
      }, {
        'author.value': {
          equals: user?.id,
        },
      }],
    } as Where
  }, update: standardUpdateAccess,
}
export const categoriesAccess: CollectionConfig['access'] = {
  create: isAdminOrEditor, delete: isAdminOrEditor, read: anyone, update: isAdminOrEditor,
}
export const membersAccess: CollectionConfig['access'] = {
  read: standardReadAccess, update: onlySelfOrAdmin, create: isAdmin, delete: onlySelfOrAdmin,
}
export type LockedAccessCollection = Extract<CollectionSlug, 'pages' | 'posts' | 'surf' | 'media' | 'categories' | 'members'>
export type CollectionAccessMap<T extends LockedAccessCollection> = {
  [key in T]: CollectionConfig<T>['access']
}
export const AllAccess = {
  pages: pagesAccess,
  posts: postsAccess,
  surf: surfsAccess,
  media: mediaAccess,
  categories: categoriesAccess,
  members: membersAccess,
}