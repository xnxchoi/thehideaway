import {
  Access,
  AccessArgs,
  FieldAccess,
  RequestContext as OriginalRequestContext,
  Where,
} from 'payload'
import type { Admin, Member } from '@/payload-types'
import { Flatten } from '@/utilities/typeUtilities'

type isAuthenticated = (args: AccessArgs<Member> | AccessArgs<Admin>) => boolean

type MemberRoles = NonNullable<Flatten<Member['roles']>>
type UserRoles = MemberRoles | 'admins'
declare module 'payload' {
  //@ts-ignore
  export interface RequestContext extends OriginalRequestContext {
    role?: UserRoles
    user?: Member | Admin
  }
}
export const checkRole = (role: UserRoles, user: AccessArgs['req']['user']): boolean => {
  if (!user) return false
  if (user?.collection === 'admins' && role === 'admins') return true
  if (user?.collection === 'admins') {
    return true
  }
  return !!user.roles?.some((individualRole) => {
    return individualRole === role
  })
}
export const isAdmin: Access = ({ req: { user } }) => {
  return user?.collection === 'admins'
}
export const isWriter: Access = ({ req: { user } }) => checkRole('author', user)
export const isEditor: Access = ({ req: { user } }) => checkRole('editor', user)
export const isAdminOrEditor: Access = ({ req: { user } }) =>
  checkRole('editor', user) || checkRole('author', user)
/**
 *  Collection accessor for read
 *  For collections with author properties
 *
 */
export const standardReadAccess: Access = ({ req: { user } }: AccessArgs) => {
  if (user) {
    return {
      or: [
        {
          _status: {
            equals: 'published',
          },
        },
        {
          'author.value':{
            equals: user?.id,
          }
        },
      ],
    } as Where
  }
  return {
    _status: {
      equals: 'published',
    },
  }
}
export const isAuthor: FieldAccess = ({ data, req: { user } }) => {
  if (!user) return false
  if (user?.collection === 'admins') return true
  return !!data?.author?.some((au) => {
    if (au.value === user?.id && au.relationTo === user?.collection) return true
  })
}
export const isAuthorOrEditor = ({ data, req: { user } }) => {
  if (!user) return false
  if (user?.collection === 'admins') return true
  if (user?.roles?.some((role) => role === 'editor')) return true
  return !!data?.author?.some((au) => {
    if (au.value === user?.id && au.relationTo === user?.collection) return true
  })
}
/**
 *  Accessor for modifications
 *  For collections with author properties
 *  Either be an admin/editor, or the author of the document
 *
 */
export const standardUpdateAccess: Access = ({ req: { user } }) => {
  if (!user) return false
  if (user?.collection === 'admins') return true
  if (user?.roles?.some((role) => role === 'editor')) return true
  return {
    'author.value': {
      equals: user?.id,
    }
  }
}
/**
 * Accessor for creation
 * Either be an admin, editor, or author
 */
export const standardCreateAccess: Access = ({ req: { user } }) => {

  if (user?.collection === 'admins') return true
  if(user?.roles?.some((role) => role === 'author' || role === 'editor'))return true
  return false
}

export const anyone = () => true

export const authenticated = ({ req: { user } }) => {
  return Boolean(user)
}
/**
 *  Accessor for personally sensitive data
 *  Only allow admins and the user themselves
 *  Note that editors are not allowed!
 */
export const onlySelfOrAdmin: Access = ({ req: { user } }) => {
  if (!user) return false
  if (user?.collection === 'admins') return true
  return {
    id: {
      equals: user?.id,
    },
  }
}
