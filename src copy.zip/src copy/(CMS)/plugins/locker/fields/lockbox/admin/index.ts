import { CheckboxField, CollectionSlug } from 'payload'
import { defaultCondition, pagesCondition } from './condition'

/**
 * Creates admin configuration for lockbox field based on collection type
 * @param props Configuration properties
 * @returns Admin configuration for the lockbox field
 */
export const lockboxFieldAdmin = (props: {
  collection: CollectionSlug
  overrides?: Partial<CheckboxField['admin']>
}): CheckboxField['admin'] => {
  const { collection, overrides = {} } = props

  // Common configuration for all collections
  const baseConfig: CheckboxField['admin'] = collection === 'pages' ? {
    position: 'sidebar', condition: pagesCondition,
  } : {
    position: 'sidebar', condition: defaultCondition,
  }

  // Merge with any overrides provided
  return {
    ...baseConfig, ...overrides,
  }
}
