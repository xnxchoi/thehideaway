import { CheckboxField, CollectionConfig, Condition } from 'payload'

/**
 * Field admins condition for locked checkbox
 *
 */
export const pagesCondition: Condition = ( data, siblingData, {user}) => {
  if (!user) return false
  if (user?.collection === 'admins') return true
  return false
}
export const defaultCondition: Condition = ( data, siblingData, {user }) => {
  if (!user) return false
  if (user?.collection === 'admins' || user?.roles?.some((role) => role === 'editor'))
    return true
  if (user?.roles?.some((role) => role === 'author')) {
    if (
      data?.author?.some((au) => {
        return au.value === user?.id && au.relationTo === user?.collection
      })
    ) {
      return true
    }
  }
  return false
}
