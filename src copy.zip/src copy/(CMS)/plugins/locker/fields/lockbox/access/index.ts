import { Access, CollectionSlug, CheckboxField } from 'payload'
import {
  createPagesCheckboxFieldAcess,
  createStdCheckboxFieldAccess,
  updatePagesCheckboxFieldAcess,
} from '../../access'
import { updateStdCheckboxFieldAccess } from '../../access'

export const lockboxFieldAccess = (args: {
  collection: CollectionSlug
  overrides?: Partial<CheckboxField['access']>
}): CheckboxField['access'] => {
  const { collection, overrides = {} } = args
  return {
    read: () => true,
    update: collection === 'pages' ? updatePagesCheckboxFieldAcess : updateStdCheckboxFieldAccess,
    create: collection === 'pages' ? createPagesCheckboxFieldAcess : createStdCheckboxFieldAccess,
    ...overrides,
  }
}
