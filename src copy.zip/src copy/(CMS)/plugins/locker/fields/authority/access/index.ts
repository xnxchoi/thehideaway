import { CollectionSlug, RadioField } from 'payload'
import {
  createPagesRadioFieldAccess,
  createStdRadioFieldAccess,
  updatePagesRadioFieldAccess,
  updateStdRadioFieldAccess,
} from '../../access'

export const authorityFieldAccess = (props: {
  collection: CollectionSlug
  overrides?: Partial<RadioField['access']>
}): RadioField['access'] => {
  const { collection, overrides } = props
  return {
    read: () => true,
    update: collection === 'pages' ? updatePagesRadioFieldAccess : updateStdRadioFieldAccess,
    create: collection === 'pages' ? createPagesRadioFieldAccess : createStdRadioFieldAccess,
    ...overrides,
  }
}
