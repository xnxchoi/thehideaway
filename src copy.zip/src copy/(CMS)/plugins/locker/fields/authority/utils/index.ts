export const roleToAuthority = (role: 'member' | 'patron' | 'author' | 'editor'): number => {
  switch (role) {
    case 'patron':
      return 1
    case 'author':
      return 2
    case 'editor':
      return 3
    default:
      return 0
  }
}
export const authorityToRole = (authority: number): Role => {
  switch (authority) {
    case 0:
      return 'member'
    case 1:
      return 'patron'
    case 2:
      return 'author'
    case 3:
      return 'editor'
    default:
      return 'member'
  }
}
export type Role = 'member' | 'patron' | 'author' | 'editor'
export const rolesToAuthority = (roles: Role[]): number => {
  return roles.reduce((acc, role) => {
    return Math.max(acc, roleToAuthority(role))
  }, 0)
}
