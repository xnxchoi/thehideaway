import { CollectionSlug, Condition, NumberField } from 'payload'
/**
 * Field admins condition for locked checkbox
 *
 */
const pagesCondition: Condition = (data,siblingData,{user}) => {
  if (!user) return false
  return user?.collection === 'admins'
}
const defaultCondition: Condition = ( data, siblingData,{user }) => {
  if (!user) return false
  if (user?.collection === 'admins' || user?.roles?.some((role) => role === 'editor'))
    return true
  if (user?.roles?.some((role) => role === 'author')) {
    if (
      data?.author?.some((au) => {
        return au.value === user?.id && au.relationTo === user?.collection
      })
    ) {
      return true
    }
  }
  return false
}
export const authorityFieldAdmin = (props: {
  collection: CollectionSlug
  overrides?: Partial<NumberField['admin']>
}): NumberField['admin'] => {
  const { collection, overrides = {} } = props
  return collection === 'pages' ?{
    position: 'sidebar',
    condition: pagesCondition,
    // components: {
    //   Field: {
    //     path: '@/plugins/locker/fields/authority/component',
    //     clientProps:{
    //       path:'authority'
    //     }
    //   },
    // },
  } : {
    position: 'sidebar',
    condition: defaultCondition,
    components: {
      Field: {
        path: '@/(CMS)/plugins/locker/fields/authority/component',
        clientProps:{
          path:'authority'
        }
      },
    },
  }
}
