import { FieldAccessArgs } from 'node_modules/payload/dist/fields/config/types'
import { FieldAccess } from 'payload'

type AuthorAdminEditorProps = FieldAccessArgs & {
  editor?: boolean, author?: boolean,
}
const isAuthorOrAdmin = (props: AuthorAdminEditorProps) => {
  const { req, data, editor, author: doAuthor } = props
  if (req.user?.collection === 'admins') return true
  if (editor) {
    if (!!(req.user?.roles?.some((v) => v === 'editor'))) return true
  }
  if (doAuthor) {
    if (!!(req.user?.roles?.some(v => v === 'author'))) return true
  }
  let author = data?.author
  if (Array.isArray(author)) {
    author = author[0]
  }
  if (typeof author === 'object') {
    author = author?.value
  }
  return !!(req.user?.roles?.some((v) => v === 'author') && author === req.user?.id)
}
const adminAccess = ({ req }: FieldAccessArgs) => ((req.user?.collection === 'admins'))
export const createStdRadioFieldAccess: FieldAccess = ({ req }) => {
  return isAuthorOrAdmin({ req, editor: true ,author:true})
}
export const updateStdRadioFieldAccess: FieldAccess = ({ req, data }) => {
  return isAuthorOrAdmin({ req, data, editor: true })
}

export const createPagesRadioFieldAccess: FieldAccess = ({ req }) => {
  return adminAccess({req})
}
export const updatePagesRadioFieldAccess: FieldAccess = ({ req }) => {
  return adminAccess({req})
}
export const updateStdCheckboxFieldAccess: FieldAccess = ({ req, data }) => {
return isAuthorOrAdmin({ req, data, editor: true })
}
export const createStdCheckboxFieldAccess: FieldAccess = ({ req }) => {
  return isAuthorOrAdmin({ req, editor: true ,author:true})
}

export const createPagesCheckboxFieldAcess: FieldAccess = ({ req }) => {
 return adminAccess({req})
}
export const updatePagesCheckboxFieldAcess: FieldAccess = ({ req }) => {
  return adminAccess({req})
}

//For fields that are relationship fields, and is part of a collection with the 'author' property
export const updateStdRelFieldAccess: FieldAccess = ({ req, data }) => {
  return isAuthorOrAdmin({ req, data ,editor:true})
}
export const createStdRelFieldAccess: FieldAccess = ({ req }) => {
  return isAuthorOrAdmin({ req, editor: true ,author:true})
}
export const createPagesRelFieldAcess: FieldAccess = ({ req }) => {
return adminAccess({req})
}
export const updatePagesRelFieldAcess: FieldAccess = ({ req }) => {
return adminAccess({req})
}
