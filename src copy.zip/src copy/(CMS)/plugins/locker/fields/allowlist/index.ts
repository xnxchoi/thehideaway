import { CollectionSlug, DefaultValue, PolymorphicRelationshipField } from 'payload'
import { allowListFieldAdmin } from '@/(CMS)/plugins/locker/fields/allowlist/admin'
import { allowListFieldAccess } from './access'

const defaultValue: DefaultValue = ({ user }) => {
  if (!user) return []
  return [
    {
      value: user?.id,
      relationTo: user?.collection,
    },
  ]
}
export const allowListField = (props: {
  collection: CollectionSlug
  overrides?: Partial<PolymorphicRelationshipField>
}): PolymorphicRelationshipField => {
  const { collection, overrides } = props
  let config = {
    name: 'allowList',
    type: 'relationship',
    relationTo: ['admins', 'members'],
    hasMany: true,
    index: true,
    defaultValue: defaultValue,
    admin: allowListFieldAdmin({ collection, overrides: overrides?.admin || {} }),
    access: allowListFieldAccess({ collection, overrides: overrides?.access || {} }),
    ...overrides,
  }
  return config as PolymorphicRelationshipField
}
