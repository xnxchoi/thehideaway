import { FieldHook, FieldHookArgs, ValueWithRelation } from 'payload'

export const sanitizeAllowList: FieldHook = async (args: FieldHookArgs) => {
  const { req, value, data, operation, originalDoc, previousValue, collection } = args
  const { user, payload } = req
  const allowedList = value as ValueWithRelation[]
  if (operation === 'create') {
    if (!user) return []
    if (collection?.slug === 'pages' && user.collection !== 'admins') {
      return []
    }
    let allowList = new Set(allowedList)
    return [...allowList]
  }
  if (collection?.slug === 'pages' && user?.collection !== 'admins') {
    return previousValue
  }
  const filteredList = allowedList.filter(async (item) => {
    if (item.relationTo === 'admins') {
      return true
    }
    const doc = await payload.findByID({
      collection: item.relationTo,
      id: item.value,
      select: {
        id: true,
        roles: true,
      },
    })
    if (doc && 'roles' in doc) {
      if (doc.roles?.some((role) => role === 'editor' || role === 'author')) {
        return true
      }
    }
    return false
  })
  return filteredList
}
