import { CollectionSlug, PolymorphicRelationshipField } from 'payload'
import {
  createPagesRelFieldAcess,
  createStdRelFieldAccess,
  updatePagesRelFieldAcess,
  updateStdRelFieldAccess,
} from '../../access'

export const allowListFieldAccess = (props: {
  collection: CollectionSlug
  overrides?: Partial<PolymorphicRelationshipField['access']>
}): PolymorphicRelationshipField['access'] => {
  const { collection, overrides } = props
  return {
    read: () => true,
    update: collection === 'pages' ? updatePagesRelFieldAcess : updateStdRelFieldAccess,
    create: collection === 'pages' ? createPagesRelFieldAcess : createStdRelFieldAccess,
    ...overrides,
  }
}
