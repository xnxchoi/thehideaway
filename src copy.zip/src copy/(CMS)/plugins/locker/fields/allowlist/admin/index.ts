import { CollectionSlug, Condition, PolymorphicRelationshipField } from 'payload'

/**
 * Field admins condition for locked checkbox
 *
 */
const pagesCondition: Condition = (data,siblingData,{ user }) => {
  if (!user) return false
  return user?.collection === 'admins'
}
const defaultCondition: Condition = (data, siblingData, { user}) => {
  if (!user) return false
  if (user?.collection === 'admins' || user?.roles?.some((role) => role === 'editor'))
    return true
  if (user?.roles?.some((role) => role === 'author')) {
    if (
      data?.author?.some((au) => {
        return au.value === user?.id && au.relationTo === user?.collection
      })
    ) {
      return true
    }
  }
  return false
}
export const allowListFieldAdmin = (props: {
  collection: CollectionSlug
  overrides?: Partial<PolymorphicRelationshipField['admin']>
}): PolymorphicRelationshipField['admin'] => {
  const { collection, overrides = {} } = props
  return {
    position: 'sidebar',
    condition: collection === 'pages' ? pagesCondition : defaultCondition,
    ...overrides,
  }
}
