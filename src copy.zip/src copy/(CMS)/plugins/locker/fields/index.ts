import { LockedAccessCollection } from '@/(CMS)/plugins/locker/access'
import {
  CheckboxField,
  CollectionConfig,
  Field,
  PayloadRequest,
  PolymorphicRelationshipField,
} from 'payload'
import { lockBoxField } from '@/(CMS)/plugins/locker/fields/lockbox/ index'

type LockerOverride = {
  locked?: Partial<CheckboxField>
  allowlist?: Partial<PolymorphicRelationshipField>
  collection?: Partial<CollectionConfig>
}

export const lockerFields = (props: {
  collection: CollectionConfig<LockedAccessCollection>
  overrides: LockerOverride
  req: PayloadRequest
}) => {
  const { collection, overrides } = props
  const col = collection.slug as LockedAccessCollection
  const { locked, allowlist, collection: collectionOverride } = overrides
  const fields: Field[] = [
    lockBoxField({ collection: col, overrides: locked }),
    ...collection.fields,
  ]
}
