'use client'

import { Button, FieldLabel, TextInput, useField, useForm, useFormFields } from '@payloadcms/ui'
import { PolymorphicRelationshipField } from 'payload'
import { useCallback, useEffect } from 'react'
import {
  RelationshipComponent
} from '@payloadcms/richtext-lexical/dist/features/relationship/client/components/RelationshipComponent'

type LockerUIComponentProps = {
  checkboxFieldPath: string
  relationshipFieldPath: string
  numberFieldPath:string
}

export const LockerComponent: React.FC<LockerUIComponentProps> = ({
  checkboxFieldPath: checkboxFieldPathFromProps,
  relationshipFieldPath: fieldToUse,
  numberFieldPath: numberFieldPathFromProps,

}) => {
  const { value, setValue } = useField<PolymorphicRelationshipField>({ path:  fieldToUse})
  const {value:numberValue,setValue:setNumberValue}=useField<number>({path: numberFieldPathFromProps})
  const {value:relationshipValue,setValue:setRelationshipValue}=useField<PolymorphicRelationshipField>({path: fieldToUse})
  const { dispatchFields } = useForm()

  // The value of the checkbox
  // We're using separate useFormFields to minimise re-renders
  const checkboxValue = useFormFields(([fields]) => {
    return fields[checkboxFieldPathFromProps]?.value as string
  })


  useEffect(() => {
    if (checkboxValue) {

      } else{
      setRelationshipValue([])
      setNumberValue(0)
    }
  }, [ checkboxValue, setValue, value])

  const handleLock = useCallback((e) => {
    e.preventDefault()

    dispatchFields({
      type: 'UPDATE', path: checkboxFieldPathFromProps, value: !checkboxValue,
    })
  }, [checkboxValue, checkboxFieldPathFromProps, dispatchFields])



  return (<div className="field-type slug-field-component">
      <div className="label-wrapper">
        <FieldLabel htmlFor={`field-${checkboxFieldPathFromProps}`} label={'게시글'} />
        <Button className="lock-button" buttonStyle="none" onClick={handleLock}>
          {checkboxValue ? '공개하기' : '잠그기'}
        </Button>
      </div>
      <RelationshipComponent data={}/>
    </div>)
}
