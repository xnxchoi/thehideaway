'use client'

import React, { useEffect, useState } from 'react'
import { useField, Button } from '@payloadcms/ui'
import Select from 'react-select'

const authorityLevels = [
  { label: 'Registered Members', value: 1 },
  { label: 'Subscribed Patrons', value: 2 },
  { label: 'Authors', value: 3 },
]

const AccessControlField: React.FC<{ user: any }> = ({ user }) => {
  const { value: locked, setValue: setLocked } = useField<boolean>({ path: 'locked' })
  const { value: authorityEnabled, setValue: setAuthorityEnabled } = useField<boolean>({
    path: 'authority.enabled',
  })
  const { value: authorityLevel, setValue: setAuthorityLevel } = useField<number>({
    path: 'authority.level',
  })
  const { value: allowListEnabled, setValue: setAllowListEnabled } = useField<boolean>({
    path: 'allowList.enabled',
  })
  const { value: allowListUsers, setValue: setAllowListUsers } = useField<string[]>({
    path: 'allowList.users',
  })

  const [options, setOptions] = useState<any[]>([])

  useEffect(() => {
    if (!locked) {
      setAuthorityEnabled(false)
      setAuthorityLevel(null)
      setAllowListEnabled(false)
      setAllowListUsers([])
    }
  }, [locked])

  useEffect(() => {
    const fetchUsers = async () => {
      const res = await fetch(
        `/api/members?where[id][not_equals]=${user.id}&where[protected][not_equals]=true`,
      )
      const data = await res.json()
      setOptions(data.docs.map((user) => ({ value: user.id, label: user.name })))
    }
    fetchUsers()
  }, [user.id])

  const statusLabel = () => {
    if (!locked) return 'This post is publicly accessible.'
    const parts: string[] = []
    if (allowListEnabled && allowListUsers.length > 0) parts.push(`selected users`)
    if (authorityEnabled && authorityLevel) {
      const authority = authorityLevels.find((al) => al.value === authorityLevel)?.label
      if (authority) parts.push(authority)
    }
    return parts.length
      ? `This post will be visible to ${parts.join(' and ')}.`
      : 'This post will be visible to you only.'
  }

  return (
    <div className="flex flex-col gap-4">
      <label className="flex items-center gap-2">
        <input type="checkbox" checked={locked} onChange={(e) => setLocked(e.target.checked)} />
        Locked
      </label>

      <div
        className={`transition-opacity duration-300 ${locked ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}
      >
        <div>{statusLabel()}</div>

        <div className="flex flex-col gap-2">
          <div>Authority Level:</div>
          <div className="flex gap-2">
            {authorityLevels.map((level) => (
              <Button
                key={level.value}
                variant={authorityLevel === level.value ? 'default' : 'outline'}
                onClick={() => {
                  setAuthorityLevel(level.value)
                  setAuthorityEnabled(true)
                }}
              >
                {level.label}
              </Button>
            ))}
          </div>

          <div className="flex gap-2 items-center">
            <label className="flex items-center gap-2">
              <input
                type="checkbox"
                checked={allowListEnabled}
                onChange={(e) => setAllowListEnabled(e.target.checked)}
              />
              Enable Allow List
            </label>
            <div className="flex-1">
              <Select
                isMulti
                isDisabled={!allowListEnabled}
                options={options}
                value={options.filter((option) => allowListUsers.includes(option.value))}
                onChange={(selected) => {
                  setAllowListUsers(selected.map((s) => s.value))
                }}
              />
            </div>
            {allowListUsers.length > 0 && (
              <Button variant="outline" onClick={() => setAllowListUsers([])}>
                Reset
              </Button>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

export default AccessControlField
