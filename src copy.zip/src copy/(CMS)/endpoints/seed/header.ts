import { Header } from '@/payload-types'

export const content: Partial<Header> = {
  navItems: [],
  createdAt: '2024-11-30T08:37:15.409Z',
  updatedAt: '2025-02-03T10:56:16.195Z',
}
