import type { CollectionSlug, File, Payload } from 'payload'

import { image1 } from './images/img1'
import { image2 } from './images/img2'
import { image3 } from './images/img3'
import { image4 } from './images/img4'
import { image5 } from './images/img5'
import { image6 } from './images/img6'
import { image7 } from './images/img7'
import { post1 } from './contents/post1'
import { post2 } from './contents/post2'
import { post3 } from './contents/post3'
import { post4 } from './contents/post4'
import { post5 } from './contents/post5'
import { post6 } from './contents/post6'
import { post7 } from './contents/post7'

const collections: CollectionSlug[] = ['media', 'posts', 'categories']


export const seedRP = async ({ payload }: { payload: Payload }): Promise<void> => {
  payload.logger.info('Seeding database...')

  payload.logger.info(`— Clearing media...`)
  payload.logger.info(`— Clearing collections and globals...`)

  for (const collection of collections) {
    await payload.delete({
      collection, where: {
        id: {
          exists: true,
        },
      },
    })
  }

  payload.logger.info(`— Seeding demo author and user...`)


  // const demoAdmin = await payload.create({
  //   collection: 'admins', data: {
  //     name: 'Claude Severin', email: 'hideaway.seoul@gmail.com', password: 'LO$T1n$eou1__',
  //   },
  // })
  // const demoAuthor = await payload.create({
  //   collection: 'members', data: {
  //     name: 'Yong Jang Seo', email: 'yongjangseo@gmail.com', slug: 'yongjang-seo',
  //   },
  // })
  let demoAuthorID: number | string = '8f3072ad-aa5e-4593-af5e-86b944195c9f'
  // let demoAdminID: number | string = demoAdmin.id
  // let demoAuthorID: number | string = 'f0e1ea81-87db-41c6-813e-25fe37c10b78'
  payload.logger.info(`— Seeding media...`)
  const [image1Buffer, image2Buffer, image3Buffer, image4Buffer, image5Buffer, image6Buffer, image7Buffer] = await Promise.all([fetchFileByURL(`${process.env.NEXT_PUBLIC_SERVER_URL}/images/img1.jpg`), fetchFileByURL(`${process.env.NEXT_PUBLIC_SERVER_URL}/images/img2.jpg`), fetchFileByURL(`${process.env.NEXT_PUBLIC_SERVER_URL}/images/img3.png`), fetchFileByURL(`${process.env.NEXT_PUBLIC_SERVER_URL}/images/img4.png`), fetchFileByURL(`${process.env.NEXT_PUBLIC_SERVER_URL}/images/img5.jpg`), fetchFileByURL(`${process.env.NEXT_PUBLIC_SERVER_URL}/images/img6.jpg`), fetchFileByURL(`${process.env.NEXT_PUBLIC_SERVER_URL}/images/img7.jpg`)])

  payload.logger.info(`— Seeding image1...`)
  const image1Doc = await payload.create({
    collection: 'media', data: image1, file: image1Buffer,
  }).then((res) => {
    payload.logger.info(`image1Doc: ${res.id}`)
    return res
  }).catch((err) => {
    payload.logger.error({
      message: 'Error seeding image1', error: err,
    })
  })
  payload.logger.info(`— Seeding image2...`)
  const image2Doc = await payload.create({
    collection: 'media', data: image2, file: image2Buffer,
  }).then((res) => {
    payload.logger.info(`image2Doc: ${res.id}`)
    return res
  }).catch((err) => {
    payload.logger.error({
      message: 'Error seeding image2', error: err,
    })
  })
  payload.logger.info(`— Seeding image3...`)
  const image3Doc = await payload.create({
    collection: 'media', data: image3, file: image3Buffer,
  }).then((res) => {
    payload.logger.info(`image3Doc: ${res.id}`)
    return res
  }).catch((err) => {
    payload.logger.error({
      message: 'Error seeding image3', error: err,
    })
  })
  payload.logger.info(`— Seeding image4...`)
  const image4Doc = await payload.create({
    collection: 'media', data: image4, file: image4Buffer,
  }).then((res) => {
    payload.logger.info(`image4Doc: ${res.id}`)
    return res
  }).catch((err) => {
    payload.logger.error({
      message: 'Error seeding image4', error: err,
    })
  })
  payload.logger.info(`— Seeding image5...`)
  const image5Doc = await payload.create({
    collection: 'media', data: image5, file: image5Buffer,
  }).then((res) => {
    payload.logger.info(`image5Doc: ${res.id}`)
    return res
  }).catch((err) => {
    payload.logger.error({
      message: 'Error seeding image5', error: err,
    })
  })
  payload.logger.info(`— Seeding image6...`)
  const image6Doc = await payload.create({
    collection: 'media', data: image6, file: image6Buffer,
  }).then((res) => {
    payload.logger.info(`image6Doc: ${res.id}`)
    return res
  }).catch((err) => {
    payload.logger.error({
      message: 'Error seeding image6', error: err,
    })
  })
  payload.logger.info(`— Seeding image7...`)
  const image7Doc = await payload.create({
    collection: 'media', data: image7, file: image7Buffer,
  }).then((res) => {
    payload.logger.info(`image7Doc: ${res.id}`)
    payload.logger.info('Completed seeding images')
    return res
  }).catch((err) => {
    payload.logger.error({
      message: 'Error seeding image7', error: err,
    })
  })

  payload.logger.info(`— Seeding categories...`)

  const financeCategory = await payload.create({
    collection: 'categories', data: { relatedCategories: [], title: 'Finance' },
  })

  const artsCategory = await payload.create({
    collection: 'categories', data: {
      title: 'Arts & Consumption', relatedCategories: [],
    },
  })

  const homoEconomicusCategory = await payload.create({
    collection: 'categories', data: { relatedCategories: [], title: 'Homo Economicus' },
  })

  const curationCategory = await payload.create({
    collection: 'categories', data: { relatedCategories: [], title: 'Curation' },
  }).then((res) => {
    payload.logger.info('Completed seeding categories')
    return res
  })

  let image1ID: number | string | null = image1Doc?.id ?? null
  let image2ID: number | string | null = image2Doc?.id ?? null
  let image3ID: number | string | null = image3Doc?.id ?? null
  let image4ID: number | string | null = image4Doc?.id ?? null
  let image5ID: number | string | null = image5Doc?.id ?? null
  let image6ID: number | string | null = image6Doc?.id ?? null
  let image7ID: number | string | null = image7Doc?.id ?? null

  // image1ID = `"${image1Doc.id}"`
  // image2ID = `"${image2Doc.id}"`
  // image3ID = `"${image3Doc.id}"`
  // image4ID = `"${image4Doc.id}"`
  // image5ID = `"${image5Doc.id}"`
  // image6ID = `"${image6Doc.id}"`
  // image7ID = `"${image7Doc.id}"`
  demoAuthorID = `"${demoAuthorID}"`

  payload.logger.info(`— Seeding posts...`)
  payload.logger.info(`— Seeding post1...`)
  // Do not create posts with `Promise.all` because we want the posts to be created in order
  // This way we can sort them by `createdAt` or `publishedAt` and they will be in the expected order
  const [post1Doc, post2Doc, post3Doc, post4Doc, post5Doc, post6Doc, post7Doc] = await Promise.all([payload.create({
    collection: 'posts', data: JSON.parse(JSON.stringify({
      ...post1, categories: [], heroImage: image1ID,
    }).replace(/"\{\{AUTHOR\}\}"/g, demoAuthorID)),
  }).catch(err => {
    payload.logger.error({ message: `error while seeding post#1`, error: err })
  }), (payload.logger.info(`— Seeding post2...`), payload.create({
    collection: 'posts', data: JSON.parse(JSON.stringify({
      ...post2, categories: [], heroImage: image2ID,
    }).replace(/"\{\{AUTHOR\}\}"/g, demoAuthorID)),
  }).catch(err => {
    payload.logger.error({ message: `error while seeding post#2`, error: err })
  })), (payload.logger.info(`— Seeding post3...`), payload.create({
    collection: 'posts', data: JSON.parse(JSON.stringify({
      ...post3, categories: [], heroImage: image3ID,

    }).replace(/"\{\{AUTHOR\}\}"/g, demoAuthorID)),
  }).catch(err => {
    payload.logger.error({ message: `error while seeding post#3`, error: err })
  })), (payload.logger.info(`— Seeding post4...`), payload.create({
    collection: 'posts', data: JSON.parse(JSON.stringify({
      ...post4, categories: [], heroImage: image4ID,
    }).replace(/"\{\{AUTHOR\}\}"/g, demoAuthorID)),
  }).catch(err => {
    payload.logger.error({ message: `error while seeding post#4`, error: err })
  })), (payload.logger.info(`— Seeding post5...`), payload.create({
    collection: 'posts', data: JSON.parse(JSON.stringify({
      ...post5, categories: [], heroImage: image5ID,
    }).replace(/"\{\{AUTHOR\}\}"/g, demoAuthorID)),
  }).catch(err => {
    payload.logger.error({ message: `error while seeding post#5`, error: err })
  })), (payload.logger.info(`— Seeding post6...`)
    , payload.create({
    collection: 'posts', data: JSON.parse(JSON.stringify({
      ...post6, categories: [], heroImage: image6ID,
    }).replace(/"\{\{AUTHOR\}\}"/g, demoAuthorID)),
  }).catch(err => {
    payload.logger.error({ message: `error while seeding post#6`, error: err })
  })), (payload.logger.info(`— Seeding post7...`)
    , payload.create({
    collection: 'posts', data: JSON.parse(JSON.stringify({
      ...post7, categories: [], heroImage: image7ID,
    }).replace(/"\{\{AUTHOR\}\}"/g, demoAuthorID)),
  }).catch(err => {
    payload.logger.error({ message: `error while seeding post#7`, error: err })
  }))]);

  // update each post with related posts
  (post1Doc?.id && post2Doc?.id && post3Doc?.id && (payload.logger.info(`— Updating posts with related posts...`), await payload.update({
    id: post1Doc.id, collection: 'posts', data: {
      relatedPosts: [post2Doc.id, post3Doc.id],
    },
  })));

  ((post1Doc?.id && post2Doc?.id && post3Doc?.id && (payload.logger.info(`— Updating post2 with related posts...`), await payload.update({
    id: post2Doc.id, collection: 'posts', data: {
      relatedPosts: [post1Doc.id, post3Doc.id],
    },
  }))))
  //
  // payload.logger.info(`— Seeding pages...`)
  // const receptionPage = await payload.create({
  //   collection: 'pages', data: {
  //     title: 'Reception', slug: 'home', hero: {
  //       type: 'none',
  //     }, layout: [{
  //       blockType: 'heroSquare', populateBy: 'collection', relationTo: 'posts', categories: [],
  //     }],
  //   },
  // })
  //
  // payload.logger.info(`— Seeding register page...`)
  // const registerPage = await payload.create({
  //   collection: 'pages', data: {
  //     title: 'Register', slug: 'register', hero: {
  //       type: 'none',
  //     }, layout: [],
  //   },
  // })
  //
  // payload.logger.info(`— Seeding plans page...`)
  // const plansPage = await payload.create({
  //   collection: 'pages', data: {
  //     title: 'Plans', slug: 'plans', hero: {
  //       type: 'none',
  //     }, layout: [],
  //   },
  // })
  // payload.logger.info(`— Seeding lostinseoul page...`)
  // const lostinseoulPage = await payload.create({
  //   collection: 'pages', data: {
  //     title: 'LOSTINSEOUL', slug: 'lostinseoul', hero: {
  //       type: 'none',
  //     }, layout: [],
  //   },
  // })
  // payload.logger.info(`— Seeding the team page...`)
  // const theTeamPage = await payload.create({
  //   collection: 'pages', data: {
  //     title: 'The Team', slug: 'the-team', hero: {
  //       type: 'none',
  //     }, layout: [],
  //   },
  // })
  // const profilePage = await payload.create({
  //   collection: 'pages', data: {
  //     title: 'Your Account', slug: 'account', hero: {
  //       type: 'none',
  //     }, layout: [],
  //   },
  // })
  // payload.logger.info(`— Seeding header...`)
  //
  // await payload.updateGlobal({
  //   slug: 'header', data: {
  //     navItems: [{
  //       link: {
  //         type: 'reference', reference: { relationTo: 'pages', value: receptionPage.id }, label: 'Reception',
  //       },
  //     }, {
  //       link: {
  //         type: 'reference', reference: { relationTo: 'pages', value: plansPage.id }, label: 'Plans',
  //       },
  //     }, {
  //       link: {
  //         type: 'reference', reference: { relationTo: 'pages', value: lostinseoulPage.id }, label: 'LOSTINSEOUL',
  //       },
  //     }, {
  //       link: {
  //         type: 'reference', reference: { relationTo: 'pages', value: theTeamPage.id }, label: 'The Team',
  //       },
  //     }, {
  //       link: {
  //         type: 'reference', reference: { relationTo: 'pages', value: registerPage.id }, label: 'Register',
  //       },
  //     }],
  //   },
  // })
  //
  // payload.logger.info(`— Seeding footer...`)

  // await payload.updateGlobal({
  //   slug: 'footer', data: {
  //     navItems: [{
  //       link: {
  //         type: 'custom', label: 'Privacy Policy', url: '/privacy-policy',
  //       },
  //     },
  //
  //       {
  //         link: {
  //           type: 'custom', label: 'Terms of Service', newTab: true, url: '/terms-of-service',
  //         },
  //       }],
  //   },
  // })

  payload.logger.info('Seeded database successfully!')
}

async function fetchFileByURL(url: string): Promise<File> {
  const res = await fetch(url, {
    credentials: 'include', method: 'GET',
  })

  if (!res.ok) {
    throw new Error(`Failed to fetch file from ${url}, status: ${res.status}`)
  }

  const data = await res.arrayBuffer()

  return {
    name: url.split('/').pop() || `file-${Date.now()}`,
    data: Buffer.from(data),
    mimetype: `image/${url.split('.').pop()}`,
    size: data.byteLength,
  }
}
