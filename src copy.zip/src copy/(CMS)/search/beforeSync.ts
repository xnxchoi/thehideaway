import type { BeforeSync, DocToSync } from '@payloadcms/plugin-search/types'

export const beforeSyncWithSearch: BeforeSync = async ({ originalDoc, searchDoc, payload }) => {
  const {
    doc: { relationTo: collection },
  } = searchDoc
  let modifiedDoc: DocToSync = {
    ...searchDoc,
  }
  if ('slug' in originalDoc) {
    const { slug, id, name, meta, photo } = originalDoc
    modifiedDoc = {
      ...modifiedDoc, slug: slug, meta: {
        ...meta, title: meta?.title || name, image: meta?.image?.id || meta?.image, description: meta?.description,
      },
    }
  } else {
    const { slug, id, categories, title, meta } = originalDoc
    modifiedDoc = {
      ...modifiedDoc, slug, meta: {
        ...meta, title: meta?.title || title, image: meta?.image?.id || meta?.image, description: meta?.description,
      }, categories: [],
    }
    if (categories && Array.isArray(categories) && categories.length > 0) {
      // get full categories and keep a flattened copy of their most important properties
      try {
        const mappedCategories = categories.map((category) => {
          const { id, title } = category

          return {
            relationTo: 'categories', id, title,
          }
        })

        modifiedDoc.categories = mappedCategories
      } catch (err) {
        console.error(`Failed. Category not found when syncing collection '${collection}' with id: '${id}' to search.`)
      }
    }
  }

  return modifiedDoc
}
