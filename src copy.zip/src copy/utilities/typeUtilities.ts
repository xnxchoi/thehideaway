export type Flatten<Type> = Type extends Array<infer Item> ? Item : Type;
export type RequiredFields<T, K extends keyof T> = T & Required<Pick<T, K>>;
export type RequiredKeys<T> = {
  [K in keyof T]-?:
  ({} extends { [P in K]: T[K] } ? never : K)
}[keyof T]

export type OptionalKeys<T> = {
  [K in keyof T]-?:
  ({} extends { [P in K]: T[K] } ? K : never)
}[keyof T]

export type ExcludeOptionalProps<T> = Pick<T, RequiredKeys<T>>
export type ExcludeProperties<Type, Att extends keyof Type> = {
  [Property in keyof Type as Exclude<Property, Att>]: Type[Property]
};
export type MakeRequired<Type, Att extends OptionalKeys<Type>> = Required<Pick<Type, RequiredKeys<Type> | Att>>

type _Combine<T, K extends PropertyKey = T extends unknown ? keyof T : never> =
  T extends unknown ? T & Partial<Record<Exclude<K, keyof T>, never>> : never;

export type Combine<T> = { [K in keyof _Combine<T>]: _Combine<T>[K] }
export type Without<T> = { [P in keyof T]?: undefined };
export type XOR<T, U> = (Without<T> & U) | (Without<U> & T);
