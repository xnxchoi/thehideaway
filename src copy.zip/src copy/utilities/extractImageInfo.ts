import { PayloadRequest } from 'payload'
import { imageSize } from 'image-size'
import { DateTime } from 'luxon'

export const extractImageInfo = async (args: {
  req: PayloadRequest
}) => {
  const { req } = args

  const { file, payload } = req
  if(!file) return (payload.logger.error({
    message: 'No file',
    origin: 'extractImageInfo',
    date: DateTime.now().toISO(),
    user: req.user?.id,
  }),false)

  const { data, mimetype, name, size } = file
  if (mimetype.indexOf('image') < 0) return (payload.logger.error({
    message: 'Not an image',
    origin: 'extractImageInfo',
    date: DateTime.now().toISO(),
    file: name, user: req.user?.id,
  }),false)

  if (size > (30 * 2 ^ 20)) return (payload.logger.error({
    message: 'Image too large',
    origin: 'extractImageInfo',
    date: DateTime.now().toISO(),
    file: name,
    user: req.user?.id,
    size,
    size_mb: size / (2 ^ 20),
  }),false)
  const { width, height } = imageSize(data as Uint8Array)
  let colorSum = 0
  let r = 0, g = 0, b = 0, avg = 0
  for (let x = 0, len = data.length; x < len; x += 4) {
    r = data[x]
    g = data[x + 1]
    b = data[x + 2]
    avg = Math.floor((r + g + b) / 3)
    colorSum += avg
  }
  return {
    darkmode: Math.floor(colorSum / (width * height)) < 0.5,
    width,
    height,
  }
}
