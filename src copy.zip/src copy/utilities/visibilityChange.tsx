'use client'
import { useCallback, useEffect, useRef, useState } from 'react'

function rand(min: number, max: number) {
  const minCeiled = Math.ceil(Math.min(min, max))
  const maxFloored = Math.floor(Math.max(min, max))
  return Math.floor(Math.random() * (maxFloored - minCeiled + 1) + minCeiled)
}

export const TabMessenger = () => {
  const org = 'THE HIDEAWAY'
  const sO = useRef<ReturnType<typeof setTimeout>>(null!)
  const [dT, setDT] = useState('')
  const [emojis, setEmojis] = useState({})
  const [messages, setMessages] = useState({})
  const [mLen, setMLen] = useState(0)
  const [eLen, setELen] = useState(0)
  const [banner, setBanner] = useState('')
  const [visible, setVisible] = useState(true)
  const arr = useCallback(async () => {
    let a = await import('../constants/tabMessages.json')
      .then((a) => JSON.parse(JSON.stringify(a)))
      .then((a) => {
        return {
          mLen: Object.keys(a.messages).length,
          eLen: Object.keys(a.icons).length,
          messages: a.messages,
          icons: a.icons,
        }
      })
    setEmojis(a.icons), setMessages(a.messages), setMLen(a.mLen), setELen(a.eLen)
  }, [setEmojis, setMessages, setMLen, setELen])

  const visibleCallback = useCallback(() => {
    setVisible(document.hidden)
  }, [setVisible])
  useEffect(() => {
    sO.current && clearTimeout(sO.current)
    ;(visible &&
      (sO.current = setTimeout(async () => {
        setBanner(`${emojis[rand(1, eLen)]}   ${messages[rand(1, mLen)]}`)
      }, 1500))) ||
      setBanner(dT ?? org)
  }, [emojis, messages, sO, dT, org, visible])
  useEffect(() => {
    setDT(document.title)
    arr().then(() => {
      document.addEventListener('visibilitychange', visibleCallback)
    })
    return () => {
      document.removeEventListener('visibilitychange', visibleCallback)
    }
  }, [])
  useEffect(() => {
    document.title = banner
  }, [banner])
  return null
}
