'use client'
import { useEffect, useState } from 'react'
import { getDeviceInfo } from '@/providers/RP_Pro'
import { resizeListenerProps } from '@/utilities/rp_utils'

export const useWindowResize = (args: resizeListenerProps = {}) => {
  const config = {
    debounce: 300, detectHeightChange: !1, ...args,
  }
  const [currentWidth, setCurrentWidth] = useState<number>(null!)
  const [currentHeight, setCurrentHeight] = useState<number>(null!)
  const [lastTimestamp, setLastTimestamp] = useState<number>(0)
  const [timeoutID, setTimeoutID] = useState<ReturnType<typeof setTimeout>>(null!)
  const devInfo = getDeviceInfo()
  useEffect(() => {
    const l = devInfo.isMobile && devInfo.browser.chrome
    if (currentWidth === null) {
      setCurrentWidth(window.innerWidth)
      return
    }
    if (currentHeight === null && config.detectHeightChange && !l) {
      setCurrentHeight(window.innerHeight)
      return
    }

    function handleResize() {
      timeoutID && clearTimeout(timeoutID), setTimeoutID(setTimeout(() => {
        window.innerWidth !== currentWidth && (setCurrentWidth(window.innerWidth), setLastTimestamp(Date.now())), window.innerHeight === currentHeight || l || (setCurrentHeight(window.innerHeight), setLastTimestamp(Date.now()))
      }, config.debounce))
    }

    return (window.removeEventListener('resize', handleResize), window.addEventListener('resize', handleResize), () => {
      window.removeEventListener('resize', handleResize)
    })
  }, [currentWidth, currentHeight, config.debounce, config.detectHeightChange]), useEffect(() => {
    const handleVisibilityChange = () => {
      setTimeout(() => {
        setLastTimestamp(Date.now())
      }, 50)
    }

    return (window.removeEventListener('visibilitychange', handleVisibilityChange), window.addEventListener('visibilitychange', handleVisibilityChange), () => {
      window.removeEventListener('visibilitychange', handleVisibilityChange)
    })
  }, [])
  return lastTimestamp
}