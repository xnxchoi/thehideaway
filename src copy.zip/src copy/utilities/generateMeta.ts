import type { Metadata } from 'next'

import type { Page, Post } from '@/payload-types'
import { getServerSideURL } from './getURL'
import { mergeOpenGraph } from './mergeOpenGraph'
import { User } from 'payload'

export const generateMeta = async (args: {
  doc: Partial<Page> | Partial<Post> | Partial<User>
}): Promise<Metadata> => {
  const { doc } = args || {}

  const ogImage = typeof doc?.meta?.image === 'object' && doc.meta.image !== null && 'url' in doc.meta.image && `${getServerSideURL()}`

  const title = doc?.meta?.title ? `${doc?.meta?.title} | The Hideaway` : 'The Hideaway'

  return {
    description: doc?.meta?.description, openGraph: mergeOpenGraph({
      description: doc?.meta?.description || '', images: ogImage ? [{
        url: ogImage,
      }] : undefined, title, url: Array.isArray(doc?.slug) ? doc?.slug.join('/') : '/',
    }), title,
  }
}
