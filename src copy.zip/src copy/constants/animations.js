export const DURATION = Object.freeze({
  S: 0.6,
})
export const EASE = Object.freeze({
  p3eo: "Power3.easeOut",
  p3eio: "Power3.easeInOut",
  p3ei: "Power3.easeIn",
})
