import { NextAuthConfig } from 'next-auth'
import Kakao from 'next-auth/providers/kakao'
import Naver from 'next-auth/providers/naver'
import { Member } from '@/payload-types'
import { PayloadAuthjsUser } from 'payload-authjs'
import { Provider } from 'next-auth/providers'
import * as process from 'node:process'
import Google from 'next-auth/providers/google'
declare module 'next-auth' {
  interface User extends PayloadAuthjsUser<Member> {
  }
}

export const authMembersProviders: Provider[] = [Naver({
  clientId: process.env.AUTH_NAVER_ID, clientSecret: process.env.AUTH_NAVER_SECRET,
}), Kakao({ clientId: process.env.AUTH_KAKAO_ID, clientSecret: process.env.AUTH_KAKAO_SECRET }), Google({
  clientId: process.env.AUTH_MEMBERS_GOOGLE_ID, clientSecret: process.env.AUTH_MEMBERS_GOOGLE_SECRET,
})]
export const authMembersProviderMap = authMembersProviders.map((provider) => {
  if (typeof provider === 'function') {
    const providerData = provider()
    return { id: providerData.id, name: providerData.name }
  } else {
    return { id: provider.id, name: provider.name }
  }
})
export const authMembersConfig: NextAuthConfig = {
  basePath: '/api/auth/members', cookies: {
    sessionToken: {
      name: 'authjs.member-session-token',
    }, csrfToken: {
      name: 'authjs.member-csrf-token',
    }, callbackUrl: {
      name: 'authjs.member-callback-url',
    },
  }, session: { strategy: 'database' }, providers: authMembersProviders, callbacks: {
    authorized: ({ auth }) => !!auth,

  }, pages: {
    signIn: '/check-in',
  }
}