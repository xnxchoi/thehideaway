'use client'
import { Link } from 'src/components/UX/Link'
import { Logo } from '@/components/UX/Logo'
import { undefined, z } from 'zod'
import { Lanyard, MemberCardsType } from '@/components/layouts/Registration/lanyard'
import { motion } from 'motion/react'
import * as React from 'react'
import { useEffect, useState } from 'react'
import { useForm } from 'react-hook-form'
import { zodResolver } from '@hookform/resolvers/zod'
import { Form, FormControl, FormField, FormItem, FormLabel } from '@/components/ui/form'
import { Input, InputFile } from '@/components/ui/input'
import '@/styles/__inputs.scss'
import { Member } from '@/payload-types'
import { useRPStore } from '@/providers/RP_Pro'
import { AspectRatio } from '@/components/ui/aspect-ratio'


const minLengthErrorMessage = '비밀번호는 최소 8자 이상이어야 합니다', maxLengthErrorMessage = '비밀번호는 최대 20자입니다',
  uppercaseErrorMessage = '최소 1자 이상의 영문 대문자를 포함해야 합니다', lowercaseErrorMessage = '최소 1자 이상의 영문 소문자를 포함해야 합니다',
  numberErrorMessage = '숫자를 최소 1자 이상 포함해야 합니다', specialCharacterErrorMessage = '!@#$%^&* 특수문자 중 한 자 이상 포함하여야 합니다'
const nameSchema = z.string().min(2).max(40).refine((name) => !/[0-9]/.test(name), {
  message: '숫자는 사용할 수 없습니다',
}).refine((name) => !/[!@#$%^&*]/.test(name), {
  message: '특수문자는 사용할 수 없습니다',
})
const userNameSchema = z.string().min(2).max(40)
const MAX_FILE_SIZE = 5 * 1024 * 1024
const ACCEPTED_IMAGE_TYPES = ['image/jpeg', 'image/jpg', 'image/png', 'image/webp']
// const profilePictureSchema = z.preprocess((value) => (Array.isArray(value) ? value : [value]), z.array(z.instanceof(FileList))).refine((files) => files.length > 0 ?( ACCEPTED_IMAGE_TYPES.includes(files?.[0]?.type) ? true : false) : true, 'Invalid file. choose either JPEG ,jpg , webp PNG image').refine(file => file.length == 1 ? file[0]?.size <= MAX_FILE_SIZE ? true : false : true, 'Max file size allowed is 5MB.')
const profilePictureSchema= z.object({
  file: z.instanceof(FileList).optional(),
});
const passwordSchema = z.string().min(8, { message: minLengthErrorMessage }).max(20, { message: maxLengthErrorMessage }).refine((password) => /[A-Z]/.test(password), {
  message: uppercaseErrorMessage,
}).refine((password) => /[a-z]/.test(password), {
  message: lowercaseErrorMessage,
}).refine((password) => /[0-9]/.test(password), { message: numberErrorMessage }).refine((password) => /[!@#$%^&*]/.test(password), {
  message: specialCharacterErrorMessage,
})

export const signupFormSchema = z.object({
  username: userNameSchema,
  firstName: nameSchema,
  lastName: nameSchema,
  email: z.string().email(),
  password: passwordSchema,
  confirmPassword: passwordSchema,
  profilePicture: profilePictureSchema,
})

export const SplitSection = () => {
  const userInfo: Omit<Member, 'memberNumber' | 'protected' | 'updatedAt' | 'favourites'> = {
    email: '',
    firstName: '',
    lastName: '',
    name: '',
    slug: '',
    emailVerified: 'false',
    verified: false,
    id: '',
    roles: [],
    description: '',
    createdAt: '',
  }
  const user = useRPStore((state) => state.user)
  const [type, setType] = useState<MemberCardsType | string>('BADGE')

  const form = useForm<z.infer<typeof signupFormSchema>>({
    resolver: zodResolver(signupFormSchema), defaultValues: {
      username: '', firstName: '', lastName: '', email: '', password: '', confirmPassword: '',

    },
  })
  const fileRef=form.register('profilePicture')
  useEffect(() => {
    if (user) {
      setType('BADGE')
      user.email && form.setValue('email', user.email)
      user.name && form.setValue('username', user.name)

    } else {
      setType('BADGE')
    }
  }, [user])

  // 2. Define a submit handler.
  function onSubmit(values: z.infer<typeof signupFormSchema>) {

  }

  return (<motion.section key={'splitSection'}
                          className="gap-[.5em] bg-background w-full min-h-screen mb-0 p-[.5em] flex relative overflow-clip"
                          data-themed={'background-color, color'}>
    <Form {...form}>
      <div className={'flow-side w-full pt-[25px] lg:w-[35em]'}>
        <div
          className={'w-full h-full lg:w-[30em] gap-x-[2em] gap-y-[2em] shrink-0 p-[1.5em] pt-[23px] flex-col flex justify-center'}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-8 grid grid-cols-8 gap-4">
          <div className={'relative form-field active col-span-full'}>
            <AspectRatio ratio={4/5}></AspectRatio>
          </div>
            <FormField control={form.control} name={'profilePicture'}
              render={({ field }) => (<FormItem className={'relative form-field active col-span-full'}>
                <InputFile {...fileRef} />
              </FormItem>)}
            />
            <FormField control={form.control} name={'email'}
                       render={({ field }) => (<FormItem className={'relative form-field active col-span-full'}>
                         <FormControl>
                           <Input autoComplete={'email'} {...field} placeholder={''} className={'w-input'} />
                         </FormControl>
                         <div data-form={'baseline'} />
                         <FormLabel className={'input-label'}>Email</FormLabel>
                       </FormItem>)} />
            <FormField control={form.control} name={'username'}
                       render={({ field }) => (<FormItem className={'relative form-field active col-span-full'}>
                         <FormControl>
                           <Input autoComplete={'username'} {...field} placeholder={''} className={'w-input'} />
                         </FormControl>
                         <div data-form={'baseline'} />
                         <FormLabel className={'input-label'}>Name</FormLabel>
                       </FormItem>)} />
            <FormField control={form.control} name={'firstName'}
                       render={({ field }) => (<FormItem className={'relative form-field active col-span-full'}>
                         <FormControl>
                           <Input autoComplete={'given-name'} {...field} placeholder={''} className={'w-input'} />
                         </FormControl>
                         <div data-form={'baseline'} />
                         <FormLabel className={'input-label'}>First Name</FormLabel>
                       </FormItem>)} />
            <FormField control={form.control} name={'lastName'}
                       render={({ field }) => (<FormItem className={'relative form-field active col-span-full'}>
                         <FormControl>
                           <Input autoComplete={'family-name'} {...field} placeholder={''} className={'w-input'} />
                         </FormControl>
                         <div data-form={'baseline'} />
                         <FormLabel className={'input-label'}>Last Name</FormLabel>
                       </FormItem>)} />
            <FormField control={form.control} name={'password'}
                       render={({ field }) => (<FormItem className={'relative form-field active col-span-full'}>
                         <FormControl>
                           <Input autoComplete={'new-password'} {...field} placeholder={''} type={'password'}
                                  className={'w-input'} />
                         </FormControl>
                         <div data-form={'baseline'} />
                         <FormLabel className={'input-label'}>Password</FormLabel>
                       </FormItem>)} />
            <FormField control={form.control} name={'confirmPassword'}
                       render={({ field }) => (<FormItem className={'relative form-field active col-span-full'}>
                         <FormControl>
                           <Input autoComplete={'new-password'} {...field} placeholder={''} type={'password'}
                                  className={'w-input'} />
                         </FormControl>
                         <div data-form={'baseline'} />
                         <FormLabel className={'input-label'}>Confirm Password</FormLabel>
                       </FormItem>)} />
          </form>
          <Link className={'max-w-[100%] flex relative items-center content-between w-full'} href={'/public'}>
            <div className={'shrink-0 pointer-events-none flex content-center'}>
              <Logo />
            </div>
          </Link>
        </div>
        <div className={'shrink-0 order-1'}></div>
      </div>
      <div className={'flow-visual hidden lg:flex relative grow'}>
        <Lanyard type={type} />
      </div>
    </Form>
  </motion.section>)
}
