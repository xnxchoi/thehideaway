'use client'
import { useCallback, useEffect, useRef, useState } from 'react'
import { useIsMobile } from '@/utilities/getBreakpoints'
import gsap from 'gsap'
import { useLenis } from 'lenis/react'
import './__credits.scss'
import { seedd } from '@/components/sections/Credits/seedd'
import { Link } from '@/components/UX/Link'
import { useGSAP } from '@gsap/react'
import { PaginatedDocs } from 'payload'
import { motion } from 'motion/react'

interface Person {
  id: string // Unique identifier for the person
  nom: string // Name of the person
  birthDay: number | null // Optional flag indicating if the person has a birthDay
  birthMonth: number | null
  photo: Photo // Object containing photo-related details
}

interface Member extends Person {
  birthday: boolean
}

interface Photo {
  sourceUrl?: string
  altText?: string
  mediaType?: string
  title: string
  srcSet?: string
  mediaItemUrl: string
  mediaDetails: {
    file: string
    height: number
    width: number
    sizes: {
      name: string
      sourceUrl: string
      width: string
      file: string
      fileSize: number
      height: string
    }[]
  }
}

interface TeamData {
  title: string
  team: {
    paragraphe: null | string
    postes: {
      nomDuPoste: string
      personnes: Person[]
    }[]
  }
}

const getPeople = (): TeamData => {
  return { team: seedd.data[0].page.team, title: seedd.data[0].page.title }
}

export const Credits = (credits: PaginatedDocs) => {
  let p = getPeople()
  return MOVIED({ ppl: p })
}
const MOVIED = (props: { ppl: TeamData }) => {
  const { ppl } = props
  const teme = ppl
  const movied = useRef<HTMLDivElement>(null!)
  const [teamData, setTeamData] = useState(teme)
  const credits = useRef<HTMLDivElement>(null!)
  const fondFlou = useRef<HTMLDivElement>(null!)
  const mobileList = useRef<HTMLUListElement>(null!)
  const closeCatMob = useRef<HTMLButtonElement>(null!)
  const mobileListItems = useRef<HTMLLIElement[]>([])
  const [activeProfile, setActiveProfile] = useState<Person>(null!)
  const [mobileProfile, setMobileProfile] = useState<Person>(null!)
  const { isMobile } = useIsMobile()
  const [isParty, setIsParty] = useState(!1)
  const [hasBirthday, setHasBirthday] = useState(!1)
  const [isTouching, setIsTouching] = useState(!1)
  const canvas = useRef<HTMLCanvasElement>(null!)
  const dpr = anotherMathFunc(window.devicePixelRatio, 1, 2)
  const canvasCtx = useRef<CanvasRenderingContext2D>(null!)
  const [wW, setWw] = useState(window.innerWidth)
  const [wH, setWh] = useState(window.innerHeight)
  const deltaY = useRef(0)

  const inten = useRef(0)

  const posX = useRef(0)

  const ySetter = useRef<Function>(null!)
  const height = useRef(0)
  const acceleration = useRef(0)

  const confettisCount = useRef(300), gravity = useRef(0.8), terminalVelocity = useRef(20), drag = useRef(0.075)
  const people = useRef<Member[]>([])

  const colors = useRef([{
    front: 'red', back: 'darkred',
  }, {
    front: 'green', back: 'darkgreen',
  }, {
    front: 'blue', back: 'darkblue',
  }, {
    front: 'yellow', back: 'darkyellow',
  }, {
    front: 'orange', back: 'darkorange',
  }, {
    front: 'pink', back: 'darkpink',
  }, {
    front: 'purple', back: 'darkpurple',
  }, {
    front: 'turquoise', back: 'darkturquoise',
  }])

  const getPic = (photo: Photo, size: string) => {
    // Example function to fetch photo URLs based on size
    let a = photo['mediaDetails']['sizes'].findIndex((s) => s.name === size)
    return ((a > -1 && photo['mediaDetails']['sizes'][a]['sourceUrl']) || '/assets/image/metal-finger.jpeg')
  }
  const scroller = useLenis()!

  const updateProfil = (e) => {
    setActiveProfile(e)
    e.birthDay && setIsParty(false) && initConfettis() && gsap.ticker.add(render)
  }
  const updateProfil2 = (e) => {
    if (isMobile) {
      scroller.stop(), setActiveProfile(e), setMobileProfile(e)
      const n = mobileListItems.current.find((item) => item.dataset.id === e.id)
      if (!n) return
      credits.current.classList.add('-hidden'), closeCatMob.current.classList.add('on'), fondFlou.current.classList.add('pointer'), mobileList.current.classList.remove('-snap'), e.birthDay && !isParty && initConfettis() && gsap.ticker.add(render)
      setTimeout(function() {
        n.scrollIntoView(), gsap.to(mobileList.current, {
          scrollLeft: '+=60',
          duration: 0.5,
          ease: 'power3.inOut',
          yoyo: !0,
          repeat: 1,
          delay: 0.5,
          onComplete: function() {
            mobileList.current.classList.add('-snap')
          },
        })
      }, 250)
    }
  }
  const hideProfil = useCallback(() => {
    isMobile || setActiveProfile(null!)
  }, [])
  const hideProfil2 = useCallback(() => {
    scroller.start(), setActiveProfile(null!), setMobileProfile(null!)
    closeCatMob.current.classList.remove('on'), fondFlou.current.classList.remove('pointer'), gsap.delayedCall(1, function() {
      credits.current.classList.remove('-hidden')
    })
  }, [])

  const onResize = useCallback(() => {
    canvas.current.width = wW * dpr
    canvas.current.height = wH * dpr
    canvas.current.style.width = '' + Math.ceil(wW) + 'px'
    canvas.current.style.height = '' + Math.ceil(wH) + 'px'
    canvasCtx.current.scale(dpr, dpr)
  }, [canvas, wW, wH, canvasCtx])
  const confettis = useRef<{
    color: any
    dimensions: { x: number; y: number }
    position: { x: any; y: number }
    rotation: any
    scale: { x: number; y: number }
    velocity: { x: any; y: any }
  }[]>([])
  const isWheeling = useRef<ReturnType<typeof setTimeout>>(null!)
  const onWheel = useCallback((e: WheelEvent) => {
    deltaY.current = e.deltaY
    clearTimeout(isWheeling.current), (isWheeling.current = setTimeout(function() {
      deltaY.current = 0
    }, 66))
  }, [isWheeling, deltaY])
  const init = useCallback(() => {
    if (isMobile) {
      setIsTouching(false), gsap.to(credits.current, {
        opacity: 1, duration: 0.5, delay: 1,
      })
    } else {
      window.addEventListener('wheel', onWheel), (height.current = credits.current.offsetHeight), (acceleration.current = 1), gsap.to(credits.current, {
        opacity: 1, duration: 0.5, delay: 1, onComplete: () => {
          gsap.ticker.add(animate)
        },
      })
    }
  }, [onWheel, credits, setIsTouching])
  const testBirthday = useCallback(() => {
    let t = new Date(), n = t.getDate(), o = t.getMonth() + 1
    console.log(n, o)
    teamData.team.postes.forEach(function(t) {
      people.current = [...new Set([...people.current, ...t.personnes.map(function(p) {
        let hasB = (p.birthDay === n && p.birthMonth === o) ?? false
        setHasBirthday(hasB)
        return {
          ...p, birthday: hasB,
        }
      })])]
    })
    console.log(people.current)
  }, [teamData, people])
  const { context, contextSafe } = useGSAP(() => {
    ySetter.current = gsap.quickSetter('.credits', 'y', 'px')
  }, { scope: movied })

  const ySet = contextSafe((pos) => {
    ySetter.current(pos)
  })
  const initCanvas = useCallback(() => {
    console.log('initCanvas')
    let c = canvas.current.getContext('2d')!
    canvasCtx.current = c;(confettisCount.current = 300), (gravity.current = 0.8), (terminalVelocity.current = 20), (drag.current = 0.075)
  }, [canvas, canvasCtx, confettisCount, gravity, terminalVelocity, drag])
  useEffect(() => {
    init()

    testBirthday()
  }, [])
  useEffect(() => {
    hasBirthday && initCanvas()
  }, [hasBirthday])
  const initConfettis = useCallback(() => {
    console.log('initConfettis')
    setIsParty(true)
    confettis.current = []
    for (let i = 0; i < confettisCount.current; i++) confettis.current.push({
      color: colors.current[randomize(0, colors.current.length - 1)], dimensions: {
        x: randomize(10, 40), y: randomize(10, 30),
      }, position: {
        x: randomize(0, wW), y: wH - 1,
      }, rotation: randomize(0, 2 * Math.PI), scale: {
        x: 1, y: 1,
      }, velocity: {
        x: randomize(-25, 25), y: randomize(-5, -50),
      },
    })
  }, [confettisCount, wW, wH, colors, setIsParty])

  const animate = useCallback((time, dt) => {
    let e = 1 - Math.pow(0.9, dt)
    let intent = inten.current
    let posax = posX.current
    ySet(posax)

    inten.current += (deltaY.current / 2 - intent) * e
    posX.current -= (dt * acceleration.current + 6 * intent) / 12
    posX.current > 0 && (posX.current = -height.current / 2), posX.current < -height.current / 2 && (posX.current = posX.current + height.current / 2)
  }, [inten, posX, height, acceleration, deltaY])
  const render = useCallback(() => {
    canvasCtx.current.clearRect(0, 0, wW * dpr, wH * dpr), confettis.current.forEach(function(t, n) {
      canvasCtx.current.scale(dpr, dpr)
      let o = t.dimensions.x * t.scale.x, r = t.dimensions.y * t.scale.y
      canvasCtx.current.translate(t.position.x, t.position.y), canvasCtx.current.rotate(t.rotation), (t.velocity.x -= t.velocity.x * drag.current), (t.velocity.y = Math.min(t.velocity.y + gravity.current, terminalVelocity.current)), (t.velocity.x += Math.random() > 0.5 ? Math.random() : -Math.random()), (t.position.x += t.velocity.x), (t.position.y += t.velocity.y), t.position.y >= wH + 2 * r && confettis.current.splice(n, 1), (t.scale.y = Math.cos(0.1 * t.position.y)), (canvasCtx.current.fillStyle = t.scale.y > 0 ? t.color.front : t.color.back), canvasCtx.current.fillRect(-o / 2, -r / 2, o, r), canvasCtx.current.setTransform(1, 0, 0, 1, 0, 0)
    }), confettis.current.length || setIsParty(!1), canvasCtx.current.clearRect(0, 0, wW * dpr, wH * dpr)
  }, [confettis, wW, wH, dpr, setIsParty, colors, gravity, terminalVelocity, drag, canvasCtx])

  const pause = useCallback(() => {
    let progress = {
      acceleration: acceleration.current,
    }
    gsap.to(progress, {
      acceleration: 0, onUpdate: function() {
        acceleration.current = progress.acceleration
      }, duration: 0.8, ease: 'power2.inOut',
    })
    setIsTouching(true)
  }, [setIsTouching, acceleration])
  const play = useCallback(() => {
    let progress = {
      acceleration: acceleration.current,
    }
    gsap.to(progress, {
      acceleration: 1, onUpdate: function() {
        acceleration.current = progress.acceleration
      }, duration: 0.8, ease: 'power2.inOut',
    })
    setIsTouching(false)
  }, [setIsTouching, acceleration])
  const to = useRef<ReturnType<typeof setTimeout>>(null!)
  const onMobileListScroll = useCallback((e) => {
    to.current && clearTimeout(to.current)
    to.current = setTimeout(setIndex, 100)
  }, [to])
  const setIndex = useCallback(() => {
    let e = activeProfile
    let t, o = Math.floor(mobileList.current.scrollLeft / window.innerWidth), r = !1
    null !== e && void 0 !== e && e.id && (teamData.team.postes.every(function(e, t) {
      return (e.personnes.every(function(p, e) {
          return t + e !== o || (setActiveProfile(p), (r = !0), !1)
        }), !r)
    }), console.log(activeProfile, isParty), null !== (t = activeProfile) && void 0 !== t && t.birthDay && !isParty && initConfettis())
  }, [teamData, activeProfile, isParty])
  return (<motion.div ref={movied}>
      <div className={'equipe'}>
        <div className="fondFlou fixed" ref={fondFlou}>
          <div>
            {teamData.team.postes.map((person) => person.personnes.flatMap((perso) => {
              return (<img key={`bgImg-${perso.id}`}
                           className={`absolute imgFond ${activeProfile?.id === perso.id ? 'visible' : 'hidden'}`}
                           src={getPic(perso.photo, 'custom-lazy')} alt="" />)
            }))}
          </div>
        </div>
        <div className="profil absolute" style={{ display: activeProfile ? 'inherit' : 'none' }}>
          <div className="vignette vignetteEquipe r">
            {activeProfile && activeProfile.photo && (
              <img src={getPic(activeProfile.photo, 'medium_large')} width={activeProfile.photo.mediaDetails.width}
                   height={activeProfile.photo.mediaDetails.height} alt={''} className={'pic absolute'} loading="lazy"
                   decoding="async" />)}
          </div>
          <div className="nom">{activeProfile && activeProfile.nom}</div>
          <div className="infos tUp mono">
            <p className="poste"></p>
          </div>
        </div>
        <div className="credits-modal" style={{ display: mobileProfile ? 'inherit' : 'none' }}>
          <ul ref={mobileList} onScroll={onMobileListScroll}>
            {teamData.team.postes.map((poste, posteIndex) => poste.personnes.map((person, personIndex) => (
              <li ref={(el) => {
                el && (mobileListItems.current[personIndex] = el)
              }} key={`teamm-${posteIndex}-${personIndex}`} data-id={`${posteIndex}-${personIndex}`}
                  data-index={`${posteIndex}-${personIndex}`}>
                <div className="profil a">
                  <div className="vignette vignetteEquipe relative">
                    {person.photo && (
                      <img className="pic absolute" src={getPic(person.photo, 'medium_large')} alt="" loading="lazy"
                           decoding="async" />)}
                  </div>
                  <div className={`nom ${person.birthDay ? 'birthDay' : ''}`}>{person.nom}</div>
                  <div className="infos tUp mono">
                    <p className="poste">{poste.nomDuPoste}</p>
                  </div>
                </div>
              </li>)))}
          </ul>
        </div>
        <div className="wrap relative">
          <div ref={credits} className="credits" onMouseEnter={() => pause()} onMouseLeave={() => play()}>
            {teamData.team.postes.map((poste, posteIndex) => (
              <div key={`team-${posteIndex}`} className="flex space-between">
                <div className="gauche">{poste.nomDuPoste}</div>
                <ul className="droite">
                  {poste.personnes.map((person, personIndex) => (
                    <li key={`team-1-${posteIndex}-${personIndex}`} className={person.birthDay ? 'birthDay' : ''}
                        onMouseEnter={() => updateProfil({
                          ...person,
                          id: `${posteIndex}-${personIndex}`,
                          job: poste.nomDuPoste,
                          thumbnail: getPic(person.photo, 'medium_large'),
                        })} onMouseLeave={hideProfil} onClick={() => updateProfil2({
                      ...person,
                      id: `${posteIndex}-${personIndex}`,
                      job: poste.nomDuPoste,
                      thumbnail: getPic(person.photo, 'medium_large'),
                    })}>
                      {person.nom}
                    </li>))}
                </ul>
              </div>))}
            {teamData.team.postes.map((poste, posteIndex) => (
              <div key={`team-2-${posteIndex}`} className="team-2 flex space-between">
                <div className="gauche">{poste.nomDuPoste}</div>
                <ul className="droite">
                  {poste.personnes.map((person, personIndex) => (
                    <li key={`team-1-${posteIndex}-${personIndex}`} className={person.birthDay ? 'birthDay' : ''}
                        onMouseEnter={() => updateProfil({
                          ...person,
                          id: `${posteIndex}-${personIndex}`,
                          job: poste.nomDuPoste,
                          thumbnail: getPic(person.photo, 'medium_large'),
                        })} onMouseLeave={hideProfil} onClick={() => updateProfil2({
                      ...person,
                      id: `${posteIndex}-${personIndex}`,
                      job: poste.nomDuPoste,
                      thumbnail: getPic(person.photo, 'medium_large'),
                    })}>
                      {person.nom}
                    </li>))}
                </ul>
              </div>))}
          </div>
        </div>
        <button className="closeCatMob fixed flex items-center" onClick={hideProfil2} ref={closeCatMob}>
          <svg fill="none" height="25" viewBox="0 0 25 25" width="25" xmlns="http://www.w3.org/2000/svg">
            <g stroke="#121212" strokeLinecap="round" strokeWidth="1.25">
              <path d="m1.5 23.3019 21.8025-21.80245" />
              <path d="m23.5328 23.269-21.80249-21.80241" />
            </g>
          </svg>
        </button>
      </div>
      <footer id="rp-footer" style={{ display: 'none' }}>
        <div className="bas">
          <div className={'datas flex flex-wrap space-between'}>
            <div className="gauche flex space-between"></div>
          </div>
          <Link href={'/public'} className={'wander h100 relative'}>
            <div className={'vignette fixed vignetteFooter'} style={{ transform: 'translate(-50%, -110%)' }}>
              <div className={'h-vignetteInner'}>
                <canvas ref={canvas} style={{ display: 'block', width: 0, height: 0 }} />
              </div>
            </div>
          </Link>
        </div>
      </footer>
    </motion.div>)
}
const randomize = (t, e) => {
  return Math.floor(Math.random() * (t - e + 1)) + e
}
const anotherMathFunc = function(e, t, n) {
  return e < t ? t : e > n ? n : e
}
