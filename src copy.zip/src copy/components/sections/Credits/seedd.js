export const seedd =
  ('/en/people',
  (function (
    a,
    b,
    c,
    d,
    e,
    f,
    g,
    h,
    i,
    j,
    k,
    l,
    m,
    n,
    o,
    p,
    q,
    r,
    s,
    t,
    u,
    v,
    w,
    x,
    y,
    z,
    A,
    B,
    C,
    D,
    E,
    F,
    G,
    H,
    I,
    J,
    K,
    L,
    M,
    N,
    O,
    P,
    Q,
    R,
    S,
    T,
    U,
    V,
    W,
    X,
    Y,
    Z,
    _,
    $,
    aa,
    ab,
    ac,
    ad,
    ae,
    af,
    ag,
    ah,
    ai,
    aj,
    ak,
    al,
    am,
    an,
    ao,
    ap,
    aq,
    ar,
    as,
    at,
    au,
    av,
    aw,
    ax,
    ay,
    az,
    aA,
    aB,
    aC,
    aD,
    aE,
    aF,
    aG,
    aH,
    aI,
    aJ,
    aK,
    aL,
    aM,
    aN,
    aO,
    aP,
    aQ,
    aR,
    aS,
    aT,
    aU,
    aV,
    aW,
    aX,
    aY,
    aZ,
    a_,
    a$,
    ba,
    bb,
    bc,
    bd,
    be,
    bf,
    bg,
    bh,
    bi,
    bj,
    bk,
    bl,
  ) {
    return {
      data: [
        {
          page: {
            title: 'Team',
            seo: {
              title: 'Team | TUX',
              metaDesc: 'Our team is made up of 80 experts between Los Angeles and Montreal.',
              opengraphImage: {
                sourceUrl:
                  'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Ftux-og-1.png',
              },
              twitterImage: {
                sourceUrl: x,
              },
            },
            translation: x,
            team: {
              paragraphe: x,
              postes: [
                {
                  nomDuPoste: 'Video editor',
                  personnes: [
                    {
                      nom: 'Pierre-Alexandre Bouvier',
                      photo: {
                        sourceUrl: _,
                        altText: c,
                        mediaType: d,
                        title: 'TUXCO_PAB',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_PAB-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_PAB-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_PAB-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_PAB.jpg 800w',
                        mediaItemUrl: _,
                        mediaDetails: {
                          file: '2023\u002F07\u002FTUXCO_PAB.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'TUXCO_PAB-792x1000.jpg',
                              fileSize: 79489,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_PAB-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'TUXCO_PAB-300x300.jpg',
                              fileSize: 12645,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_PAB-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'TUXCO_PAB-768x970.jpg',
                              fileSize: 75068,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_PAB-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'TUXCO_PAB-16x20.jpg',
                              fileSize: V,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_PAB-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: y,
                      birthMonth: z,
                      id: '0-0',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Motion Designers',
                  personnes: [
                    {
                      nom: 'Félix Arsenault ',
                      photo: {
                        sourceUrl: $,
                        altText: c,
                        mediaType: d,
                        title: 'félix',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Ffélix-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Ffélix-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Ffélix-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Ffélix.jpg 800w',
                        mediaItemUrl: $,
                        mediaDetails: {
                          file: '2022\u002F08\u002Ffélix.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'félix-792x1000.jpg',
                              fileSize: 106676,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Ffélix-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'félix-300x300.jpg',
                              fileSize: 23072,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Ffélix-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'félix-768x970.jpg',
                              fileSize: 102125,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Ffélix-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'félix-16x20.jpg',
                              fileSize: 854,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Ffélix-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: D,
                      birthMonth: q,
                      id: '1-0',
                    },
                  ],
                },
                {
                  nomDuPoste: '3D Artist',
                  personnes: [
                    {
                      nom: 'Jean-Michel Simard',
                      photo: {
                        sourceUrl: aa,
                        altText: c,
                        mediaType: d,
                        title: 'mitch',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmitch-1-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmitch-1-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmitch-1-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmitch-1.jpg 800w',
                        mediaItemUrl: aa,
                        mediaDetails: {
                          file: '2022\u002F08\u002Fmitch-1.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'mitch-1-792x1000.jpg',
                              fileSize: 90604,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmitch-1-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'mitch-1-300x300.jpg',
                              fileSize: 18966,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmitch-1-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'mitch-1-768x970.jpg',
                              fileSize: 86579,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmitch-1-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'mitch-1-16x20.jpg',
                              fileSize: 913,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmitch-1-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: v,
                      birthMonth: A,
                      id: '2-0',
                    },
                    {
                      nom: 'Nathan Favreau',
                      photo: {
                        sourceUrl: ab,
                        altText: c,
                        mediaType: d,
                        title: 'TUXCO_NATHAN',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_NATHAN-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_NATHAN-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_NATHAN-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_NATHAN.jpg 800w',
                        mediaItemUrl: ab,
                        mediaDetails: {
                          file: '2023\u002F07\u002FTUXCO_NATHAN.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'TUXCO_NATHAN-792x1000.jpg',
                              fileSize: 67575,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_NATHAN-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'TUXCO_NATHAN-300x300.jpg',
                              fileSize: 14450,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_NATHAN-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'TUXCO_NATHAN-768x970.jpg',
                              fileSize: 64674,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_NATHAN-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'TUXCO_NATHAN-16x20.jpg',
                              fileSize: V,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_NATHAN-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: ac,
                      birthMonth: w,
                      id: '2-1',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Chief Creative Officer, Founder',
                  personnes: [
                    {
                      nom: 'Ludwig Ciupka',
                      photo: {
                        sourceUrl: ad,
                        altText: c,
                        mediaType: d,
                        title: 'ludo',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fludo-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fludo-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fludo-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fludo.jpg 800w',
                        mediaItemUrl: ad,
                        mediaDetails: {
                          file: '2022\u002F08\u002Fludo.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'ludo-792x1000.jpg',
                              fileSize: 75805,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fludo-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'ludo-300x300.jpg',
                              fileSize: 14386,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fludo-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'ludo-768x970.jpg',
                              fileSize: 72433,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fludo-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'ludo-16x20.jpg',
                              fileSize: 840,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fludo-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: y,
                      birthMonth: v,
                      id: '3-0',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Chief Executive Officer, Founder',
                  personnes: [
                    {
                      nom: 'Dominic Tremblay',
                      photo: {
                        sourceUrl: ae,
                        altText: c,
                        mediaType: d,
                        title: 'Dominic',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FDominic-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FDominic-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FDominic-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FDominic.jpg 800w',
                        mediaItemUrl: ae,
                        mediaDetails: {
                          file: '2022\u002F08\u002FDominic.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'Dominic-792x1000.jpg',
                              fileSize: 102498,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FDominic-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'Dominic-300x300.jpg',
                              fileSize: 20823,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FDominic-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'Dominic-768x970.jpg',
                              fileSize: 98443,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FDominic-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'Dominic-16x20.jpg',
                              fileSize: 878,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FDominic-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: af,
                      birthMonth: u,
                      id: '4-0',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Copywriters',
                  personnes: [
                    {
                      nom: 'Emily Wilkinson',
                      photo: {
                        sourceUrl: ag,
                        altText: c,
                        mediaType: d,
                        title: 'emily',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Femily-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Femily-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Femily-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Femily.jpg 800w',
                        mediaItemUrl: ag,
                        mediaDetails: {
                          file: '2022\u002F07\u002Femily.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'emily-792x1000.jpg',
                              fileSize: 79597,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Femily-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'emily-300x300.jpg',
                              fileSize: 15166,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Femily-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'emily-768x970.jpg',
                              fileSize: 76315,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Femily-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'emily-16x20.jpg',
                              fileSize: ah,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Femily-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: 31,
                      birthMonth: B,
                      id: '5-0',
                    },
                    {
                      nom: 'Nicolas Doyon',
                      photo: {
                        sourceUrl: ai,
                        altText: c,
                        mediaType: d,
                        title: 'Nicolas_Doyon_TUXCO',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FNicolas_Doyon_TUXCO-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FNicolas_Doyon_TUXCO-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FNicolas_Doyon_TUXCO-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FNicolas_Doyon_TUXCO.jpg 800w',
                        mediaItemUrl: ai,
                        mediaDetails: {
                          file: '2023\u002F04\u002FNicolas_Doyon_TUXCO.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'Nicolas_Doyon_TUXCO-792x1000.jpg',
                              fileSize: 118987,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FNicolas_Doyon_TUXCO-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'Nicolas_Doyon_TUXCO-300x300.jpg',
                              fileSize: 23299,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FNicolas_Doyon_TUXCO-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'Nicolas_Doyon_TUXCO-768x970.jpg',
                              fileSize: 113418,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FNicolas_Doyon_TUXCO-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'Nicolas_Doyon_TUXCO-16x20.jpg',
                              fileSize: 876,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FNicolas_Doyon_TUXCO-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: aj,
                      birthMonth: w,
                      id: '5-1',
                    },
                    {
                      nom: 'Patrick Kabongo',
                      photo: {
                        sourceUrl: ak,
                        altText: c,
                        mediaType: d,
                        title: 'Patrick_Tux',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-61-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-61-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-61-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-61.jpg 800w',
                        mediaItemUrl: ak,
                        mediaDetails: {
                          file: '2023\u002F11\u002FMicrosoftTeams-image-61.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'MicrosoftTeams-image-61-792x1000.jpg',
                              fileSize: 86680,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-61-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'MicrosoftTeams-image-61-300x300.jpg',
                              fileSize: 13712,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-61-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'MicrosoftTeams-image-61-768x970.jpg',
                              fileSize: 82442,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-61-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'MicrosoftTeams-image-61-16x20.jpg',
                              fileSize: W,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-61-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: q,
                      birthMonth: X,
                      id: '5-2',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Accountant',
                  personnes: [
                    {
                      nom: 'Julie Cai',
                      photo: {
                        sourceUrl: s,
                        altText: c,
                        mediaType: d,
                        title: E,
                        srcSet: F,
                        mediaItemUrl: s,
                        mediaDetails: {
                          file: G,
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: H,
                              fileSize: I,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl: J,
                              width: l,
                            },
                            {
                              file: K,
                              fileSize: L,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl: M,
                              width: b,
                            },
                            {
                              file: N,
                              fileSize: O,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl: P,
                              width: i,
                            },
                            {
                              file: Q,
                              fileSize: R,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl: S,
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: C,
                      birthMonth: r,
                      id: '6-0',
                    },
                    {
                      nom: 'Jérémie Hogu',
                      photo: {
                        sourceUrl: al,
                        altText: c,
                        mediaType: d,
                        title: 'selfies-01',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-01-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-01-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-01-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-01.jpg 800w',
                        mediaItemUrl: al,
                        mediaDetails: {
                          file: '2024\u002F06\u002Fselfies-01.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'selfies-01-792x1000.jpg',
                              fileSize: 66336,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-01-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'selfies-01-300x300.jpg',
                              fileSize: 14058,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-01-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'selfies-01-768x970.jpg',
                              fileSize: 63477,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-01-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'selfies-01-16x20.jpg',
                              fileSize: 833,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-01-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: 16,
                      birthMonth: T,
                      id: '6-1',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Production Coordinator',
                  personnes: [
                    {
                      nom: 'Geneviève Leblanc ',
                      photo: {
                        sourceUrl: am,
                        altText: c,
                        mediaType: d,
                        title: 'MicrosoftTeams-image (52)',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F10\u002FMicrosoftTeams-image-52-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F10\u002FMicrosoftTeams-image-52-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F10\u002FMicrosoftTeams-image-52-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F10\u002FMicrosoftTeams-image-52.jpg 800w',
                        mediaItemUrl: am,
                        mediaDetails: {
                          file: '2023\u002F10\u002FMicrosoftTeams-image-52.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'MicrosoftTeams-image-52-792x1000.jpg',
                              fileSize: 84322,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F10\u002FMicrosoftTeams-image-52-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'MicrosoftTeams-image-52-300x300.jpg',
                              fileSize: 15985,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F10\u002FMicrosoftTeams-image-52-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'MicrosoftTeams-image-52-768x970.jpg',
                              fileSize: 80163,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F10\u002FMicrosoftTeams-image-52-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'MicrosoftTeams-image-52-16x20.jpg',
                              fileSize: W,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F10\u002FMicrosoftTeams-image-52-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: x,
                      birthMonth: x,
                      id: '7-0',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Designers',
                  personnes: [
                    {
                      nom: 'Alexandre Lepage',
                      photo: {
                        sourceUrl: an,
                        altText: c,
                        mediaType: d,
                        title: 'alex-l',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Falex-l-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Falex-l-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Falex-l-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Falex-l.jpg 800w',
                        mediaItemUrl: an,
                        mediaDetails: {
                          file: '2022\u002F08\u002Falex-l.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'alex-l-792x1000.jpg',
                              fileSize: 66615,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Falex-l-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'alex-l-300x300.jpg',
                              fileSize: 13361,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Falex-l-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'alex-l-768x970.jpg',
                              fileSize: 63268,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Falex-l-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'alex-l-16x20.jpg',
                              fileSize: ao,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Falex-l-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: ap,
                      birthMonth: u,
                      id: '8-0',
                    },
                    {
                      nom: 'Eloise Daigle',
                      photo: {
                        sourceUrl: aq,
                        altText: c,
                        mediaType: d,
                        title: 'eloise-d',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feloise-d-1-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feloise-d-1-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feloise-d-1-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feloise-d-1.jpg 800w',
                        mediaItemUrl: aq,
                        mediaDetails: {
                          file: '2022\u002F08\u002Feloise-d-1.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'eloise-d-1-792x1000.jpg',
                              fileSize: 97169,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feloise-d-1-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'eloise-d-1-300x300.jpg',
                              fileSize: 19620,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feloise-d-1-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'eloise-d-1-768x970.jpg',
                              fileSize: 92949,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feloise-d-1-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'eloise-d-1-16x20.jpg',
                              fileSize: 891,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feloise-d-1-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: ar,
                      birthMonth: t,
                      id: '8-1',
                    },
                    {
                      nom: "Israël L'Italien",
                      photo: {
                        sourceUrl: as,
                        altText: c,
                        mediaType: d,
                        title: 'Israel_Tux',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-63-792x1000.png 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-63-768x970.png 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-63-16x20.png 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-63.png 800w',
                        mediaItemUrl: as,
                        mediaDetails: {
                          file: '2023\u002F11\u002FMicrosoftTeams-image-63.png',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'MicrosoftTeams-image-63-792x1000.png',
                              fileSize: 870067,
                              height: e,
                              mimeType: U,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-63-792x1000.png',
                              width: l,
                            },
                            {
                              file: 'MicrosoftTeams-image-63-300x300.png',
                              fileSize: 122492,
                              height: b,
                              mimeType: U,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-63-300x300.png',
                              width: b,
                            },
                            {
                              file: 'MicrosoftTeams-image-63-768x970.png',
                              fileSize: 822741,
                              height: m,
                              mimeType: U,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-63-768x970.png',
                              width: i,
                            },
                            {
                              file: 'MicrosoftTeams-image-63-16x20.png',
                              fileSize: 981,
                              height: j,
                              mimeType: U,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-63-16x20.png',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: q,
                      birthMonth: r,
                      id: '8-2',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Creative Web Developpers',
                  personnes: [
                    {
                      nom: 'Adrien Vanderpotte',
                      photo: {
                        sourceUrl: at,
                        altText: c,
                        mediaType: d,
                        title: 'adrien',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fadrien-1-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fadrien-1-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fadrien-1-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fadrien-1.jpg 800w',
                        mediaItemUrl: at,
                        mediaDetails: {
                          file: '2022\u002F07\u002Fadrien-1.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'adrien-1-792x1000.jpg',
                              fileSize: 83889,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fadrien-1-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'adrien-1-300x300.jpg',
                              fileSize: 15577,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fadrien-1-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'adrien-1-768x970.jpg',
                              fileSize: 80538,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fadrien-1-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'adrien-1-16x20.jpg',
                              fileSize: au,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fadrien-1-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: C,
                      birthMonth: w,
                      id: '9-0',
                    },
                    {
                      nom: 'Léo Blondin',
                      photo: {
                        sourceUrl: av,
                        altText: c,
                        mediaType: d,
                        title: 'selfies-leo-TUX',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-leo-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-leo-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-leo-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-leo.jpg 800w',
                        mediaItemUrl: av,
                        mediaDetails: {
                          file: '2024\u002F06\u002Fselfies-leo.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'selfies-leo-792x1000.jpg',
                              fileSize: 94151,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-leo-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'selfies-leo-300x300.jpg',
                              fileSize: 17958,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-leo-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'selfies-leo-768x970.jpg',
                              fileSize: 90075,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-leo-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'selfies-leo-16x20.jpg',
                              fileSize: Y,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-leo-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: Z,
                      birthMonth: B,
                      id: '9-1',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Art Directors',
                  personnes: [
                    {
                      nom: 'Edith Morin',
                      photo: {
                        sourceUrl: aw,
                        altText: c,
                        mediaType: d,
                        title: 'Edith_TUX',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FEdith_TUX-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FEdith_TUX-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FEdith_TUX-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FEdith_TUX.jpg 800w',
                        mediaItemUrl: aw,
                        mediaDetails: {
                          file: '2023\u002F04\u002FEdith_TUX.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'Edith_TUX-792x1000.jpg',
                              fileSize: 96238,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FEdith_TUX-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'Edith_TUX-300x300.jpg',
                              fileSize: 17615,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FEdith_TUX-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'Edith_TUX-768x970.jpg',
                              fileSize: 91735,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FEdith_TUX-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'Edith_TUX-16x20.jpg',
                              fileSize: ax,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FEdith_TUX-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: D,
                      birthMonth: z,
                      id: '10-0',
                    },
                    {
                      nom: 'Lochlan Doyle',
                      photo: {
                        sourceUrl: ay,
                        altText: c,
                        mediaType: d,
                        title: 'lochlan',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Flochlan-1-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Flochlan-1-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Flochlan-1-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Flochlan-1.jpg 800w',
                        mediaItemUrl: ay,
                        mediaDetails: {
                          file: '2022\u002F07\u002Flochlan-1.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'lochlan-1-792x1000.jpg',
                              fileSize: 61654,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Flochlan-1-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'lochlan-1-300x300.jpg',
                              fileSize: 10382,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Flochlan-1-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'lochlan-1-768x970.jpg',
                              fileSize: 58677,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Flochlan-1-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'lochlan-1-16x20.jpg',
                              fileSize: az,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Flochlan-1-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: Z,
                      birthMonth: z,
                      id: '10-1',
                    },
                    {
                      nom: 'Melissa Desjardins',
                      photo: {
                        sourceUrl: aA,
                        altText: c,
                        mediaType: d,
                        title: 'Melissa-Desjardin_DA_TUX',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F09\u002FMicrosoftTeams-image-48-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F09\u002FMicrosoftTeams-image-48-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F09\u002FMicrosoftTeams-image-48-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F09\u002FMicrosoftTeams-image-48.jpg 800w',
                        mediaItemUrl: aA,
                        mediaDetails: {
                          file: '2023\u002F09\u002FMicrosoftTeams-image-48.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'MicrosoftTeams-image-48-792x1000.jpg',
                              fileSize: 98138,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F09\u002FMicrosoftTeams-image-48-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'MicrosoftTeams-image-48-300x300.jpg',
                              fileSize: 16387,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F09\u002FMicrosoftTeams-image-48-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'MicrosoftTeams-image-48-768x970.jpg',
                              fileSize: 93222,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F09\u002FMicrosoftTeams-image-48-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'MicrosoftTeams-image-48-16x20.jpg',
                              fileSize: 885,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F09\u002FMicrosoftTeams-image-48-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: D,
                      birthMonth: q,
                      id: '10-2',
                    },
                    {
                      nom: 'Pamela Jaton',
                      photo: {
                        sourceUrl: aB,
                        altText: c,
                        mediaType: d,
                        title: 'pam',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fpam-1-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fpam-1-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fpam-1-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fpam-1.jpg 800w',
                        mediaItemUrl: aB,
                        mediaDetails: {
                          file: '2022\u002F08\u002Fpam-1.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'pam-1-792x1000.jpg',
                              fileSize: 77289,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fpam-1-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'pam-1-300x300.jpg',
                              fileSize: 14102,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fpam-1-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'pam-1-768x970.jpg',
                              fileSize: 73559,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fpam-1-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'pam-1-16x20.jpg',
                              fileSize: 796,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fpam-1-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: Z,
                      birthMonth: q,
                      id: '10-3',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Creative Directors',
                  personnes: [
                    {
                      nom: 'Alice Ware',
                      photo: {
                        sourceUrl: aC,
                        altText: c,
                        mediaType: d,
                        title: 'alice',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F11\u002Falice-1-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F11\u002Falice-1-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F11\u002Falice-1-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F11\u002Falice-1.jpg 800w',
                        mediaItemUrl: aC,
                        mediaDetails: {
                          file: '2022\u002F11\u002Falice-1.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'alice-1-792x1000.jpg',
                              fileSize: 51399,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F11\u002Falice-1-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'alice-1-300x300.jpg',
                              fileSize: 10762,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F11\u002Falice-1-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'alice-1-768x970.jpg',
                              fileSize: 48717,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F11\u002Falice-1-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'alice-1-16x20.jpg',
                              fileSize: aD,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F11\u002Falice-1-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: ar,
                      birthMonth: z,
                      id: '11-0',
                    },
                    {
                      nom: 'Emmanuel Mauriès-Rinfret',
                      photo: {
                        sourceUrl: s,
                        altText: c,
                        mediaType: d,
                        title: E,
                        srcSet: F,
                        mediaItemUrl: s,
                        mediaDetails: {
                          file: G,
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: H,
                              fileSize: I,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl: J,
                              width: l,
                            },
                            {
                              file: K,
                              fileSize: L,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl: M,
                              width: b,
                            },
                            {
                              file: N,
                              fileSize: O,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl: P,
                              width: i,
                            },
                            {
                              file: Q,
                              fileSize: R,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl: S,
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: y,
                      birthMonth: v,
                      id: '11-1',
                    },
                    {
                      nom: 'Louis Paquet',
                      photo: {
                        sourceUrl: aE,
                        altText: c,
                        mediaType: d,
                        title: 'louis',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Flouis-1-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Flouis-1-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Flouis-1-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Flouis-1.jpg 800w',
                        mediaItemUrl: aE,
                        mediaDetails: {
                          file: '2022\u002F08\u002Flouis-1.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'louis-1-792x1000.jpg',
                              fileSize: 97199,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Flouis-1-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'louis-1-300x300.jpg',
                              fileSize: 18462,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Flouis-1-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'louis-1-768x970.jpg',
                              fileSize: 92653,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Flouis-1-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'louis-1-16x20.jpg',
                              fileSize: 868,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Flouis-1-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: aj,
                      birthMonth: v,
                      id: '11-2',
                    },
                    {
                      nom: 'René Charles Arseneau',
                      photo: {
                        sourceUrl: aF,
                        altText: c,
                        mediaType: d,
                        title: 'rc',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Frc-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Frc-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Frc-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Frc.jpg 800w',
                        mediaItemUrl: aF,
                        mediaDetails: {
                          file: '2022\u002F08\u002Frc.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'rc-792x1000.jpg',
                              fileSize: 66724,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Frc-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'rc-300x300.jpg',
                              fileSize: 14005,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Frc-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'rc-768x970.jpg',
                              fileSize: 63619,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Frc-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'rc-16x20.jpg',
                              fileSize: 819,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Frc-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: X,
                      birthMonth: q,
                      id: '11-3',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Strategy Director',
                  personnes: [
                    {
                      nom: 'Melissa Tucker-Gagné',
                      photo: {
                        sourceUrl: aG,
                        altText: c,
                        mediaType: d,
                        title: 'mel',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmel-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmel-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmel-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmel.jpg 800w',
                        mediaItemUrl: aG,
                        mediaDetails: {
                          file: '2022\u002F08\u002Fmel.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'mel-792x1000.jpg',
                              fileSize: 75893,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmel-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'mel-300x300.jpg',
                              fileSize: 13793,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmel-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'mel-768x970.jpg',
                              fileSize: 72000,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmel-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'mel-16x20.jpg',
                              fileSize: au,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmel-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: r,
                      birthMonth: A,
                      id: '12-0',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Director Media Strategy',
                  personnes: [
                    {
                      nom: 'Evelyne Tourigny',
                      photo: {
                        sourceUrl: aH,
                        altText: c,
                        mediaType: d,
                        title: 'Evelyne_Tux',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-57-753x1000.jpg 753w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-57-1506x2000.jpg 1506w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-57-768x1020.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-57-1157x1536.jpg 1157w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-57-15x20.jpg 15w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-57.jpg 1536w',
                        mediaItemUrl: aH,
                        mediaDetails: {
                          file: '2023\u002F11\u002FMicrosoftTeams-image-57.jpg',
                          height: 2040,
                          width: 1536,
                          sizes: [
                            {
                              file: 'MicrosoftTeams-image-57-753x1000.jpg',
                              fileSize: 70696,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-57-753x1000.jpg',
                              width: '753',
                            },
                            {
                              file: 'MicrosoftTeams-image-57-1506x2000.jpg',
                              fileSize: 217564,
                              height: '2000',
                              mimeType: a,
                              name: 'large',
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-57-1506x2000.jpg',
                              width: '1506',
                            },
                            {
                              file: 'MicrosoftTeams-image-57-300x300.jpg',
                              fileSize: 14138,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-57-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'MicrosoftTeams-image-57-768x1020.jpg',
                              fileSize: 74533,
                              height: '1020',
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-57-768x1020.jpg',
                              width: i,
                            },
                            {
                              file: 'MicrosoftTeams-image-57-1157x1536.jpg',
                              fileSize: 142005,
                              height: '1536',
                              mimeType: a,
                              name: '1536x1536',
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-57-1157x1536.jpg',
                              width: '1157',
                            },
                            {
                              file: 'MicrosoftTeams-image-57-15x20.jpg',
                              fileSize: 871,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-57-15x20.jpg',
                              width: '15',
                            },
                          ],
                        },
                      },
                      birthDay: r,
                      birthMonth: r,
                      id: '13-0',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Operations Director',
                  personnes: [
                    {
                      nom: 'Frederique Bissonnet',
                      photo: {
                        sourceUrl: aI,
                        altText: c,
                        mediaType: d,
                        title: 'fred',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ffred-1-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ffred-1-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ffred-1-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ffred-1.jpg 800w',
                        mediaItemUrl: aI,
                        mediaDetails: {
                          file: '2022\u002F07\u002Ffred-1.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'fred-1-792x1000.jpg',
                              fileSize: 70825,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ffred-1-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'fred-1-300x300.jpg',
                              fileSize: 13489,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ffred-1-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'fred-1-768x970.jpg',
                              fileSize: 67695,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ffred-1-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'fred-1-16x20.jpg',
                              fileSize: 856,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ffred-1-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: aJ,
                      birthMonth: q,
                      id: '14-0',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Directors, Client Partnership',
                  personnes: [
                    {
                      nom: 'Chloé Daoust Dandurand',
                      photo: {
                        sourceUrl: aK,
                        altText: c,
                        mediaType: d,
                        title: 'chloe_d',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fchloe_d-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fchloe_d-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fchloe_d-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fchloe_d.jpg 800w',
                        mediaItemUrl: aK,
                        mediaDetails: {
                          file: '2022\u002F08\u002Fchloe_d.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'chloe_d-792x1000.jpg',
                              fileSize: 86797,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fchloe_d-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'chloe_d-300x300.jpg',
                              fileSize: 14625,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fchloe_d-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'chloe_d-768x970.jpg',
                              fileSize: 82703,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fchloe_d-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'chloe_d-16x20.jpg',
                              fileSize: aL,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fchloe_d-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: aM,
                      birthMonth: v,
                      id: '15-0',
                    },
                    {
                      nom: 'Félix Asselin',
                      photo: {
                        sourceUrl: aN,
                        altText: c,
                        mediaType: d,
                        title: 'Felix_Asselin_TUX',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F12\u002FMicrosoftTeams-image-62-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F12\u002FMicrosoftTeams-image-62-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F12\u002FMicrosoftTeams-image-62-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F12\u002FMicrosoftTeams-image-62.jpg 800w',
                        mediaItemUrl: aN,
                        mediaDetails: {
                          file: '2023\u002F12\u002FMicrosoftTeams-image-62.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'MicrosoftTeams-image-62-792x1000.jpg',
                              fileSize: 61913,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F12\u002FMicrosoftTeams-image-62-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'MicrosoftTeams-image-62-300x300.jpg',
                              fileSize: 12792,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F12\u002FMicrosoftTeams-image-62-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'MicrosoftTeams-image-62-768x970.jpg',
                              fileSize: 58957,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F12\u002FMicrosoftTeams-image-62-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'MicrosoftTeams-image-62-16x20.jpg',
                              fileSize: Y,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F12\u002FMicrosoftTeams-image-62-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: aO,
                      birthMonth: u,
                      id: '15-1',
                    },
                    {
                      nom: 'Marie-Laurence Choiniere',
                      photo: {
                        sourceUrl: aP,
                        altText: c,
                        mediaType: d,
                        title: 'malo',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmalo-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmalo-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmalo-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmalo.jpg 800w',
                        mediaItemUrl: aP,
                        mediaDetails: {
                          file: '2022\u002F08\u002Fmalo.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'malo-792x1000.jpg',
                              fileSize: 111369,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmalo-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'malo-300x300.jpg',
                              fileSize: 20335,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmalo-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'malo-768x970.jpg',
                              fileSize: 106398,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmalo-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'malo-16x20.jpg',
                              fileSize: 861,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmalo-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: aQ,
                      birthMonth: r,
                      id: '15-2',
                    },
                    {
                      nom: 'Virginie Lavallée-Corbeil',
                      photo: {
                        sourceUrl: aR,
                        altText: c,
                        mediaType: d,
                        title: 'virginie',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fvirginie-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fvirginie-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fvirginie-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fvirginie.jpg 800w',
                        mediaItemUrl: aR,
                        mediaDetails: {
                          file: '2022\u002F08\u002Fvirginie.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'virginie-792x1000.jpg',
                              fileSize: 109079,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fvirginie-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'virginie-300x300.jpg',
                              fileSize: 20493,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fvirginie-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'virginie-768x970.jpg',
                              fileSize: 104001,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fvirginie-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'virginie-16x20.jpg',
                              fileSize: Y,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fvirginie-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: aJ,
                      birthMonth: t,
                      id: '15-3',
                    },
                    {
                      nom: 'Yasmine Zeggane',
                      photo: {
                        sourceUrl: aS,
                        altText: c,
                        mediaType: d,
                        title: 'yasmine',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fyasmine-1-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fyasmine-1-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fyasmine-1-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fyasmine-1.jpg 800w',
                        mediaItemUrl: aS,
                        mediaDetails: {
                          file: '2022\u002F08\u002Fyasmine-1.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'yasmine-1-792x1000.jpg',
                              fileSize: 99682,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fyasmine-1-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'yasmine-1-300x300.jpg',
                              fileSize: 16728,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fyasmine-1-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'yasmine-1-768x970.jpg',
                              fileSize: 94941,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fyasmine-1-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'yasmine-1-16x20.jpg',
                              fileSize: aD,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fyasmine-1-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: B,
                      birthMonth: w,
                      id: '15-4',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Financial Director',
                  personnes: [
                    {
                      nom: 'Mao-Pier Héraut',
                      photo: {
                        sourceUrl: aT,
                        altText: c,
                        mediaType: d,
                        title: 'selfies-Mao-TUX',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-03-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-03-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-03-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-03.jpg 800w',
                        mediaItemUrl: aT,
                        mediaDetails: {
                          file: '2024\u002F06\u002Fselfies-03.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'selfies-03-792x1000.jpg',
                              fileSize: 72437,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-03-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'selfies-03-300x300.jpg',
                              fileSize: 15905,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-03-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'selfies-03-768x970.jpg',
                              fileSize: 69563,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-03-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'selfies-03-16x20.jpg',
                              fileSize: ah,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-03-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: X,
                      birthMonth: t,
                      id: '16-0',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Graphic Production',
                  personnes: [
                    {
                      nom: 'Jean-Michel Lavoie',
                      photo: {
                        sourceUrl: aU,
                        altText: c,
                        mediaType: d,
                        title: 'jean-mi',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjean-mi-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjean-mi-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjean-mi-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjean-mi.jpg 800w',
                        mediaItemUrl: aU,
                        mediaDetails: {
                          file: '2022\u002F08\u002Fjean-mi.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'jean-mi-792x1000.jpg',
                              fileSize: 74342,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjean-mi-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'jean-mi-300x300.jpg',
                              fileSize: 17206,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjean-mi-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'jean-mi-768x970.jpg',
                              fileSize: 71267,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjean-mi-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'jean-mi-16x20.jpg',
                              fileSize: 890,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjean-mi-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: v,
                      birthMonth: u,
                      id: '17-0',
                    },
                    {
                      nom: 'Tanya Machado',
                      photo: {
                        sourceUrl: aV,
                        altText: c,
                        mediaType: d,
                        title: 'tanya',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ftanya-1-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ftanya-1-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ftanya-1-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ftanya-1.jpg 800w',
                        mediaItemUrl: aV,
                        mediaDetails: {
                          file: '2022\u002F07\u002Ftanya-1.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'tanya-1-792x1000.jpg',
                              fileSize: 68462,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ftanya-1-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'tanya-1-300x300.jpg',
                              fileSize: 14261,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ftanya-1-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'tanya-1-768x970.jpg',
                              fileSize: 65437,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ftanya-1-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'tanya-1-16x20.jpg',
                              fileSize: W,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ftanya-1-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: D,
                      birthMonth: t,
                      id: '17-1',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Creative Leads',
                  personnes: [
                    {
                      nom: 'Marie Laurence Grenier',
                      photo: {
                        sourceUrl: aW,
                        altText: c,
                        mediaType: d,
                        title: 'marie-laurence',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fmarie-laurence-1-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fmarie-laurence-1-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fmarie-laurence-1-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fmarie-laurence-1.jpg 800w',
                        mediaItemUrl: aW,
                        mediaDetails: {
                          file: '2022\u002F07\u002Fmarie-laurence-1.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'marie-laurence-1-792x1000.jpg',
                              fileSize: 53000,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fmarie-laurence-1-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'marie-laurence-1-300x300.jpg',
                              fileSize: 10089,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fmarie-laurence-1-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'marie-laurence-1-768x970.jpg',
                              fileSize: 50664,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fmarie-laurence-1-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'marie-laurence-1-16x20.jpg',
                              fileSize: 845,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fmarie-laurence-1-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: aO,
                      birthMonth: T,
                      id: '18-0',
                    },
                    {
                      nom: 'Maude Bussières',
                      photo: {
                        sourceUrl: s,
                        altText: c,
                        mediaType: d,
                        title: E,
                        srcSet: F,
                        mediaItemUrl: s,
                        mediaDetails: {
                          file: G,
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: H,
                              fileSize: I,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl: J,
                              width: l,
                            },
                            {
                              file: K,
                              fileSize: L,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl: M,
                              width: b,
                            },
                            {
                              file: N,
                              fileSize: O,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl: P,
                              width: i,
                            },
                            {
                              file: Q,
                              fileSize: R,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl: S,
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: C,
                      birthMonth: af,
                      id: '18-1',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Lead, Client Partnership',
                  personnes: [
                    {
                      nom: 'Kim-Mai Lam',
                      photo: {
                        sourceUrl: aX,
                        altText: c,
                        mediaType: d,
                        title: 'Kim-Mai_TUX',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F09\u002FKim-Mai_TUX-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F09\u002FKim-Mai_TUX-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F09\u002FKim-Mai_TUX-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F09\u002FKim-Mai_TUX.jpg 800w',
                        mediaItemUrl: aX,
                        mediaDetails: {
                          file: '2024\u002F09\u002FKim-Mai_TUX.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'Kim-Mai_TUX-792x1000.jpg',
                              fileSize: 100555,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F09\u002FKim-Mai_TUX-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'Kim-Mai_TUX-300x300.jpg',
                              fileSize: 18531,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F09\u002FKim-Mai_TUX-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'Kim-Mai_TUX-768x970.jpg',
                              fileSize: 95997,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F09\u002FKim-Mai_TUX-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'Kim-Mai_TUX-16x20.jpg',
                              fileSize: 862,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F09\u002FKim-Mai_TUX-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: q,
                      birthMonth: C,
                      id: '19-0',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Lead, responsible commitment',
                  personnes: [
                    {
                      nom: 'Sarah Patier',
                      photo: {
                        sourceUrl: aY,
                        altText: c,
                        mediaType: d,
                        title: 'sarah',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsarah-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsarah-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsarah-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsarah.jpg 800w',
                        mediaItemUrl: aY,
                        mediaDetails: {
                          file: '2022\u002F08\u002Fsarah.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'sarah-792x1000.jpg',
                              fileSize: 81629,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsarah-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'sarah-300x300.jpg',
                              fileSize: 13844,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsarah-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'sarah-768x970.jpg',
                              fileSize: 78146,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsarah-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'sarah-16x20.jpg',
                              fileSize: aL,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsarah-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: 26,
                      birthMonth: r,
                      id: '20-0',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Studio director',
                  personnes: [
                    {
                      nom: 'Mateusz Markiewicz',
                      photo: {
                        sourceUrl: aZ,
                        altText: c,
                        mediaType: d,
                        title: 'mat',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmat-1-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmat-1-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmat-1-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmat-1.jpg 800w',
                        mediaItemUrl: aZ,
                        mediaDetails: {
                          file: '2022\u002F08\u002Fmat-1.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'mat-1-792x1000.jpg',
                              fileSize: 54883,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmat-1-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'mat-1-300x300.jpg',
                              fileSize: 11332,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmat-1-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'mat-1-768x970.jpg',
                              fileSize: 52493,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmat-1-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'mat-1-16x20.jpg',
                              fileSize: 850,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmat-1-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: z,
                      birthMonth: w,
                      id: '21-0',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Client Partners',
                  personnes: [
                    {
                      nom: 'Barbara Caselli',
                      photo: {
                        sourceUrl: s,
                        altText: c,
                        mediaType: d,
                        title: E,
                        srcSet: F,
                        mediaItemUrl: s,
                        mediaDetails: {
                          file: G,
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: H,
                              fileSize: I,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl: J,
                              width: l,
                            },
                            {
                              file: K,
                              fileSize: L,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl: M,
                              width: b,
                            },
                            {
                              file: N,
                              fileSize: O,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl: P,
                              width: i,
                            },
                            {
                              file: Q,
                              fileSize: R,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl: S,
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: T,
                      birthMonth: T,
                      id: '22-0',
                    },
                    {
                      nom: 'Chloé Guilmette',
                      photo: {
                        sourceUrl: a_,
                        altText: c,
                        mediaType: d,
                        title: 'chloe',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchloe-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchloe-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchloe-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchloe.jpg 800w',
                        mediaItemUrl: a_,
                        mediaDetails: {
                          file: '2022\u002F07\u002Fchloe.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'chloe-792x1000.jpg',
                              fileSize: 57859,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchloe-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'chloe-300x300.jpg',
                              fileSize: 12152,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchloe-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'chloe-768x970.jpg',
                              fileSize: 55261,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchloe-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'chloe-16x20.jpg',
                              fileSize: ax,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchloe-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: ac,
                      birthMonth: r,
                      id: '22-1',
                    },
                    {
                      nom: 'Julie Su',
                      photo: {
                        sourceUrl: a$,
                        altText: c,
                        mediaType: d,
                        title: 'julie',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjulie-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjulie-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjulie-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjulie.jpg 800w',
                        mediaItemUrl: a$,
                        mediaDetails: {
                          file: '2022\u002F08\u002Fjulie.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'julie-792x1000.jpg',
                              fileSize: 74187,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjulie-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'julie-300x300.jpg',
                              fileSize: 14458,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjulie-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'julie-768x970.jpg',
                              fileSize: 70713,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjulie-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'julie-16x20.jpg',
                              fileSize: 835,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjulie-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: u,
                      birthMonth: B,
                      id: '22-2',
                    },
                    {
                      nom: 'Noémie Richard-Bonesso',
                      photo: {
                        sourceUrl: ba,
                        altText: c,
                        mediaType: d,
                        title: 'TUX_Noemie_photo_VF',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUX_Noemie_photo_VF-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUX_Noemie_photo_VF-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUX_Noemie_photo_VF-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUX_Noemie_photo_VF.jpg 800w',
                        mediaItemUrl: ba,
                        mediaDetails: {
                          file: '2023\u002F07\u002FTUX_Noemie_photo_VF.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'TUX_Noemie_photo_VF-792x1000.jpg',
                              fileSize: 64853,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUX_Noemie_photo_VF-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'TUX_Noemie_photo_VF-300x300.jpg',
                              fileSize: 13211,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUX_Noemie_photo_VF-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'TUX_Noemie_photo_VF-768x970.jpg',
                              fileSize: 62143,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUX_Noemie_photo_VF-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'TUX_Noemie_photo_VF-16x20.jpg',
                              fileSize: 843,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUX_Noemie_photo_VF-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: y,
                      birthMonth: A,
                      id: '22-3',
                    },
                    {
                      nom: 'Tomy Asselin-Lapointe',
                      photo: {
                        sourceUrl: bb,
                        altText: c,
                        mediaType: d,
                        title: 'Tomy_tuxco',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FTomy_tuxco-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FTomy_tuxco-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FTomy_tuxco-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FTomy_tuxco.jpg 800w',
                        mediaItemUrl: bb,
                        mediaDetails: {
                          file: '2023\u002F04\u002FTomy_tuxco.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'Tomy_tuxco-792x1000.jpg',
                              fileSize: 92862,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FTomy_tuxco-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'Tomy_tuxco-300x300.jpg',
                              fileSize: 17352,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FTomy_tuxco-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'Tomy_tuxco-768x970.jpg',
                              fileSize: 88923,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FTomy_tuxco-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'Tomy_tuxco-16x20.jpg',
                              fileSize: 864,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FTomy_tuxco-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: t,
                      birthMonth: A,
                      id: '22-4',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Executive Producer',
                  personnes: [
                    {
                      nom: 'Christina Meunier',
                      photo: {
                        sourceUrl: bc,
                        altText: c,
                        mediaType: d,
                        title: 'chris',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchris-1-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchris-1-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchris-1-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchris-1.jpg 800w',
                        mediaItemUrl: bc,
                        mediaDetails: {
                          file: '2022\u002F07\u002Fchris-1.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'chris-1-792x1000.jpg',
                              fileSize: 89695,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchris-1-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'chris-1-300x300.jpg',
                              fileSize: 18833,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchris-1-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'chris-1-768x970.jpg',
                              fileSize: 86116,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchris-1-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'chris-1-16x20.jpg',
                              fileSize: bd,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchris-1-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: A,
                      birthMonth: B,
                      id: '23-0',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Producer',
                  personnes: [
                    {
                      nom: 'Shaida Missaghi',
                      photo: {
                        sourceUrl: be,
                        altText: c,
                        mediaType: d,
                        title: 'shaida',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fshaida-1-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fshaida-1-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fshaida-1-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fshaida-1.jpg 800w',
                        mediaItemUrl: be,
                        mediaDetails: {
                          file: '2022\u002F08\u002Fshaida-1.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'shaida-1-792x1000.jpg',
                              fileSize: 66503,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fshaida-1-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'shaida-1-300x300.jpg',
                              fileSize: 13357,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fshaida-1-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'shaida-1-768x970.jpg',
                              fileSize: 63272,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fshaida-1-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'shaida-1-16x20.jpg',
                              fileSize: az,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fshaida-1-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: y,
                      birthMonth: q,
                      id: '24-0',
                    },
                    {
                      nom: 'Ariane Baril',
                      photo: {
                        sourceUrl: bf,
                        altText: c,
                        mediaType: d,
                        title: 'Ariane_TUX',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F08\u002FAriane_TUX-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F08\u002FAriane_TUX-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F08\u002FAriane_TUX-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F08\u002FAriane_TUX.jpg 800w',
                        mediaItemUrl: bf,
                        mediaDetails: {
                          file: '2024\u002F08\u002FAriane_TUX.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'Ariane_TUX-792x1000.jpg',
                              fileSize: 74841,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F08\u002FAriane_TUX-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'Ariane_TUX-300x300.jpg',
                              fileSize: 15197,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F08\u002FAriane_TUX-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'Ariane_TUX-768x970.jpg',
                              fileSize: 71388,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F08\u002FAriane_TUX-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'Ariane_TUX-16x20.jpg',
                              fileSize: 865,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F08\u002FAriane_TUX-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: t,
                      birthMonth: u,
                      id: '24-1',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Lead, Brand Strategist',
                  personnes: [
                    {
                      nom: 'Stacy Gagnidze',
                      photo: {
                        sourceUrl: bg,
                        altText: c,
                        mediaType: d,
                        title: 'stacy',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fstacy-1-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fstacy-1-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fstacy-1-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fstacy-1.jpg 800w',
                        mediaItemUrl: bg,
                        mediaDetails: {
                          file: '2022\u002F07\u002Fstacy-1.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'stacy-1-792x1000.jpg',
                              fileSize: 68816,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fstacy-1-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'stacy-1-300x300.jpg',
                              fileSize: 14018,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fstacy-1-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'stacy-1-768x970.jpg',
                              fileSize: 65848,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fstacy-1-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'stacy-1-16x20.jpg',
                              fileSize: V,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fstacy-1-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: ap,
                      birthMonth: C,
                      id: '25-0',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Strategist',
                  personnes: [
                    {
                      nom: 'Nadia Gopaul',
                      photo: {
                        sourceUrl: bh,
                        altText: c,
                        mediaType: d,
                        title: 'selfies-Nadia-TUX',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-02-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-02-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-02-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-02.jpg 800w',
                        mediaItemUrl: bh,
                        mediaDetails: {
                          file: '2024\u002F06\u002Fselfies-02.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'selfies-02-792x1000.jpg',
                              fileSize: 83419,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-02-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'selfies-02-300x300.jpg',
                              fileSize: 15181,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-02-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'selfies-02-768x970.jpg',
                              fileSize: 79833,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-02-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'selfies-02-16x20.jpg',
                              fileSize: 849,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-02-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: r,
                      birthMonth: r,
                      id: '26-0',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Digital Media Strategist',
                  personnes: [
                    {
                      nom: 'Valérie Bourgeois',
                      photo: {
                        sourceUrl: bi,
                        altText: c,
                        mediaType: d,
                        title: 'valb',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fvalb-1-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fvalb-1-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fvalb-1-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fvalb-1.jpg 1080w',
                        mediaItemUrl: bi,
                        mediaDetails: {
                          file: '2022\u002F07\u002Fvalb-1.jpg',
                          height: 1364,
                          width: 1080,
                          sizes: [
                            {
                              file: 'valb-1-792x1000.jpg',
                              fileSize: 117894,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fvalb-1-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'valb-1-300x300.jpg',
                              fileSize: 19840,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fvalb-1-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'valb-1-768x970.jpg',
                              fileSize: 112411,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fvalb-1-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'valb-1-16x20.jpg',
                              fileSize: ao,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fvalb-1-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: aQ,
                      birthMonth: t,
                      id: '27-0',
                    },
                  ],
                },
                {
                  nomDuPoste: 'VP Creation',
                  personnes: [
                    {
                      nom: 'Simon Chénier-Gauvreau',
                      photo: {
                        sourceUrl: bj,
                        altText: c,
                        mediaType: d,
                        title: 'simon',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsimon-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsimon-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsimon-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsimon.jpg 800w',
                        mediaItemUrl: bj,
                        mediaDetails: {
                          file: '2022\u002F08\u002Fsimon.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'simon-792x1000.jpg',
                              fileSize: 90405,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsimon-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'simon-300x300.jpg',
                              fileSize: 17301,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsimon-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'simon-768x970.jpg',
                              fileSize: 86434,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsimon-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'simon-16x20.jpg',
                              fileSize: bd,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsimon-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: t,
                      birthMonth: w,
                      id: '28-0',
                    },
                  ],
                },
                {
                  nomDuPoste: 'Executive VP, Partner',
                  personnes: [
                    {
                      nom: 'Pierre-André Vigneault ',
                      photo: {
                        sourceUrl: bk,
                        altText: c,
                        mediaType: d,
                        title: 'PA',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FPA-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FPA-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FPA-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FPA.jpg 800w',
                        mediaItemUrl: bk,
                        mediaDetails: {
                          file: '2022\u002F08\u002FPA.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'PA-792x1000.jpg',
                              fileSize: 76472,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FPA-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'PA-300x300.jpg',
                              fileSize: 11333,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FPA-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'PA-768x970.jpg',
                              fileSize: 72829,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FPA-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'PA-16x20.jpg',
                              fileSize: 834,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FPA-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: aM,
                      birthMonth: u,
                      id: '29-0',
                    },
                  ],
                },
                {
                  nomDuPoste: 'VP Client Partnership',
                  personnes: [
                    {
                      nom: 'Eve-Marie Boutet',
                      photo: {
                        sourceUrl: bl,
                        altText: c,
                        mediaType: d,
                        title: 'eve-marie',
                        srcSet:
                          'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feve-marie-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feve-marie-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feve-marie-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feve-marie.jpg 800w',
                        mediaItemUrl: bl,
                        mediaDetails: {
                          file: '2022\u002F08\u002Feve-marie.jpg',
                          height: o,
                          width: p,
                          sizes: [
                            {
                              file: 'eve-marie-792x1000.jpg',
                              fileSize: 157426,
                              height: e,
                              mimeType: a,
                              name: f,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feve-marie-792x1000.jpg',
                              width: l,
                            },
                            {
                              file: 'eve-marie-300x300.jpg',
                              fileSize: 25440,
                              height: b,
                              mimeType: a,
                              name: g,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feve-marie-300x300.jpg',
                              width: b,
                            },
                            {
                              file: 'eve-marie-768x970.jpg',
                              fileSize: 150218,
                              height: m,
                              mimeType: a,
                              name: h,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feve-marie-768x970.jpg',
                              width: i,
                            },
                            {
                              file: 'eve-marie-16x20.jpg',
                              fileSize: 838,
                              height: j,
                              mimeType: a,
                              name: k,
                              sourceUrl:
                                'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feve-marie-16x20.jpg',
                              width: n,
                            },
                          ],
                        },
                      },
                      birthDay: 14,
                      birthMonth: q,
                      id: '30-0',
                    },
                  ],
                },
              ],
            },
          },
        },
      ],
      fetch: {},
      mutations: [],
    }
  })(
    'image\u002Fjpeg',
    '300',
    '',
    'image',
    '1000',
    'medium',
    'thumbnail',
    'medium_large',
    '768',
    '20',
    'custom-lazy',
    '792',
    '970',
    '16',
    1010,
    800,
    9,
    1,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F08\u002Fplaceholder.jpg',
    3,
    6,
    12,
    5,
    null,
    13,
    2,
    4,
    7,
    8,
    24,
    'placeholder',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F08\u002Fplaceholder-792x1000.jpg 792w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F08\u002Fplaceholder-768x970.jpg 768w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F08\u002Fplaceholder-16x20.jpg 16w, https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F08\u002Fplaceholder.jpg 800w',
    '2023\u002F08\u002Fplaceholder.jpg',
    'placeholder-792x1000.jpg',
    38915,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F08\u002Fplaceholder-792x1000.jpg',
    'placeholder-300x300.jpg',
    7348,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F08\u002Fplaceholder-300x300.jpg',
    'placeholder-768x970.jpg',
    36742,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F08\u002Fplaceholder-768x970.jpg',
    'placeholder-16x20.jpg',
    810,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F08\u002Fplaceholder-16x20.jpg',
    11,
    'image\u002Fpng',
    846,
    858,
    10,
    853,
    28,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_PAB.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Ffélix.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmitch-1.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUXCO_NATHAN.jpg',
    27,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fludo.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FDominic.jpg',
    22,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Femily.jpg',
    872,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FNicolas_Doyon_TUXCO.jpg',
    20,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-61.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-01.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F10\u002FMicrosoftTeams-image-52.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Falex-l.jpg',
    859,
    18,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feloise-d-1.jpg',
    15,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-63.png',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fadrien-1.jpg',
    860,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-leo.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FEdith_TUX.jpg',
    857,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Flochlan-1.jpg',
    844,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F09\u002FMicrosoftTeams-image-48.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fpam-1.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F11\u002Falice-1.jpg',
    851,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Flouis-1.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Frc.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmel.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F11\u002FMicrosoftTeams-image-57.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ffred-1.jpg',
    21,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fchloe_d.jpg',
    863,
    23,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F12\u002FMicrosoftTeams-image-62.jpg',
    29,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmalo.jpg',
    19,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fvirginie.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fyasmine-1.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-03.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjean-mi.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Ftanya-1.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fmarie-laurence-1.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F09\u002FKim-Mai_TUX.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsarah.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fmat-1.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchloe.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fjulie.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F07\u002FTUX_Noemie_photo_VF.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2023\u002F04\u002FTomy_tuxco.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fchris-1.jpg',
    879,
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fshaida-1.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F08\u002FAriane_TUX.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fstacy-1.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2024\u002F06\u002Fselfies-02.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F07\u002Fvalb-1.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Fsimon.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002FPA.jpg',
    'https:\u002F\u002Ffolio.tux.work\u002Fwp-content\u002Fuploads\u002F2022\u002F08\u002Feve-marie.jpg',
  ))
