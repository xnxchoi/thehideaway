'use client'
import gsap from 'gsap/all'
import '@/styles/__reviewCard.scss'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import ScrollTrigger from 'gsap/ScrollTrigger'
import { useGSAP } from '@gsap/react'
import { useWindowResize } from '@/utilities/use_window_resize'
import Image from 'next/image'
import { useCursorStore, useRPStore } from '@/providers/RP_Pro'

gsap.registerPlugin(ScrollTrigger)

export const RP_POLAROID = () => {
  const config = {
    author: '<NAME>', review: 'Hi', image: '/media/ff.jpeg',
  }
  const section = useRef<HTMLElement>(null!), img = useRef<HTMLImageElement>(null!),
    footer = useRef<HTMLDivElement>(null!), author = useRef<HTMLSpanElement>(null!)
  const container = useRef<HTMLDivElement>(null!), frameContent = useRef<HTMLDivElement>(null!),
    imageContainer = useRef<HTMLDivElement>(null!), frameContainer = useRef<HTMLDivElement>(null!),
    frameContentInner = useRef<HTMLDivElement>(null!), framePositioning = useRef<HTMLDivElement>(null!),
    timeline = useRef<GSAPTimeline>(null!), logo = useRef<SVGSVGElement>(null!)
  const [osH, setOsH] = useState(0)
  const theme = useRPStore((l) => l.theme)
  const white = 'oklch(87.61% 0 118.54/1)'
  const black = 'oklch(9.69% 0.0175 23.79/1)'
  const [sectionBG, setSectionBG] = useState('')
  const [sectionFG, setSectionFG] = useState('')
  useEffect(() => {
    setSectionBG(theme === 'dark' ? black : white)
    setSectionFG(theme === 'dark' ? white : black)
  }, [])
  useEffect(() => {
    setSectionBG(theme === 'dark' ? black : white)
    setSectionFG(theme === 'dark' ? white : black)
  }, [theme])
  useEffect(() => {
    console.log(sectionBG, sectionFG)
  }, [sectionBG, sectionFG])
  const windowResize = useWindowResize({ detectHeightChange: true })
  const [wW, setWW] = useState(0)
  useEffect(() => {
    setWW(window.innerWidth)
  }, [windowResize])
  const [height, setHeight] = useState(0), [y, setY] = useState(0)
  useEffect(() => {
    setOsH(container.current.offsetHeight)
    setWW(window.innerWidth)
  })

  const calculatePositioning = useMemo(() => () => {
    setY(wW >= 767 ? -5 : -100)
    setHeight(wW >= 967 ? 30 : wW >= 767 ? -70 : 160)
  }, [setHeight, setY, wW])
  const setCursorTheme = useCursorStore(r => r.setCursorTheme)[0]
  useEffect(() => {
    setOsH(container.current.offsetHeight)
    calculatePositioning()
  }, [wW])
  const offCursor = useCallback(() => {
    setCursorTheme(theme)
  }, [setCursorTheme, theme])
  const onCursor = useCallback(() => {
    setCursorTheme(theme === 'dark' ? 'light' : 'dark')
  }, [setCursorTheme, theme])
  useGSAP(() => {
    if (!framePositioning.current || !frameContainer.current || !frameContent.current || !imageContainer.current || !framePositioning.current) {
      return
    }
    const width = framePositioning.current.offsetWidth
    const newHeight = framePositioning.current.offsetHeight + height
    const newY = framePositioning.current.offsetTop + y
    console.log(newHeight, newY)

    const newX = framePositioning.current.offsetLeft
    const borderWidth = parseInt(getComputedStyle(frameContainer.current).borderWidth, 10) || 0
    gsap.set(frameContentInner.current, {
      width: framePositioning.current.offsetWidth - borderWidth * 2,
    })
    if (timeline.current) {
      timeline.current.kill()
    }
    gsap.killTweensOf([frameContainer.current, frameContent.current, imageContainer.current])
    timeline.current = gsap.timeline({
      scrollTrigger: {
        trigger: section.current,
        start: 'top+=20% bottom',
        end: `top+=${osH + 40}px bottom`,
        scrub: true,
        markers: false,
        onEnter: () => {
          gsap.set(section.current, {
            autoAlpha: 1,
          })
        },
      },
    }).fromTo([author.current, logo.current], {
      backgroundColor: sectionBG, color: sectionFG,
    }, { backgroundColor: sectionFG, color: sectionBG }, 0).fromTo(frameContainer.current, {
      width: window.innerWidth + 48,
      height: window.innerHeight + 48,
      y: -24,
      x: -24,
      borderWidth: 40,
      borderColor: sectionBG,
    }, {
      width: width,
      height: newHeight - newY,
      y: 2 * newY,
      x: newX,
      borderWidth: 16,
      ease: 'Power2.easeInOut',
      borderColor: sectionFG,
    }, '<').fromTo(frameContent.current, {
      y: '405%', scale: 1.1, backgroundColor: sectionBG, color: sectionFG,
    }, {
      y: 0, scale: 1.01, ease: 'Power2.easeOut', backgroundColor: sectionFG, color: sectionBG,
    }, '<').fromTo(imageContainer.current, {
      width: window.innerWidth + 20, scale: 1.01, y: '-20%', x: 0,
    }, {
      y: 2 * newY + 15, x: width / 2 + 30, height: newY * 3.5, width: width - 20, ease: 'Power2.easeOut',
    }, '<+=.08')
  }, [y, height, theme, sectionBG, sectionFG])

  return (<section ref={section} className="my-[90px]">
    <div ref={container}>
      <div className="review__card-bg_card">
        <div ref={framePositioning} className="review__card-bg_frame-positioning" onMouseEnter={onCursor}
             onMouseLeave={offCursor} />
        <div ref={imageContainer} className="review__card-bg_image-container">
          <Image width={wW} height={400} alt={'an image of a reviewer'} ref={img} src={config.image}
                 className="review__card-bg_image" />
        </div>
        <div ref={frameContainer} className="review__card-bg_frame-container">
          <div ref={frameContent} className="review__card-bg_frame-content">
            <div ref={frameContentInner} className="review__card-bg_frame-content-inner">
              <blockquote className="review__card-bg_quote">WHOA</blockquote>
              <div ref={footer} className="review__card-bg_footer">
                <address data-themed="color">
                <span ref={author} className="review__card-bg_author">
                  Hi
                </span>
                  <span className="review__card-bg_authorDash">&nbsp;-&nbsp;</span>
                  <span className="review__card-bg_source"></span>
                </address>
                <svg className="review__card-bg_logo" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 45 45" ref={logo}>
                  <g id="ha_ww">
                    <path
                      d="m10.17,42.82l-.05-40.63c0-.27.29-.5.64-.5h3.14c.35,0,.64.22.64.5l.03,25.87c0,.27.29.5.64.5h13.63c.35,0,.64-.23.64-.52v-10.96c-.01-.27.27-.5.63-.5h3.14c.35,0,.64.22.64.5l.03,25.74c0,.27-.29.5-.64.5h-3.14c-.35,0-.64-.22-.64-.5v-12.39c-.01-.27-.3-.5-.65-.5h-13.63c-.35,0-.64.23-.64.52v12.39c.01.27-.27.5-.63.5h-3.14c-.35,0-.64-.22-.64-.5h0Z"
                      data-themed={'fill'} fill="currentColor" strokeWidth={0} />
                    <circle cx="31.97" cy={7} data-filled={'fill'} r="2.91" fill="currentColor" strokeWidth={0} />
                  </g>
                </svg>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>)
}
