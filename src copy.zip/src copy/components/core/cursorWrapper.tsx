import { useCursorStore } from '@/providers/RP_Pro'
import { useIsMobile } from '@/utilities/getBreakpoints'
import { Component, ComponentProps, MouseEventHandler, useCallback } from 'react'
import { ThreeEvent } from '@react-three/fiber'


type DOMMouseEventHandler<T> = (event: React.MouseEvent<T>) => void
type ThreePointerEventHandler = (event: ThreeEvent<PointerEvent>) => void

interface UseCursorHandlersOptions<T = HTMLElement> {
  onEnter?: DOMMouseEventHandler<T> | ThreePointerEventHandler
  onLeave?: DOMMouseEventHandler<T> | ThreePointerEventHandler
}
type SomeDivProps=ComponentProps<'div'>&{
  customStuff1?:string;
  customStuff2?:number;

}

interface CursorHandlers<T = HTMLElement> {
  onMouseEnter: DOMMouseEventHandler<T>
  onMouseLeave: DOMMouseEventHandler<T>
  onPointerOver: ThreePointerEventHandler
  onPointerOut: ThreePointerEventHandler
}


type EventType = 'dom' | 'three'

type EventHandlers<T extends EventType, E> = T extends 'dom'
  ? {
    onMouseEnter: (e: React.MouseEvent<E>) => void
    onMouseLeave: (e: React.MouseEvent<E>) => void
  }
  : {
    onPointerOver: (e: ThreeEvent<PointerEvent>) => void
    onPointerOut: (e: ThreeEvent<PointerEvent>) => void
  }

type CursorHandlersOptions<T extends EventType, E> = Partial<{
  onEnter: T extends 'dom'
    ? (e: React.MouseEvent<E>) => void
    : (e: ThreeEvent<PointerEvent>) => void
  onLeave: T extends 'dom'
    ? (e: React.MouseEvent<E>) => void
    : (e: ThreeEvent<PointerEvent>) => void
}>

export function useCursorHandlers<T extends EventType, E = HTMLElement>(
  type: T,
  { onEnter, onLeave }: CursorHandlersOptions<T, E> = {},
): EventHandlers<T, E> {
  const { isMobile } = useIsMobile()
  const setCur = useCursorStore((l) => l.setCursorState)[0]
  const handleEnter = useCallback(
    (e: any) => {

      !isMobile && setCur('FOCUS')
      onEnter?.(e)
    },
    [onEnter],
  )

  const handleLeave = useCallback(
    (e: any) => {
      !isMobile && setCur(null)
      onLeave?.(e)
    },
    [onLeave],
  )

  return type === 'dom'
    ? ({
      onMouseEnter: handleEnter,
      onMouseLeave: handleLeave,
    } as EventHandlers<T, E>)
    : ({
      onPointerOver: handleEnter,
      onPointerOut: handleLeave,
    } as EventHandlers<T, E>)
}