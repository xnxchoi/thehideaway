import { ComponentProps, ComponentPropsWithoutRef } from 'react'
import Image from 'next/image'
import { Link } from 'src/components/UX/Link'
import { Post } from '@/payload-types'
import { DateTime } from 'luxon'
import { HomeSquare } from '@/components/layouts/HomeSquare'
import { RP_BadgeTag } from '@/components/UX/RP_BadgeTag'
import { FrontImage } from '@/components/UX/Media/FrontImage'

export type FoundArticle =Partial<Post>

export const HomeArticleLayout = (props: { posts: FoundArticle[] }) => {
  const { posts } = props
  return (<div
    className="mb-[48px] p-[2rem] rounded-[2rem] justify-center gap-x-[20px] md:block lg:ml-[2rem] lg:mr-[2rem] xl:flex xl:gap-x-[90px] xl:mb-[100px]"
    style={{
      background: 'linear-gradient(180deg, oklch(var(--faded-bg)/1), oklch(var(--bg)/0))',
    }}>
    <div
      className="mb-6 border-b-[1px] border-solid border-[oklch(var(--fg)/1)] md:flex-[1] md:border-b-[none] md:pb-0 md:min-w-1/2 lg:min-w-[680px]">
      <div className="grid grid-cols-[1fr_1fr] gap-y-[20px] lg:grid-cols-[repeat(4,1fr)] lg:gap-x-[20px]">
        <HomeSquare article={posts[0]} />
        <Link href={'/posts/' + posts[1].slug} className="bg-transparent decoration-[none] break-words grid
              border-b-[1px]
              gap-y-[20px]
              p-[20px] pl-0
              border-solid
              border-[color:oklch(var(--fg)/.5)]
              border-t-[1px] border-r-[1px]
              lg:gap-x-[20px]
              lg:grid-cols-[1fr_1fr]
              lg:col-[1/2]
              lg:col-[1/3]
              lg:row-[2]
              lg:mr-[-10px]">
          <div className="relative w-full min-h-[1px] min-w-[1px] rounded-[5px] self-start pt-[100%] lg:row-[1/3]">
            {posts[1].heroImage && (<FrontImage
              imgClassName="rounded-[5px] absolute object-cover top-0 block w-full h-full max-w-[100%] border-0 transition-opacity duration-400 backface-hidden"
              resource={posts[1].heroImage} />)}
          </div>
          <RP_BadgeTag content={posts[1]?.category&&typeof posts[1].category!=='number'&&posts[1].category.title||'RP'} />
          <p className="text-[16px] m-0 tracking-[-.01em] font-bold lg:row-[2] lg:col-[2] lg:self-end">
            <span>{posts[1].title}</span>
          </p>
        </Link>
        <Link href={'/posts/' + posts[2].slug} className="bg-transparent
              decoration-[none] break-words grid border-r-0
              border-t-[1px] border-b-[1px] p-[20px] gap-y-[20px]
              pr-0 lg:col-[3/5] lg:ml-[-10px] lg:mr-[0px]
              border-[color:oklch(var(--fg)/.5)]
              lg:grid-cols-[1fr_1fr] lg:gap-x-[20px] lg:row-[2]">
          <div
            className="relative w-full min-h-[1px] min-w-[1px] rounded-[5px] self-start pt-[100%] lg:row-[1/3] lg:aspect-square">
            {posts[2].heroImage && (<FrontImage
              imgClassName="rounded-[5px] absolute object-cover top-0 block w-full h-full max-w-[100%] border-0 transition-opacity duration-400 backface-hidden"
              resource={posts[2].heroImage} />)}
          </div>
          <RP_BadgeTag content={posts[2]?.category&&typeof posts[2].category!=='number'&&posts[2].category.title||'RP'} />
          <p className="text-[16px] m-0 tracking-[-.01em] font-bold lg:row-[2] lg:col-[2] lg:self-end">
            <span>{posts[2].title}</span>
          </p>
        </Link>
      </div>
    </div>
    <ArticleList posts={posts} />
  </div>)
}
const ArticleList = (props: { posts: FoundArticle[] } & ComponentProps<'div'>) => {
  const { posts, ...rest } = props

  return (<div className="w-full max-w-[510px] m-auto pt-[1rem] md:max-w-[420px] md:m-0" {...rest}>
    <div>
      <div className="flex justify-between items-center gap-x-[16px] mb-0"><h2 className="text-[16px]">
        Top Articles </h2></div>
    </div>
    {posts.length > 0 ? posts.map((doc, index) => {
      const { title, publishedAt, populatedAuthor, author, heroImage, slug } = doc
      let image = ''
      if (heroImage && typeof heroImage === 'object' && heroImage.thumbnailURL) {
        image = heroImage.thumbnailURL
      } else {
        if (typeof heroImage === 'string') {
          image = heroImage
        }
      }

      let autho =(populatedAuthor&&populatedAuthor.length>0 && populatedAuthor.at(0)?.name)||'Author'

      return (<Article index={index} image={image} author={autho } title={title!} date={publishedAt || ''}
                       link={`/posts/${slug}`} key={index} />)
    }) : [1, 2, 3, 4, 5].map(() => (
      <div className="flex justify-between items-center gap-x-[16px] mb-0"><h2 className="text-[16px]"></h2></div>))}
  </div>)
}
export type ArticleProps = {
  title: string, image: string, link: string, date: string, author: string, index: number,
}
const Article = (props: ComponentPropsWithoutRef<'div'> & ArticleProps) => {
  const { title, image, link, date, author, index } = props
  return (<>
    <div
      className="flex text-[1.1rem] w-[20px] h-[20px] items-center justify-center mt-[20px] ml-[4px] rounded-[50%] bg-[oklch(var(--off-fg)/.4)] z-[10] absolute md:mt-[20px] md:ml-[-40px]">{index + 1}</div>
    <div
      className="pt-[16px] pb-[16px] pl-0 pr-0 flex flex-row-reverse justify-between relative border-[color:oklch(var(--fg)/.5)] border-b-[1px] lg:pt-[20px] lg:pb-[20px]">
      <div className="self-start aspect-square ml-[16px] relative h-[75px] bg-[oklch(var(--off-bg)/.1)]">
        <div>
          {image && (<Image alt={title} width={200} height={200}
                            className="border-solid border-[1px] border-color-[oklch(var(--off-bg)/.9)] radius-[4px]"
                            style={{
                              position: 'absolute', height: '100%', width: '100%', inset: 0, color: 'transparent',
                            }} sizes="100px" src={image} />)}
        </div>
      </div>
      <div className="self-start grow">
        <div>
          <div>
            <div>
              <div className="text-[18px] tracking-normal lg:text-[20px]">
                <Link
                  className="font-bold shadow-[inset 0 -1px 0 0 transparent] before:absolute before:inset-0 before:w-full before:h-full before:z-[1] before:content-['']"
                  href={link}>
                  {title}
                </Link>
              </div>
            </div>
            <div className="mt-[6px] leading-[1px] relative">
          <span className="inline tracking-[0.1em] uppercase text-[1.1rem]">
            <span>
              {author}
            </span>
          </span>
              <span className="ml-[.75em] inline tracking-[0.1em] uppercase text-[1.1rem]">

            <time dateTime={date}>{date.length > 0 && DateTime.fromISO(date).toRelative()}</time>
          </span>
              <span
                className="inline tracking-[0.1em] uppercase text-[1.1rem] before:content-['|'] mx-3 text-[oklch(var(--faded-fg)/1)]">
            <Link className="whitespace-nowrap" href={link + '/#comments'}>
              <svg className="align-middle inline mr-1 fill-current" width={12} height={12} fill="none"
                   viewBox="0 0 12 12" xmlns="http://www.w3.org/2000/svg">
                <title>Comments</title>
                <desc>Comment Icon Bubble</desc>
                <path fillRule="evenodd" clipRule="evenodd"
                      d="M2.8999 2.10001C2.76729 2.10001 2.64012 2.15268 2.54635 2.24645C2.45258 2.34022 2.3999 2.4674 2.3999 2.60001V9.3929L3.6928 8.10001H9.8999C10.0325 8.10001 10.1597 8.04733 10.2535 7.95356C10.3472 7.85979 10.3999 7.73261 10.3999 7.60001V2.60001C10.3999 2.4674 10.3472 2.34022 10.2535 2.24645C10.1597 2.15268 10.0325 2.10001 9.8999 2.10001H2.8999ZM1.83924 1.53935C2.12055 1.25804 2.50208 1.10001 2.8999 1.10001H9.8999C10.2977 1.10001 10.6793 1.25804 10.9606 1.53935C11.2419 1.82065 11.3999 2.20218 11.3999 2.60001V7.60001C11.3999 7.99783 11.2419 8.37936 10.9606 8.66067C10.6793 8.94197 10.2977 9.10001 9.8999 9.10001H4.10701L1.3999 11.8071V2.60001C1.3999 2.20218 1.55794 1.82065 1.83924 1.53935Z" />
              </svg>
              <span className="coral-count">
                <span className="text-[1.1rem] tracking-widest uppercase text-[oklch(var(--faded-fg)/1)]"></span>
              </span>
            </Link>
          </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  </>)
}