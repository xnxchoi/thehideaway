
import { Canvas } from '@react-three/fiber'
import { Environment, Lightformer, Loader, useTexture } from '@react-three/drei'
import { Physics } from '@react-three/rapier'
import { RP_Plate } from '@/components/layouts/Registration/Plate'
import { useRef } from 'react'
import { Color } from 'three'
import { getDeviceInfo } from '@/providers/RP_Pro'
import { KineticProvider, useKinetics } from '@/components/layouts/Registration/KineticProvider'
import { MembershipBadge } from '@/components/layouts/Registration/MembershipBadge'
export type MemberCardsType = 'BADGE' | 'PLATE'

export function Lanyard(props: { type: MemberCardsType | string }) {
  const { type } = props
  return <KineticProvider><Registerer type={type} /> <Loader barStyles={{
    backgroundColor: 'oklch(54.74% 0.2224 29.01/.5)', borderRadius: '1px',
  }} containerStyles={{
    transition: 'all 0.5s ease',
    zIndex: 247,
    backgroundColor: 'rgba(0,0,0,.1)',
    backdropFilter: 'blur(4px)',
    borderRadius: '10px',
    padding: '10px',
    position: 'absolute',
  }} /></KineticProvider>
}

function Registerer(props: { type: MemberCardsType | string }={type: 'BADGE' as MemberCardsType}) {
  const { type } = props
  const { device, isTouchDevice } = getDeviceInfo()
  const isMouse = device.type !== 'mobile' && !isTouchDevice
  const { move } = useKinetics()

  return  (<div className="relative h-full w-full">
    <Canvas style={{ right: '0', top: '0', bottom: '0', position: 'absolute', left: '0' }}
            camera={{ position: [0, 0, 13], fov: type === 'BADGE' ? 25 : 35 }}
            frameloop={(type === 'BADGE' || move) ? 'always' : 'demand'}>
      <ambientLight intensity={Math.PI} />
      {type === 'BADGE' && (<Physics debug={false} interpolate={true} gravity={[0, -40, 0]} timeStep={1 / 60}>
        <MembershipBadge />
      </Physics>) || (<RP_Plate />)}
      <Environment background blur={0.75}>
        <color attach="background" args={[new Color('rgb(1,1,1)')]} />
        <Lightformer intensity={16} color={'rgb(64, 64, 64)'}
          // position={[-2, -5, 1.1]} position={[0, -3.8, 2]} rotation={[2.14, 0.97, 2.16]} rotation={[3, 0.3, 6.3]}
                     scale={[16, 1, 1]} />
        <Lightformer intensity={2} color="white" position={[0, -1, 5]} rotation={[0, 0, Math.PI / 3]}
                     scale={[100, 0.1, 1]} />
        <Lightformer intensity={3} color="white" position={[-1, -1, 1]} rotation={[0, 0, Math.PI / 3]}
                     scale={[100, 0.1, 1]} />
        <Lightformer intensity={3} color="white" position={[1, 1, 1]} rotation={[0, 0, Math.PI / 3]}
                     scale={[100, 0.1, 1]} />
        <Lightformer intensity={10} color="white" position={[-10, 0, 14]} rotation={[0, Math.PI / 2, Math.PI / 3]}
                     scale={[100, 10, 1]} />
      </Environment>
    </Canvas></div>)
}
