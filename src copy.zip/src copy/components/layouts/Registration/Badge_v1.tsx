'use client'
import { useCallback, useEffect, useMemo, useRef, useState } from 'react'
import * as THREE from 'three'
import { Color, Mesh, Object3D, Texture, Vector2, Vector3 } from 'three'
import { Center, Text3D, useGLTF, useTexture } from '@react-three/drei'
import { extend, ThreeElements, ThreeEvent, useFrame, useThree } from '@react-three/fiber'
import {
  BallCollider, CuboidCollider, RapierRigidBody, RigidBody, RigidBodyTypeString, useRopeJoint, useSphericalJoint,
} from '@react-three/rapier'
import { MeshLineGeometry, MeshLineMaterial, raycast } from 'meshline'
import { ScreenSizerProps } from '@react-three/drei/core/ScreenSizer'
import { FONTFACES } from '@/constants/api'
import { getDeviceInfo, useCursorStore } from '@/providers/RP_Pro'
import { easing } from 'maath'
import { useKinetics } from '@/components/layouts/Registration/KineticProvider'
import { useFormContext, useWatch } from 'react-hook-form'
import gsap from 'gsap/all'
import { RootRef } from '@react-three/uikit'

extend({ MeshLineGeometry, MeshLineMaterial })
const pathway = '/assets/plate/apr25_textures/badge'
declare module '@react-three/fiber' {
  interface ThreeElements {
    meshLine: Mesh & MeshLineGeometry & MeshLineMaterial & { raycast: ReturnType<typeof raycast> }
    meshLineMaterial: Partial<MeshLineMaterial>
    meshLineGeometry: Partial<MeshLineGeometry>
    screenSizer: Partial<ScreenSizerProps> & Partial<ThreeElements['object3D']>
  }
}
useGLTF.preload('/assets/plate/apr25_textures/badge/BADGEd-transformed.glb')
useTexture.preload('/assets/plate/apr25_textures/grain_metal/frame_displacement.jpg')

function materialConfigurer(props: {
  normal?: Texture
  roughness: Texture
  map: Texture
  displacement?: Texture
}) {
  const { normal, roughness, map, displacement } = props
  const { size } = useThree()
  roughness.wrapS = roughness.wrapT = THREE.RepeatWrapping
  let topass: {
    normalMap?: Texture
    normalScale?: Vector2
    bumpMap?: Texture
    bumpScale?: number
    roughnessMap: Texture
    map: Texture
    roughness: number
    metalness: number
  } = {
    roughnessMap: roughness, map: map, roughness: 1, metalness: 1,
  }
  if (normal) {
    topass = {
      ...topass, normalMap: normal, normalScale: new THREE.Vector2(size.width, size.height),
    }
  } else if (displacement) {
    topass = {
      ...topass, bumpScale: 1, bumpMap: displacement,
    }
  }
  return topass
}

export function Badger({ maxSpeed = 50, minSpeed = 10 }) {
  const band = useRef<ThreeElements['mesh'] & { geometry: MeshLineGeometry; material: MeshLineMaterial }>(null!),
    fixed = useRef<RapierRigidBody & { lerped: Vector3 }>(null!),
    j1 = useRef<RapierRigidBody & { lerped: Vector3 }>(null!),
    j2 = useRef<RapierRigidBody & { lerped: Vector3 }>(null!),
    j3 = useRef<RapierRigidBody & { lerped: Vector3 }>(null!),
    card = useRef<RapierRigidBody & ThreeElements['mesh']>(null!)
  const { setMove } = useKinetics()
  const vec = new THREE.Vector3(), ang = new THREE.Vector3(), rot = new THREE.Vector3(), dir = new THREE.Vector3(),
    dire = new THREE.Vector3()
  const segmentProps: {
    type: RigidBodyTypeString
    canSleep: boolean
    colliders?: any
    angularDamping: number
    linearDamping: number
  } = {
    type: 'dynamic', canSleep: true, colliders: false, angularDamping: 2, linearDamping: 2,
  }
  // Clamp angular velocity for stability
  const maxAngularVelocity = 2 // Adjust for the desired max speed


  const model = useGLTF(`${pathway}/BADGEd-transformed.glb`)
  const texture = useTexture('/assets/model/ha.png')
  const displacement = useTexture('/assets/plate/apr25_textures/grain_metal/frame_displacement.jpg')
  displacement.mapping = 300
  const [maxW, setMaxW] = useState(1)
  const [maxH, setMaxH] = useState(1)
  const needsMeasurement = useRef(false)
  const [minW, setMinW] = useState(1)
  const [minH, setMinH] = useState(1)
  const [scale, setScale] = useState(1)
  const scaledVec = useMemo(() => new THREE.Vector3(scale * 0.1, scale * 0.1, 0.1), [scale])
  const [cardSize, setCardSize] = useState({ width: 3.1, height: 2 })
  const { width, height } = useThree((state) => state.size)
  const { isMobile } = getDeviceInfo()
  const setCursorState = useCursorStore((l) => l.setCursorState)[0]
  const hMI = useMemo(() => (state: string | null) => !isMobile && (setCursorState(state)), [setCursorState, isMobile])
  const [curve] = useState(() => new THREE.CatmullRomCurve3([new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()]))
  const [dragged, drag] = useState<false | THREE.Vector3>(false)
  const [hovered, hover] = useState(false)
  const light = useRef<THREE.PointLight>(null!)
  const signRef = useRef<ThreeElements['mesh']>(null!)
  const nameRef = useRef<ThreeElements['mesh']>(null!)
  const centerRef = useRef<ThreeElements['group']>(null!)
  const rootR = useRef<RootRef>(null!)
  const mp = useRef<ThreeElements['material']>(null!)
  const boxSizer = useRef(new THREE.Box3()), boxSizeGetter = useRef(new THREE.Vector3())
  const { control } = useFormContext()
  const [name1, name2] = useWatch({
    name: ['firstName', 'lastName'], control, defaultValue: ['R', 'P'],
  })
  const firstName = useRef(name1 as string), lastName = useRef(name2 as string)
  const lastTime = useRef<number>(0)
  const [displayText, setDisplayText] = useState(`${firstName.current} ${lastName.current}`)
  const [firstText, setFirstText] = useState(`${firstName.current}`), [secondText, setSecondText] = useState(`${lastName.current}`)
  const [opacity, setOpacity] = useState(1)
  const to = useRef<ReturnType<typeof setTimeout>>(null!)
  const duration = 350 // how long the to will wait before firing callback, in ms
  useEffect(() => {
    if (nameRef.current && card.current) {
      const size = boxSizer.current.setFromObject(nameRef.current as Object3D).getSize(boxSizeGetter.current)
      console.log('size:', size)
      setMaxW(size.x)
      setMaxH(size.y)
      setMinW(size.x * 0.5)
      setMinH(size.y * 0.5)

    }
  }, [])

  const handleOnCentered = useCallback(() => {
    needsMeasurement.current = true
    setFirstText(name1)
    setSecondText(name2)
    needsMeasurement.current = false
  }, [])

  const displayTextUpdate = useCallback<GSAPTickerCallback>(function displayTextUpdate(time, deltaTime, frame, elapsed) {
    const isMeasuring = needsMeasurement.current
    lastTime.current += isMeasuring ? 0 : gsap.ticker.deltaRatio(60) * 16.7
    let progress = Math.min((lastTime.current / 300), 1)
    let opac = progress > 0.5 ? 2 * progress - 1 : 1 - progress * 2
    console.log(`textUpdate, opacity: ${opac}, progress: ${progress}, lastTime: ${lastTime.current}, deltaTime: ${deltaTime}, frame: ${frame}, elapsed: ${elapsed}`)
    setOpacity(opac)
    if (progress >= 1) {
      return (lastTime.current = 0, gsap.ticker.remove(displayTextUpdate))
    }
    if (opac === 0) {
      // once past halfway, set text to new
      handleOnCentered()
    }
  }, [])
  useEffect(() => {
    console.log('name being changed')
    firstName.current = name1
    lastName.current = name2
    to.current && clearTimeout(to.current)
    to.current = setTimeout(() => {
      console.log(`countdown finished, ${to.current}`)
      gsap.ticker.add(displayTextUpdate)
    }, duration)
    return () => {
      to.current && clearTimeout(to.current)
      gsap.ticker.remove(displayTextUpdate)
    }
  }, [name1, name2])

  const textPhysicalMeshProps = useMemo(() => ({
    transparent: true,
    anisotropy: 1,
    metalness: 1,
    opacity: opacity,
    color: 'rgb(144,144,144)',
    sheen: 1,
    anisotropyRotation: 0.66,
    sheenRoughness: 1,
    roughness: 0.4,
  }), [opacity])
  const topLayerTextProps = useMemo(() => ({
    transparent: true,
    opacity: opacity,
    sheenRoughness: 1,
    sheen: 1,
    color: 'rgb(11,11,11)',
    roughness: 0.3,
    metalness: 1,
  }), [opacity])
  const text3dProps = useMemo(() => ({
    bevelEnabled: true,
    bevelSegments: 15,
    depth: 26,
    bevelThickness: 0.1,
    bevelSize: 0.04,
    bevelOffset: 0.001,
    font: FONTFACES.COPPERPLATE.HEAVY,
    size: 0.8,
    height: 1,
    letterSpacing: 0.15,
  }), [])

  useRopeJoint(fixed, j1, [[0, 0, 0], [0, 0, 0], 1]) // prettier-ignore
  useRopeJoint(j1, j2, [[0, 0, 0], [0, 0, 0], 1]) // prettier-ignore
  useRopeJoint(j2, j3, [[0, 0, 0], [0, 0, 0], 1]) // prettier-ignore
  useSphericalJoint(j3, card, [[0, 0, 0], [0, 1.56, 0]]) // prettier-ignore
  const [spun, setSpun] = useState(true)
  useEffect(() => {
    setTimeout(() => setSpun(false), 5500)
    setMove(true)
  }, [])

  const translateVector = useRef(new THREE.Vector3()), eulers = useRef(new THREE.Euler()),
    quat = useRef(new THREE.Quaternion())
  useFrame((state, delta) => {
    easing.damp3(light.current.position, [state.pointer.x * 12, 0.1, 8 + state.pointer.y * 4], 0.2, delta)
    if (dragged) {
      vec.set(state.pointer.x, state.pointer.y, 0.5).unproject(state.camera)
      dir.copy(vec).sub(state.camera.position).normalize()
      vec.add(dir.multiplyScalar(state.camera.position.length()));
      [card, j1, j2, j3, fixed].forEach((ref) => ref.current?.wakeUp())
      card.current?.setNextKinematicTranslation({
        x: vec.x - dragged.x, y: vec.y - dragged.y, z: vec.z - dragged.z,
      })
    }
    if (fixed.current) {
      // Fix most of the jitter when over pulling the card
      ;[j1, j2].forEach((ref) => {
        if (!ref.current.lerped) ref.current.lerped = new THREE.Vector3().copy(ref.current.translation())
        const clampedDistance = Math.max(0.1, Math.min(1, ref.current.lerped.distanceTo(ref.current.translation())))
        ref.current.lerped.lerp(ref.current.translation(), delta * (minSpeed + clampedDistance * (maxSpeed - minSpeed)))
      })

      // Calculate catmul curve
      curve.points[0].copy(j3.current.translation())
      curve.points[1].copy(j2.current.lerped)
      curve.points[2].copy(j1.current.lerped)
      curve.points[3].copy(fixed.current.translation())
      if (band.current.geometry && 'setPoints' in band.current.geometry) {
        band.current.geometry.setPoints(curve.getPoints(633))
      }

      // Tilt it back towards the screen
      ang.copy(card.current.angvel())
      rot.copy(card.current.rotation())
      let rr = card.current.rotation()
      const euler = new THREE.Euler().setFromQuaternion(new THREE.Quaternion(rr.x, rr.y, rr.z, rr.w), 'YXZ')
      let currentYRotation = euler.y

      // Wrap current rotation to be between -Math.PI and Math.PI
      currentYRotation = THREE.MathUtils.euclideanModulo(currentYRotation + Math.PI, Math.PI * 2) - Math.PI

      // Determine the target rotation based on the "spun" state
      const targetYRotation = (spun ? Math.PI : 0) + ((dragged || !hovered) ? 0 : -state.pointer.x * (Math.PI / 3))// 0 deg if not spun, 180 deg (Math.PI) if spun

      // Calculate the difference to the target rotation
      let angleDifference = targetYRotation - currentYRotation

      // Wrap the angleDifference to be within -Math.PI to Math.PI for the shortest path
      angleDifference = THREE.MathUtils.euclideanModulo(angleDifference + Math.PI, Math.PI * 2) - Math.PI

      // Clamp angular velocity for stability
      const maxAngularVelocity = 2 // Adjust for the desired max speed
      const velocityY = Math.max(-maxAngularVelocity, Math.min(maxAngularVelocity, angleDifference * 5)) // "5" is the rotation speed factor

      card.current.setAngvel({ x: ang.x, y: velocityY, z: ang.z }, true)
      // : card.current.setAngvel({ x: ang.x, y: ang.y - rot.y * 0.25, z: ang.z }, false)
    }
  })
  const countt = useRef<ReturnType<typeof requestAnimationFrame>>(null!)
  const [num, setNum] = useState(0)
  const counter = useCallback(function counter() {
    setNum((s) => s + 1)
    countt.current = requestAnimationFrame(counter)
  }, [])

  useEffect(() => {
    if (!dragged) {
      countt.current && cancelAnimationFrame(countt.current)
      if (num > 20 && num < 100) {
        setSpun((spun) => !spun)
      }
      setNum(0)
    } else {
      countt.current = requestAnimationFrame(counter)
    }
  }, [dragged])

  curve.curveType = 'catmullrom'
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping
  const centerProps = useMemo(() => ({
    scale: scaledVec, height: maxH, width: maxH,
  }), [cardSize, scaledVec])
  return (<>
    <group position={[0, 4, 0]} onPointerOver={() => hMI('FOCUS')} onPointerOut={() => hMI(null)}>
      <RigidBody ref={fixed} {...segmentProps} type="fixed" />
      <RigidBody position={[0.5, 0, 0]} ref={j1} {...segmentProps}>
        <BallCollider args={[0.1]} />
      </RigidBody>
      <RigidBody position={[1, 0, 0]} ref={j2} {...segmentProps}>
        <BallCollider args={[0.1]} />
      </RigidBody>
      <RigidBody position={[1.5, 0, 0]} ref={j3} {...segmentProps}>
        <BallCollider args={[0.1]} />
      </RigidBody>
      <RigidBody position={[2, 0, 0]} ref={card}
                 {...segmentProps} type={dragged ? 'kinematicPosition' : 'dynamic'}>
        <CuboidCollider args={[0.8, 1.125, 0.01]} />
        <group scale={2.25} position={[0, -1.2, -0.05]} onPointerOver={() => hover(true)}
               onPointerOut={() => hover(false)} onPointerUp={(e: Omit<ThreeEvent<PointerEvent>, 'target'> & {
          target: Element
        }) => (e.target.releasePointerCapture(e.pointerId), drag(false), countt.current && cancelAnimationFrame(countt.current))}
               onPointerDown={(e: Omit<ThreeEvent<PointerEvent>, 'target'> & {
                 target: Element
               }) => (e.target?.setPointerCapture(e.pointerId), drag(dire.copy(e.point).sub(vec.copy(card.current.translation()))))}>
          <mesh {...model.nodes['card']} geometry={model.nodes['card']['geometry']}>
            <meshStandardMaterial
              {...model.nodes['card']['material']} />
            <Center {...centerProps} ref={centerRef}>
              <group rotation={[0, 0, 0]} position={[0, 0, 0]} scale={[1, 1, 0.1]} ref={signRef}>
                <Text3D {...text3dProps} >
                  <meshPhysicalMaterial {...model.materials.logo_metal} {...textPhysicalMeshProps} />
                  {firstText}
                </Text3D>
                <Text3D {...text3dProps} height={1.15} bevelEnabled={false}>
                  <meshPhysicalMaterial {...topLayerTextProps} />
                  {firstText}
                </Text3D>
              </group>
            </Center>
          </mesh>
          <mesh {...model.nodes['back_engraving']}>
            <meshStandardMaterial
              {...model.nodes['back_engraving']['material']} />
          </mesh>
          <mesh geometry={model.nodes.frame['geometry']}>
            <meshPhysicalMaterial {...model.materials['frame_metal']} metalness={1.0} anisotropyRotation={0.8} sheen={1}
                                  anisotropy={14} normalScale={[.01, -.01]} color={'rgb(161,161,161)'}
                                  displacementMap={displacement} normalMap={model.materials['frame_metal']['normalMap']}
                                  displacementScale={0.01} />
          </mesh>
          <mesh {...model.nodes['logo']}>
            <meshPhysicalMaterial
              {...model.nodes['logo']['material']} {...{
              transparent: true,
              anisotropy: 1,
              metalness: 1,

              color: 'rgb(24,24,24)',
              sheen: 1,
              anisotropyRotation: 0.66,
              sheenColor: 'rgb(29,24,24)',
              sheenRoughness: 1,
              roughness: 0.4,
            }} />
          </mesh>
          <mesh {...model.nodes['front_btm_engraving']}>
            <meshPhysicalMaterial
              {...model.materials['front_btm']} {...{
              transparent: true,
              anisotropy: 1,
              metalness: 1,
              color: 'rgb(24,24,24)',
              sheen: 1,
              anisotropyRotation: 0.66,
              sheenColor: 'rgb(29,24,24)',
              sheenRoughness: 0.4,
              roughness: 0.4,
            }} />
          </mesh>
          <mesh geometry={model.nodes['name']['geometry']} ref={nameRef}>
            <meshStandardMaterial {...model.nodes['card']['material']} color={'rgb(24,24,24)'} roughness={0.7}
                                  metalness={1} />
          </mesh>
          <Text3D {...text3dProps} scale={scaledVec}>
            <meshPhysicalMaterial {...model.materials.logo_metal} {...textPhysicalMeshProps} />
            {secondText}
          </Text3D>
          <Text3D {...text3dProps} height={1.15} scale={scaledVec} bevelEnabled={false}>
            <meshPhysicalMaterial {...topLayerTextProps} />
            {secondText}
          </Text3D>
          <mesh geometry={model.nodes.pic['geometry']}>
            <meshStandardMaterial {...model.nodes['card']['material']} color={'rgb(24,24,24)'} roughness={0.7}
                                  metalness={1} />
          </mesh>
          <mesh geometry={model.nodes.clip['geometry']}>
            <meshPhysicalMaterial metalness={1} color={'rgb(14,14,14)'} roughness={0.4} />
          </mesh>
          <mesh geometry={model.nodes.clamp['geometry']}>
            <meshPhysicalMaterial metalness={1} color={'rgb(14,14,14)'} roughness={0.4} />
          </mesh>
        </group>
      </RigidBody>
    </group>
    <mesh ref={band}>
      <meshLineGeometry />
      <meshLineMaterial color={Color['white']} depthTest={false} useMap={1} map={texture} repeat={new Vector2(-3, 1)}
                        resolution={new Vector2(width, height)} lineWidth={1} />
    </mesh>
    <spotLight angle={0.5} penumbra={0.5} ref={light} castShadow={true} intensity={10} shadow-mapSize={1024}
               shadow-bias={-0.001}>
      <orthographicCamera attach="shadow-camera" args={[-10, 10, -10, 10, 0.1, 50]} />
    </spotLight>
  </>)
}
