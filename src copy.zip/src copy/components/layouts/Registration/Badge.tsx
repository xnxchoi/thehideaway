'use client'
import { useEffect, useMemo, useRef, useState } from 'react'
import * as THREE from 'three'
import { Color, Material, Mesh, Texture, Vector2, Vector3 } from 'three'
import { Center, OnCenterCallbackProps, Text3D, useGLTF, useTexture } from '@react-three/drei'
import { extend, ThreeElements, ThreeEvent, useFrame, useThree } from '@react-three/fiber'
import {
  BallCollider, CuboidCollider, RapierRigidBody, RigidBody, RigidBodyTypeString, useRopeJoint, useSphericalJoint,
} from '@react-three/rapier'
import { MeshLineGeometry, MeshLineMaterial, raycast } from 'meshline'
import { ScreenSizerProps } from '@react-three/drei/core/ScreenSizer'
import { FONTFACES } from '@/constants/api'
import { getDeviceInfo, useCursorStore } from '@/providers/RP_Pro'
import { easing } from 'maath'
import { useKinetics } from '@/components/layouts/Registration/KineticProvider'
import { useFormContext, useWatch } from 'react-hook-form'
import gsap from 'gsap/all'
import { upperCase } from 'lodash'
import { clamp } from '@/utilities/mathUtilities'
import { lerp } from 'maath/misc'


extend({ MeshLineGeometry, MeshLineMaterial })

declare module '@react-three/fiber' {
  interface ThreeElements {
    meshLine: Mesh & MeshLineGeometry & MeshLineMaterial & { raycast: ReturnType<typeof raycast> }
    meshLineMaterial: Partial<MeshLineMaterial>
    meshLineGeometry: Partial<MeshLineGeometry>
    screenSizer: Partial<ScreenSizerProps> & Partial<ThreeElements['object3D']>
  }
}
useGLTF.preload('/assets/plate/badge/BADGE.glb')
useGLTF.preload('/assets/plate/badge/BADGE-transformed.glb')
useGLTF.preload('/assets/plate/badge/tagme-transformed.glb')
useTexture.preload('/assets/plate/badge/back_engraving_colors.png')
useTexture.preload('/assets/plate/badge/back_engraving_normal.png')
useTexture.preload('/assets/plate/badge/back_engraving_roughness.png')
useTexture.preload('/assets/plate/badge/btm_engraving_colors.png')
useTexture.preload('/assets/plate/badge/btm_engraving_normal.png')
useTexture.preload('/assets/plate/badge/btm_engraving_roughness.png')
useTexture.preload('/assets/plate/badge/frame_colors.png')
useTexture.preload('/assets/plate/badge/frame_roughness.png')
useTexture.preload('/assets/plate/badge/clip_colors.png')
useTexture.preload('/assets/plate/badge/clip_normal.png')
useTexture.preload('/assets/plate/badge/clip_roughness.png')
useTexture.preload('/assets/plate/badge/clamp_colors.png')
useTexture.preload('/assets/plate/badge/clamp_normal.png')
useTexture.preload('/assets/plate/badge/clamp_roughness.png')

function materialConfigurer(props: {
  normal?: Texture
  roughness: Texture
  map: Texture
  displacement?: Texture
}) {
  const { normal, roughness, map, displacement } = props
  const { size } = useThree()
  roughness.wrapS = roughness.wrapT = THREE.RepeatWrapping
  let topass: {
    normalMap?: Texture
    normalScale?: Vector2
    bumpMap?: Texture
    bumpScale?: number
    roughnessMap: Texture
    map: Texture
    roughness: number
    metalness: number
  } = {
    roughnessMap: roughness, map: map, roughness: 1, metalness: 1,
  }
  if (normal) {
    topass = {
      ...topass, normalMap: normal, normalScale: new THREE.Vector2(size.width, size.height),
    }
  } else if (displacement) {
    topass = {
      ...topass, bumpScale: 1, bumpMap: displacement,
    }
  }
  return topass
}

const pathway = '/assets/plate/apr25_textures/badge'

export function Badge({ maxSpeed = 50, minSpeed = 10 }) {
  const band = useRef<ThreeElements['mesh'] & { geometry: MeshLineGeometry; material: MeshLineMaterial }>(null!),
    fixed = useRef<RapierRigidBody & { lerped: Vector3 }>(null!),
    j1 = useRef<RapierRigidBody & { lerped: Vector3 }>(null!),
    j2 = useRef<RapierRigidBody & { lerped: Vector3 }>(null!),
    j3 = useRef<RapierRigidBody & { lerped: Vector3 }>(null!),
    card = useRef<RapierRigidBody & ThreeElements['mesh']>(null!)
  const { setMove } = useKinetics()
  const backEngraving = materialConfigurer({
    normal: useTexture('/assets/plate/badge/back_engraving_normal.png'),
    roughness: useTexture('/assets/plate/badge/back_engraving_roughness.png'),
    map: useTexture('/assets/plate/badge/back_engraving_colors.png'),
  })
  const frameMaterial = materialConfigurer({
    normal: useTexture('/assets/plate/badge/frame_normal.png'),
    roughness: useTexture('/assets/plate/badge/frame_roughness.png'),
    map: useTexture('/assets/plate/badge/frame_colors.png'),
  })
  frameMaterial.roughnessMap.wrapS = frameMaterial.roughnessMap.wrapT = THREE.RepeatWrapping
  frameMaterial.roughnessMap.mapping = THREE.UVMapping
  const logoMaterial = materialConfigurer({
    normal: useTexture('/assets/plate/badge/logo_normal.png'),
    roughness: useTexture('/assets/plate/badge/logo_roughness.png'),
    map: useTexture('/assets/plate/badge/logo_colors.png'),
  }), btmMaterial = materialConfigurer({
    normal: useTexture('/assets/plate/badge/btm_engraving_normal.png'),
    roughness: useTexture('/assets/plate/badge/btm_engraving_roughness.png'),
    map: useTexture('/assets/plate/badge/btm_engraving_colors.png'),
  })
  const clipMaterial = materialConfigurer({
    normal: useTexture('/assets/plate/badge/clip_normal.png'),
    roughness: useTexture('/assets/plate/badge/clip_roughness.png'),
    map: useTexture('/assets/plate/badge/clip_colors.png'),
  })
  const clampMaterial = materialConfigurer({
    normal: useTexture('/assets/plate/badge/clamp_normal.png'),
    roughness: useTexture('/assets/plate/badge/clamp_roughness.png'),
    map: useTexture('/assets/plate/badge/clamp_colors.png'),
  })

  const vec = new THREE.Vector3(), ang = new THREE.Vector3(), rot = new THREE.Vector3(), dir = new THREE.Vector3()
  const segmentProps: {
    type: RigidBodyTypeString
    canSleep: boolean
    colliders?: any
    angularDamping: number
    linearDamping: number
  } = {
    type: 'dynamic', canSleep: true, colliders: false, angularDamping: 2, linearDamping: 2,
  }
  const mx = useGLTF('/assets/plate/badge/BADGE-transformed.glb')
  const mn = useGLTF('/assets/plate/badge/tagme-transformed.glb')
  const { nodes } = useGLTF('/assets/plate/badge/tagme.glb')
  const model = useGLTF(`${pathway}/BADGEd-transformed.glb`)
  const texture = useTexture('/assets/model/ha.png')
  const [maxW, setMaxW] = useState(1)
  const [maxH, setMaxH] = useState(1)
  const [curW, setCurW] = useState(1)
  const [curH, setCurH] = useState(1)
  const [scale, setScale] = useState(1)
  const [cardSize, setCardSize] = useState({ width: 3.1, height: 2 })
  const { width, height } = useThree((state) => state.size)
  const { isMobile } = getDeviceInfo()
  const [curve] = useState(() => new THREE.CatmullRomCurve3([new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3(), new THREE.Vector3()]))
  const [dragged, drag] = useState<false | THREE.Vector3>(false)
  const [hovered, hover] = useState(false)
  const light = useRef<THREE.PointLight>(null!)
  const signRef = useRef<ThreeElements['mesh']>(null!)
  const centerRef = useRef<ThreeElements['group']>(null!)
  const nameRef = useRef<ThreeElements['mesh']>(null!)
  const mp = useRef<ThreeElements['material']>(null!)
  const boxSizer = useRef(new THREE.Box3()), boxSizeGetter = useRef(new THREE.Vector3())
  const { control } = useFormContext()
  const [name1, name2] = useWatch({
    name: ['firstName', 'lastName'], control, defaultValue: ['R', 'P'],
  })
  const [first, setFirst] = useState('R'), [last, setLast] = useState('P')
  const lastTime = useRef<number>(0)
  const [smoothText, setSmoothText] = useState(`${first} ${last}`)
  const [opacity, setOpacity] = useState(1)
  const to = useRef<ReturnType<typeof setTimeout>>(null!)
  const duration = 200 // how long the to will wait before firing callback, in ms
  useEffect(() => {
    if (model) {
      console.log(model)
      if (model.nodes['card']) {
        const size = boxSizer.current.setFromObject(model.nodes['card']).getSize(boxSizeGetter.current)
        setCardSize({
          width: size.x, height: size.y,
        })
        console.log('card', size.x, size.y)
      }
      if (model.nodes['name']) {
        const size = boxSizer.current.setFromObject(model.nodes['name']).getSize(boxSizeGetter.current)
        const currentW = size.x, currentH = size.y
        console.log('name', currentW, currentH)
        setMaxH(currentH), setMaxW(currentW)
      }
    }

  }, [])
  const [needsMeasurement, setNeedsMeasurement] = useState(true)
  useEffect(() => {
    lastTime.current = 0
  }, [needsMeasurement])
  const secondTO = useRef<ReturnType<typeof setTimeout>>(null!)
  useEffect(() => {
    to.current && clearTimeout(to.current)
    to.current = setTimeout(() => {
      setNeedsMeasurement(true)
      secondTO.current && clearTimeout(secondTO.current)
      secondTO.current = setTimeout(() => {
        setSmoothText(upperCase(name1 + ' ' + name2))
      }, 150)
    }, duration)

  }, [name1, name2])
  useEffect(() => {
    setFirst(name1)

  }, [name1])
  useEffect(() => {
    setLast(name2)
  }, [name2])
  const textPhysicalMeshProps = useMemo(() => ({
    transparent: true,
    anisotropy: 1,
    metalness: 1,
    opacity: opacity,
    color: 'rgb(144,144,144)',
    sheen: 1,
    anisotropyRotation: 0.66,
    sheenRoughness: 1,
    roughness: 0.4,
  }), [opacity])
  const topLayerTextProps = useMemo(() => ({
    transparent: true,
    opacity: opacity,
    sheenRoughness: 1,
    sheen: 1,
    color: 'rgb(11,11,11)',
    roughness: 0.3,
    metalness: 1,
  }), [opacity])
  const text3dProps = useMemo(() => ({
    bevelEnabled: true,
    bevelSegments: 15,
    depth: 26,
    bevelThickness: 0.1,
    bevelSize: 0.04,
    bevelOffset: 0.001,
    font: FONTFACES.COPPERPLATE.HEAVY,
    size: 0.8,
    height: 1,
    letterSpacing: 0.15,
  }), [scale])
  useRopeJoint(fixed, j1, [[0, 0, 0], [0, 0, 0], 1]) // prettier-ignore
  useRopeJoint(j1, j2, [[0, 0, 0], [0, 0, 0], 1]) // prettier-ignore
  useRopeJoint(j2, j3, [[0, 0, 0], [0, 0, 0], 1]) // prettier-ignore
  useSphericalJoint(j3, card, [[0, 0, 0], [0, 1.56, 0]]) // prettier-ignore
  const [spun, setSpun] = useState(true)
  useEffect(() => {
    setTimeout(() => setSpun(false), 5500)
    setMove(true)
  }, [])
  useEffect(() => {
    if (hovered) {
      document.body.style.cursor = dragged ? 'grabbing' : 'grab'
      return () => void (document.body.style.cursor = 'auto')
    }
  }, [hovered, dragged])
  const eulerV = new THREE.Euler()
  const timePast = useRef(0)
  useFrame((state, delta) => {
    easing.damp3(light.current.position, [state.pointer.x * 12, 0.1, 8 + state.pointer.y * 4], 0.2, delta)
    lastTime.current += delta * 16.7
    let progress = clamp(0, lastTime.current / 150, 1)
    setOpacity(t => lerp(t, needsMeasurement ? 1 - progress : progress, 0.2))
    if (dragged) {
      timePast.current += delta * 100
      console.log(timePast.current)
      vec.set(state.pointer.x, state.pointer.y, 0.5).unproject(state.camera)
      dir.copy(vec).sub(state.camera.position).normalize()
      vec.add(dir.multiplyScalar(state.camera.position.length()));
      [card, j1, j2, j3, fixed].forEach((ref) => ref.current?.wakeUp())
      card.current?.setNextKinematicTranslation({
        x: vec.x - dragged.x, y: vec.y - dragged.y, z: vec.z - dragged.z,
      })

    }
    if (fixed.current) {
      // Fix most of the jitter when over pulling the card
      ;[j1, j2].forEach((ref) => {
        if (!ref.current.lerped) ref.current.lerped = new THREE.Vector3().copy(ref.current.translation())
        const clampedDistance = Math.max(0.1, Math.min(1, ref.current.lerped.distanceTo(ref.current.translation())))
        ref.current.lerped.lerp(ref.current.translation(), delta * (minSpeed + clampedDistance * (maxSpeed - minSpeed)))
      })

      // Calculate catmul curve
      curve.points[0].copy(j3.current.translation())
      curve.points[1].copy(j2.current.lerped)
      curve.points[2].copy(j1.current.lerped)
      curve.points[3].copy(fixed.current.translation())
      if (band.current.geometry && 'setPoints' in band.current.geometry) {
        band.current.geometry.setPoints(curve.getPoints(633))
      }

      // Tilt it back towards the screen
      ang.copy(card.current.angvel())
      rot.copy(card.current.rotation())
      let rr = card.current.rotation()
      let currentYRotation = eulerV.setFromQuaternion(new THREE.Quaternion(rr.x, rr.y, rr.z, rr.w), 'YXZ').y

      // Wrap current rotation to be between -Math.PI and Math.PI
      currentYRotation = THREE.MathUtils.euclideanModulo(currentYRotation + Math.PI, Math.PI * 2) - Math.PI

      // Determine the target rotation based on the "spun" state
      const targetYRotation = (spun ? Math.PI : 0) + ((dragged || !hovered) ? 0 : -state.pointer.x * (Math.PI / 3))// 0 deg if not spun, 180 deg (Math.PI) if spun

      // Calculate the difference to the target rotation
      let angleDifference = targetYRotation - currentYRotation

      // Wrap the angleDifference to be within -Math.PI to Math.PI for the shortest path
      angleDifference = THREE.MathUtils.euclideanModulo(angleDifference + Math.PI, Math.PI * 2) - Math.PI

      // Clamp angular velocity for stability
      const maxAngularVelocity = 2 // Adjust for the desired max speed
      const velocityY = Math.max(-maxAngularVelocity, Math.min(maxAngularVelocity, angleDifference * 5)) // "5" is the rotation speed factor

      card.current.setAngvel({ x: ang.x, y: velocityY, z: ang.z }, true)
      // : card.current.setAngvel({ x: ang.x, y: ang.y - rot.y * 0.25, z: ang.z }, false)
    }
  })


  useEffect(() => {
    if (!dragged) {
      if (timePast.current > 20 && timePast.current < 100) {
        setSpun((spun) => !spun)
      }
      timePast.current = 0
    }
  }, [dragged])

  curve.curveType = 'catmullrom'
  texture.wrapS = texture.wrapT = THREE.RepeatWrapping
  const centerProps = useMemo(() => ({
    height: maxH, width: maxH,
  }), [])
  const ccc = useRef<ReturnType<typeof setTimeout>>(null!)
  return (<>
    <group position={[0, 4, 0]} onPointerOver={() => hMI('FOCUS')} onPointerOut={() => hMI(null)}>
      <RigidBody ref={fixed} {...segmentProps} type="fixed" />
      <RigidBody position={[0.5, 0, 0]} ref={j1} {...segmentProps}>
        <BallCollider args={[0.1]} />
      </RigidBody>
      <RigidBody position={[1, 0, 0]} ref={j2} {...segmentProps}>
        <BallCollider args={[0.1]} />
      </RigidBody>
      <RigidBody position={[1.5, 0, 0]} ref={j3} {...segmentProps}>
        <BallCollider args={[0.1]} />
      </RigidBody>
      <RigidBody position={[2, 0, 0]} ref={card}
                 {...segmentProps} type={dragged ? 'kinematicPosition' : 'dynamic'}>
        <CuboidCollider args={[0.8, 1.125, 0.01]} />
        <group scale={2.25} position={[0, -1.2, -0.05]} onPointerOver={() => hover(true)}
               onPointerOut={() => hover(false)} onPointerUp={(e: Omit<ThreeEvent<PointerEvent>, 'target'> & {
          target: Element
        }) => (e.target.releasePointerCapture(e.pointerId), drag(false))}
               onPointerDown={(e: Omit<ThreeEvent<PointerEvent>, 'target'> & {
                 target: Element
               }) => (e.target?.setPointerCapture(e.pointerId), drag(new THREE.Vector3().copy(e.point).sub(vec.copy(card.current.translation()))))}>
          <mesh geometry={model.nodes['card']['geometry']} material={model.nodes.card['material']}></mesh>
          <mesh geometry={model.nodes['front_btm_engraving']['geometry']}>
            <meshPhysicalMaterial
              {...model.materials['front_btm']} {...{
              transparent: true,
              anisotropy: 1,
              metalness: 1,
              color: 'rgb(24,24,24)',
              sheen: 1,
              anisotropyRotation: 0.66,
              sheenColor: 'rgb(29,24,24)',
              sheenRoughness: 0.4,
              roughness: 0.4,
            }} />
          </mesh>
          <mesh geometry={model.nodes.frame['geometry']}>
            <meshPhysicalMaterial {...model.materials['frame_metal']} metalness={1.0} anisotropyRotation={0.8} sheen={1}
                                  anisotropy={14} normalScale={[.01, -.01]} color={'rgb(161,161,161)'}
                                  normalMap={model.materials['frame_metal']['normalMap']} />
          </mesh>
          <mesh {...model.nodes['logo']}>
            <meshPhysicalMaterial
              {...model.nodes['logo']['material']} {...{
              transparent: true,
              anisotropy: 1,
              metalness: 1,
              opacity: 1,
              color: 'rgb(24,24,24)',
              sheen: 1,
              anisotropyRotation: 0.66,
              sheenColor: 'rgb(29,24,24)',
              sheenRoughness: 1,
              roughness: 0.4,
            }} />
          </mesh>
          <mesh geometry={model.nodes.clip['geometry']}>
            <meshPhysicalMaterial metalness={1} color={'rgb(14,14,14)'} roughness={0.4} />
          </mesh>
          <mesh geometry={model.nodes.clamp['geometry']}>
            <meshPhysicalMaterial metalness={1} color={'rgb(14,14,14)'} roughness={0.4} />
          </mesh>
          <mesh geometry={model.nodes['back_engraving']['geometry']}>
            <meshStandardMaterial
              {...model.nodes['back_engraving']['material']} />
          </mesh>
          <mesh geometry={model.nodes['details']['geometry']} material={model['materials']['base']} />
          <mesh geometry={model.nodes['name']['geometry']} material={model['materials']['base']} ref={nameRef}>
            <Center scale={[1, 1, 0.1]} {...{ position: [0, 0.2, 0.01] }} ref={centerRef}
                    onCentered={(props: OnCenterCallbackProps) => {
                      const { width, height, center, boundingBox, container, parent, ...rest } = props
                      const scaleW = maxW / width, scaleH = maxH / height
                      let scaleto = Math.min(scaleW, scaleH)
                      container.scale.setX(scaleto)
                      container.scale.setY(scaleto)
                      container.scale.setZ(0.01)
                      secondTO.current = setTimeout(() => {
                        setNeedsMeasurement(false)
                      }, 150)
                    }}>
              <Text3D {...text3dProps}>
                <meshPhysicalMaterial {...nodes['logo']['material']} {...textPhysicalMeshProps} opacity={opacity} />
                {smoothText}
              </Text3D>
              <Text3D {...text3dProps} height={1.15} bevelEnabled={false}>
                <meshPhysicalMaterial {...topLayerTextProps} opacity={opacity} />
                {smoothText}
              </Text3D>
            </Center>
          </mesh>
          <mesh geometry={model.nodes['pic']['geometry']} material={model['materials']['base']} />
        </group>
      </RigidBody>
    </group>
    <mesh ref={band}>
      <meshLineGeometry />
      <meshLineMaterial color={Color['white']} depthTest={false} useMap={1} map={texture} repeat={new Vector2(-3, 1)}
                        resolution={new Vector2(width, height)} lineWidth={1} />
    </mesh>
    <spotLight angle={0.5} penumbra={0.5} ref={light} castShadow={true} intensity={10} shadow-mapSize={1024}
               shadow-bias={-0.001}>
      <orthographicCamera attach="shadow-camera" args={[-10, 10, -10, 10, 0.1, 50]} />
    </spotLight>
  </>)
}

function NameTexture({
  material,
}: {
  material: Material
}) {
  const { watch } = useFormContext()
  const [name1, name2] = watch(['firstName', 'lastName'])
  const [first, setFirst] = useState('R'), [last, setLast] = useState('P')
  const lastTime = useRef<number>(0)
  const [smoothText, setSmoothText] = useState(`${first} ${last}`)
  const [opacity, setOpacity] = useState(1)
  const to = useRef<ReturnType<typeof setTimeout>>(null!)
  const duration = 350 // how long the to will wait before firing callback, in ms
  const tickF = useMemo<GSAPTickerCallback>(() => (function tickF(time, deltaTime, frame, elapsed) {
    lastTime.current += gsap.ticker.deltaRatio(60) * 16.7
    let rat = lastTime.current / 300, opGoal = rat < 1 ? 1 - rat : rat - 1
    setOpacity(opGoal)
    if (rat >= 2) {
      lastTime.current = 0
      gsap.ticker.remove(tickF)
      return
    }
    if (rat >= 1) {
      setSmoothText(upperCase(first + ' ' + last))
    }
  }), [first, last, lastTime, setSmoothText, setOpacity])
  useEffect(() => {
    to.current && clearTimeout(to.current)
    to.current = setTimeout(() => {
      gsap.ticker.add(tickF)
    }, duration)
    return () => {
      to.current && clearTimeout(to.current)
      gsap.ticker.remove(tickF)
    }
  }, [name1, name2])
  useEffect(() => {
    setFirst(name1)
    setLast(name2)
  }, [name1, name2])

  const textPhysicalMeshProps = useMemo(() => ({
    transparent: true,
    anisotropy: 1,
    metalness: 1,
    opacity: opacity,
    color: 'rgb(144,144,144)',
    sheen: 1,
    anisotropyRotation: 0.66,
    sheenRoughness: 1,
    roughness: 0.4,
  }), [opacity])
  const topLayerTextProps = useMemo(() => ({
    transparent: true,
    opacity: opacity,
    sheenRoughness: 1,
    sheen: 1,
    color: 'rgb(11,11,11)',
    roughness: 0.3,
    metalness: 1,
  }), [opacity])
  const text3dProps = useMemo(() => ({
    bevelEnabled: true,
    bevelSegments: 15,
    depth: 26,
    bevelThickness: 0.1,
    bevelSize: 0.04,
    bevelOffset: 0.001,
    font: FONTFACES.COPPERPLATE.HEAVY,
    size: 1,
    height: 1,
    letterSpacing: 0.15,
  }), [])
  const bvs = { bevelSegments: 1, bevelThickness: 0.1, bevelSize: 0.01, bevelEnabled: true }
  return (<Center scale={[0.1, 0.1, 0.1]} position={[-0.3, 0.4, 0.01]} right>
    <group rotation={[0, 0, 0]} position={[0, 0, 0]} scale={[0.8, 0.8, 0.1]}>
      <Text3D {...text3dProps}>
        <meshPhysicalMaterial {...material} {...textPhysicalMeshProps} />
        {smoothText}
      </Text3D>
      <Text3D {...text3dProps} height={1.15} bevelEnabled={false}>
        <meshPhysicalMaterial {...topLayerTextProps} />
        {smoothText}
      </Text3D>
    </group>
  </Center>)
}

const random = () => {
  // parent = parent.__r3f.parent
}
