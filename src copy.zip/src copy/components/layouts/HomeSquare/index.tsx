'use client'
import { Link } from 'src/components/UX/Link'
import { FoundArticle } from '@/components/layouts/HomeArticleLayout'
import { ComponentPropsWithoutRef, useEffect } from 'react'
import { RP_BadgeTag } from '@/components/UX/RP_BadgeTag'
import { FrontImage } from '@/components/UX/Media/FrontImage'
import { blase, narcissianNectare } from '../../../../fonts'
import { cn } from '@/lib/utils'


export const HomeSquare = (props: { article: FoundArticle } & ComponentPropsWithoutRef<'div'>) => {
  const { article, ...rest } = props
  useEffect(() => {
    console.log(article)
  },[])
  return (<Link href={'/posts/' + article.slug}
                className="items-center rounded-[10px] flex flex-col p-[20px] col-span-full text-center gap-y-[10px] bg-[oklch(var(--faded-fg)/1)] text-[oklch(var(--faded-bg)/1)] lg:col-[1/-1]">
    <div className="pt-[56%] w-full rounded-[5px] relative min-w-[1px] min-h-[1px] overflow-hidden">
      {article.heroImage ? (<FrontImage resource={article.heroImage}
                                        imgClassName="rounded-[5px] absolute object-cover top-0 block w-full h-full transition-opacity duration-400" />) :
        <div
          className="rounded-[5px] absolute object-cover top-0 block w-full h-full transition-opacity duration-400" />}
    </div>
    <RP_BadgeTag className="text-[oklch(var(--bg)/1)] border-[color:oklch(var(--bg)/1)]" content={'hi'} />
    <p className="tracking-[-.01em] m-0 text-[2.8rem] lg:text-[4rem]">
    <span className={cn(narcissianNectare.className,'font-medium tracking-[-.02em]')}>
    {article.title}
    </span>
    </p>
    <p className="m-0 leading-[1.25] text-[1.6rem] max-w-[70%] lg:mt-[-5px] lg:text-[2rem]">
      {article.subtitle}
    </p>
    <div
      className="inline-block uppercase text-[1.1rem] max-w-[70%] lg:mt-[-10px] lg:text-[1.2rem]">By {article?.populatedAuthor?.[0]?.name}
    </div>
  </Link>)
}