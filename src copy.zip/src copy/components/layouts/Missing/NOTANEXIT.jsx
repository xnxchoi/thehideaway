'use client'
import { Canvas, extend, useFrame, useThree } from '@react-three/fiber'
import { useEffect, useMemo, useRef, useState } from 'react'
import gsap from 'gsap/all'
import * as THREE from 'three'
import vertexShader from '@/components/layouts/Missing/shader/vertex.glsl'
import fragmentShader from '@/components/layouts/Missing/shader/fragment.glsl'
import { OrthographicCamera, shaderMaterial } from '@react-three/drei'
import { useRPStore } from '@/providers/RP_Pro.js'
import { useWindowResize } from '../../../utilities/use_window_resize.js'

function drawSVG(ctx, canvasWidth, canvasHeight) {
  ctx.clearRect(0, 0, canvasWidth, canvasHeight)
  ctx.globalAlpha = 1
  const svgEl = document.getElementById('svgel')
  let d =
    (svgEl && svgEl.querySelector('path').getAttribute('d')) ||
    'm0 1098.61.14-258.06c42.73-65 82.1-132.06 118.11-201.13 35.99-69.07 68.06-138.46 96.2-208.22 28.12-69.76 52.89-138.84 74.27-207.26 21.38-68.39 39.4-135.12 54.07-200.14l345.56.18-.72 1343.24-207.34-.11.61-1152.22h-11.81c-21.39 85.34-46.45 166.94-75.14 244.83-28.7 77.9-60.22 151.7-94.52 221.46S228.86 816.26 190.62 877.2v16.27l620.32.33-.11 205.24zm1430.98 297.45c-64.06-.03-119.96-15.99-167.7-47.84s-87.35-77.93-118.78-138.24c-31.43-60.29-54.72-132.8-69.84-217.48s-22.65-179.84-22.59-285.54c.08-155.77 14.74-286.15 44.03-391.15 29.28-104.99 72.31-183.88 129.08-236.68 56.76-52.78 127.3-79.17 211.6-79.13 85.4.05 156.19 27.18 212.36 81.4 56.15 54.22 98.25 133.48 126.29 237.82 28.03 104.34 42.03 231.7 41.95 382.05-.06 107.04-7.97 203.57-23.75 289.58-15.78 86.04-39.7 159.18-71.76 219.43-32.06 60.28-72.27 106.32-120.61 138.12-48.35 31.8-105.1 47.69-170.28 47.66m3.48-203.2c25.85.01 49.45-8.77 70.82-26.37 21.35-17.6 39.35-46.04 53.98-85.33 14.61-39.27 26.16-90.39 34.63-153.4 8.45-62.99 12.72-139.2 12.76-228.63.06-107.02-6.36-197.11-19.24-270.27-12.89-73.16-32.23-129.06-58.06-167.69s-57.85-57.95-96.06-57.97c-32.6-.02-61.81 15.89-87.68 47.7q-38.805 47.76-59.94 156.45c-14.08 72.46-21.15 170.34-21.21 293.62-.05 89.43 3.83 165.3 11.67 227.64 7.83 62.33 19.04 112.78 33.64 151.4 14.57 38.62 32.54 67.07 53.89 85.36 21.33 18.31 44.94 27.46 70.79 27.48Zm622.05-93.16.14-258.06c42.73-65 82.1-132.06 118.11-201.13 35.99-69.07 68.06-138.46 96.2-208.22 28.12-69.76 52.89-138.84 74.27-207.26 21.38-68.39 39.4-135.12 54.07-200.14l345.56.18-.72 1343.24-207.34-.11.61-1152.22h-11.81c-21.39 85.34-46.45 166.94-75.14 244.83-28.7 77.9-60.22 151.7-94.52 221.46s-70.57 135.08-108.81 196.02v16.27l620.32.33-.11 205.24z'
  let path = new Path2D(d)
  let viewBox = svgEl.getAttribute('viewBox').split(' ')
  let m = parseFloat(viewBox[2]),
    g = parseFloat(viewBox[3]),
    _ = canvasWidth / m,
    v = canvasHeight / g,
    y = Math.min(_, v)
  let fillstyle = gsap.getProperty('html', '--red-t-1')
  ctx.setTransform(y, 0, 0, y, 0, 0),
    ctx.translate((canvasWidth - m * y) / 2, (canvasHeight - g * y) / 2),
    (ctx.fillStyle = fillstyle),
    ctx.fill(path)
}

function canvasser(canvasHeight, canvasWidth) {
  let canvass = document.createElement('canvas')
  ;(canvass.width = canvasWidth), (canvass.height = canvasHeight)
  let ctx = canvass.getContext('2d', { alpha: true })
  ctx.clearRect(0, 0, canvass.width, canvass.height)
  ctx.globalAlpha = 1
  const svgEl = document.getElementById('svgel')
  if (!svgEl) {
    console.log('no svgel')
  }
  let d =
    (svgEl && svgEl.querySelector('path').getAttribute('d')) ||
    'm0 1098.61.14-258.06c42.73-65 82.1-132.06 118.11-201.13 35.99-69.07 68.06-138.46 96.2-208.22 28.12-69.76 52.89-138.84 74.27-207.26 21.38-68.39 39.4-135.12 54.07-200.14l345.56.18-.72 1343.24-207.34-.11.61-1152.22h-11.81c-21.39 85.34-46.45 166.94-75.14 244.83-28.7 77.9-60.22 151.7-94.52 221.46S228.86 816.26 190.62 877.2v16.27l620.32.33-.11 205.24zm1430.98 297.45c-64.06-.03-119.96-15.99-167.7-47.84s-87.35-77.93-118.78-138.24c-31.43-60.29-54.72-132.8-69.84-217.48s-22.65-179.84-22.59-285.54c.08-155.77 14.74-286.15 44.03-391.15 29.28-104.99 72.31-183.88 129.08-236.68 56.76-52.78 127.3-79.17 211.6-79.13 85.4.05 156.19 27.18 212.36 81.4 56.15 54.22 98.25 133.48 126.29 237.82 28.03 104.34 42.03 231.7 41.95 382.05-.06 107.04-7.97 203.57-23.75 289.58-15.78 86.04-39.7 159.18-71.76 219.43-32.06 60.28-72.27 106.32-120.61 138.12-48.35 31.8-105.1 47.69-170.28 47.66m3.48-203.2c25.85.01 49.45-8.77 70.82-26.37 21.35-17.6 39.35-46.04 53.98-85.33 14.61-39.27 26.16-90.39 34.63-153.4 8.45-62.99 12.72-139.2 12.76-228.63.06-107.02-6.36-197.11-19.24-270.27-12.89-73.16-32.23-129.06-58.06-167.69s-57.85-57.95-96.06-57.97c-32.6-.02-61.81 15.89-87.68 47.7q-38.805 47.76-59.94 156.45c-14.08 72.46-21.15 170.34-21.21 293.62-.05 89.43 3.83 165.3 11.67 227.64 7.83 62.33 19.04 112.78 33.64 151.4 14.57 38.62 32.54 67.07 53.89 85.36 21.33 18.31 44.94 27.46 70.79 27.48Zm622.05-93.16.14-258.06c42.73-65 82.1-132.06 118.11-201.13 35.99-69.07 68.06-138.46 96.2-208.22 28.12-69.76 52.89-138.84 74.27-207.26 21.38-68.39 39.4-135.12 54.07-200.14l345.56.18-.72 1343.24-207.34-.11.61-1152.22h-11.81c-21.39 85.34-46.45 166.94-75.14 244.83-28.7 77.9-60.22 151.7-94.52 221.46s-70.57 135.08-108.81 196.02v16.27l620.32.33-.11 205.24z'

  let path = new Path2D(d)
  let viewBox = svgEl.getAttribute('viewBox').split(' ')
  let m = parseFloat(viewBox[2]),
    g = parseFloat(viewBox[3]),
    _ = canvass.width / m,
    v = canvass.height / g,
    y = Math.min(_, v)
  let fillstyle = gsap.getProperty('html', '--red-t-1')
  ctx.setTransform(y, 0, 0, y, 0, 0),
    ctx.translate((canvass.width - m * y) / 2, (canvass.height - g * y) / 2),
    (ctx.fillStyle = fillstyle),
    ctx.fill(path)
  let txttr = new THREE.CanvasTexture(canvass)
  let vPixelRatio = window.devicePixelRatio || 2
  ;(txttr.width = canvass.width / vPixelRatio), (txttr.height = canvass.height / vPixelRatio)
  gsap.to(svgEl, {
    autoAlpha: 0,
    duration: 1,
    ease: 'Power4.easeInOut',
  })
  return txttr
}

export const NOTANEXIT = ({ ref, style }) => {
  return (
    <Canvas ref={ref} style={style}>
      <OrthographicCamera makeDefault={true} near={0.1} far={1000} left={-2} right={2} top={1} bottom={-1} />
      <EXIT />
    </Canvas>
  )
}

const EXIT = () => {
  const variation = 45
  const { scene, camera, gl, set } = useThree()
  const canvas = gl.domElement
  const textureRef = useRef()
  const canvasRef = useRef()
  const vMouse = useRef(new THREE.Vector2(0, 0))
  const [vPixelRatio, setVpixelRatio] = useState(2)
  useEffect(() => {
    setVpixelRatio(window.devicePixelRatio || 2)
  }, [])
  const [canvasSize, setCanvasSize] = useState({ width: 1024, height: 1024 })
  useEffect(() => {
    setCanvasSize({ width: canvas.offsetWidth, height: canvas.offsetHeight })
  }, [])
  const uniforms = useMemo(
    () => ({
      uTime: 0.0,
      uIntensity: [0, 0],
      uDirection: 0.0,
      u_mouse: new THREE.Vector2(0, 0),
      u_resolution: new THREE.Vector2(1, 1),
      u_pixelRatio: vPixelRatio,
      u_pxRange: 3,
      u_alpha: 1,
      canvasTexture: canvasser(canvas.offsetHeight, canvas.offsetWidth),
    }),
    [vPixelRatio],
  )

  useEffect(() => {
    const onPointerMove = (e) => {
      vMouse.current.set(-window.innerWidth + e.clientX * 2, window.innerHeight - 2 * e.clientY)
    }
    const preventDefault = (e) => {
      e.preventDefault()
    }
    document.addEventListener('mousemove', onPointerMove)
    document.addEventListener('pointermove', onPointerMove)
    document.body.addEventListener('touchmove', preventDefault, { passive: false })

    return () => {
      document.removeEventListener('mousemove', onPointerMove)
      document.removeEventListener('pointermove', onPointerMove)
      document.body.removeEventListener('touchmove', preventDefault)
    }
  }, [])
  const ShaderM = shaderMaterial(uniforms, '' + vertexShader, '' + fragmentShader)
  extend({ ShaderM })

  const resizer = useWindowResize()
  const mat = useRef(),
    quad = useRef()
  const resize = useMemo(() => {
    return () => {
      if (mat.current && quad.current) {
        let w = window.innerWidth
        let h = window.innerHeight

        const dpr = window.devicePixelRatio || 2
        gl.setSize(w, h)
        gl.setPixelRatio(dpr)
        camera.left = -w / 2
        camera.right = w / 2
        camera.top = h / 2
        camera.bottom = -h / 2
        camera.updateProjectionMatrix()
        quad.current.scale.set(w, h, 1)
        mat.current.uniforms.u_resolution.value.set(w, h).multiplyScalar(dpr)
        mat.current.uniforms.u_pixelRatio = dpr
      }
    }
  }, [camera, gl])
  useEffect(() => {
    resize()
  }, [resizer])
  useEffect(() => {
    resize()
  }, [])
  let counter = 0
  useFrame(({ clock }, delta) => {
    if (mat.current && mat.current.uniforms) {
      if (counter < 50) {
        counter++
      } else {
        console.log('mat here, uniform is:', mat.current.uniforms)
        counter = 0
      }
      mat.current.uniforms.u_mouse.value = new THREE.Vector2(
        THREE.MathUtils.damp(uniforms.u_mouse.x, vMouse.current.x, 1, delta),
        THREE.MathUtils.damp(uniforms.u_mouse.y, vMouse.current.y, 1, delta),
      )
    }
  })
  const pageIsTransitioning = useRPStore((l) => l.pageIsTransitioning),
    transitionOutType = useRPStore((l) => l.transitionOutType)
  const lastTimeRef = useRef(false)
  useEffect(() => {
    if (transitionOutType === 'NORMAL' && pageIsTransitioning) {
      if (!lastTimeRef.current) {
        lastTimeRef.current = true
      } else {
        uniforms.canvasTexture.dispose()
      }
    }
  }, [transitionOutType])
  return (
    <group>
      <mesh ref={quad}>
        <planeGeometry args={[1, 1]} position={[0, 0, 1]} />
        <shaderM ref={mat} transparent={true} opacity={1} defines={{ VAR: variation }} />
      </mesh>
    </group>
  )
}
