'use client'
import { useEffect, useRef } from 'react'
import './mis.css'
import { MMM } from '@/components/layouts/Missing/mm'
import gsap from 'gsap/all'
import { useVoyageur } from '@/stores/RP_Voyageur'

export function Missing() {
  const is404 = useVoyageur((l) => l.is404)
  const has = useRef(false)

  const curt = useRef<HTMLDivElement>(null!)

  useEffect(() => {
    if (curt.current && is404 && !has.current) {
      has.current = true
      MMM(curt.current)
      gsap.to(curt.current, {
        autoAlpha: 1,
        delay: 0.5,
        duration: 0.5,
        ease: 'Power4.EaseInOut',
      })
    }
    return () => {
      document.addEventListener('transFour', () => {
        has.current = false
      })
    }
  }, [is404, curt])

  return (
    <div ref={curt} className="curtains-canvas" style={{ opacity: 0, visibility: 'hidden' }}></div>
  )
}
