import React, { useEffect, useState } from 'react'
import { useRPStore } from '@/providers/RP_Pro'


export const Logo = () => {
  return (
    <svg width={45} height={45} xmlns="http://www.w3.org/2000/svg" className="ha-ico" viewBox="0 0 45 45" data-themed="color,fill" fill="none">
      <path
        d="m10.17,42.82l-.05-40.63c0-.27.29-.5.64-.5h3.14c.35,0,.64.22.64.5l.03,25.87c0,.27.29.5.64.5h13.63c.35,0,.64-.23.64-.52v-10.96c-.01-.27.27-.5.63-.5h3.14c.35,0,.64.22.64.5l.03,25.74c0,.27-.29.5-.64.5h-3.14c-.35,0-.64-.22-.64-.5v-12.39c-.01-.27-.3-.5-.65-.5h-13.63c-.35,0-.64.23-.64.52v12.39c.01.27-.27.5-.63.5h-3.14c-.35,0-.64-.22-.64-.5h0Z"
        fill="oklch(var(--n-s-fg)/1)" data-themed="fill" strokeWidth={0} />
      <circle cx="31.97" cy={7} r="2.91" fill="var(--cFill)" strokeWidth={0} />
    </svg>)
}
