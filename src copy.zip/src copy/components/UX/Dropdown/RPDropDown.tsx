'use client'

import { ButtonHTMLAttributes, FC, forwardRef, HTMLAttributes, useCallback, useEffect, useRef, useState } from 'react'
import { useRPStore } from '@/providers/RP_Pro'
import { cn } from '@/lib/utils'
import { useLenis } from 'lenis/react'

import gsap from 'gsap'
import { wait } from '@/utilities/Helpers'
import { Link, RP_Btn } from 'src/components/UX/Link'
import { SvgIco } from '@/components/UX/svgIco'
import { Button } from '@/components/ui/button'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuGroup,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuPortal,
  DropdownMenuSeparator,
  DropdownMenuShortcut,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger, DropOutButton,
  LinkedDropdownItem,
} from '@/components/ui/dropdown-menu'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { concat } from 'lodash'
import { RPTooltip } from '@/components/UX/tooltip'

import { RP_Patron } from '@/stores/RP_Ui'
import { SignOutButton } from '@/components/UX/SignOutButton'

interface SlitProps extends HTMLAttributes<HTMLDivElement> {
  style: HTMLAttributes<HTMLDivElement>['style'] & {
    '--orz': string
    '--id': number
    '--ol': string
    '--tm': string
    '--thx': string
  }
  size: 'T' | 'S'
}

const Slit = forwardRef<HTMLDivElement, SlitProps>((props, ref) => {
  let { size, ...rest } = props
  return <div className={cn({ sh: size === 'S', tl: size === 'T' })} ref={ref} {...rest} />
})
export type RP_DDProps = HTMLAttributes<HTMLDivElement> & {
  moves: HTMLElement[]
}

export interface DD_ToggleButtonProps extends Omit<ButtonHTMLAttributes<HTMLButtonElement>, 'style'> {
  style: HTMLAttributes<HTMLButtonElement>['style'] & {
    '--of'?: string | number
  }
}

const DTButton = forwardRef<HTMLButtonElement, DD_ToggleButtonProps>((props, ref) => {
  return <button ref={ref} {...props} />
})

export function UserDropdown(props:{user:RP_Patron}) {
  const {user} = props
  if(!user)return null
  const dropdownOpen = useRPStore((store) => store.dropdownOpen)
const setD = useRPStore((store) => store.setDropdownOpen)
  const [isOpen, setIsOpen] = useState(false)
  useEffect(() => {
    if(dropdownOpen)setIsOpen(true)
    else setIsOpen(false)
  }, [dropdownOpen])
  return (
    <DropdownMenu open={isOpen} onOpenChange={open => setIsOpen(open)} >
      <DropdownMenuTrigger asChild>
        <RP_Btn className={'circ-bt items-center justify-center has-tooltip'} style={{display:'flex'}} aria-label={`@${user.slug}`}><Avatar >
          {user.image&&(<AvatarImage src={user.image} alt={user.name??''} />)}
          <AvatarFallback>{user.firstName&&user.firstName.charAt(0)||user.name?.charAt(0)}</AvatarFallback>
        </Avatar><RPTooltip className="top text-sm" label={`@${user.slug}`} /></RP_Btn>
      </DropdownMenuTrigger>
      <DropdownMenuContent sideOffset={15}   className="w-56 right-[15px]">
        <DropdownMenuLabel>My Account</DropdownMenuLabel>
        <DropdownMenuSeparator />
        <DropdownMenuGroup>
          <LinkedDropdownItem href={'/profile'} title={'Profile'}>
            <DropdownMenuShortcut>⇧⌘P</DropdownMenuShortcut>
          </LinkedDropdownItem>
          <DropdownMenuItem>
            Billing
            <DropdownMenuShortcut>⌘B</DropdownMenuShortcut>
          </DropdownMenuItem>
          <DropdownMenuItem>
            Settings
            <DropdownMenuShortcut>⌘S</DropdownMenuShortcut>
          </DropdownMenuItem>
          <DropdownMenuItem>
            Keyboard shortcuts
            <DropdownMenuShortcut>⌘K</DropdownMenuShortcut>
          </DropdownMenuItem>
        </DropdownMenuGroup>
        <DropdownMenuSeparator />
        <DropdownMenuGroup>
          <DropdownMenuItem>Team</DropdownMenuItem>
          <DropdownMenuSub>
            <DropdownMenuSubTrigger>Invite users</DropdownMenuSubTrigger>
            <DropdownMenuPortal>
              <DropdownMenuSubContent>
                <DropdownMenuItem>Email</DropdownMenuItem>
                <DropdownMenuItem>Message</DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem>More...</DropdownMenuItem>
              </DropdownMenuSubContent>
            </DropdownMenuPortal>
          </DropdownMenuSub>

        </DropdownMenuGroup>
        <DropdownMenuSeparator />
        <DropdownMenuItem>GitHub</DropdownMenuItem>
        <DropdownMenuItem>Support</DropdownMenuItem>
        <DropdownMenuItem disabled>API</DropdownMenuItem>
        <DropdownMenuSeparator />
        <DropOutButton/>
      </DropdownMenuContent>
    </DropdownMenu>
  )
}
export const RP_DROPDOWN: FC = () => {
  const user = useRPStore((l) => l.user), setUser = useRPStore((l) => l.setUser)
  const [isOpen, setIsOpen] = useState(false)
  const charscount = 9
  const navIsOpen = useRPStore((store) => store.navIsOpen)
  const scrollY = useRPStore((store) => store.scrollY)
  const dropdownOpen = useRPStore((store) => store.dropdownOpen)
  const scroller = useLenis()
  const setDropdownOpen = useRPStore((store) => store.setDropdownOpen)
  let toggle = useRef<HTMLButtonElement>(null!), content = useRef<HTMLDivElement>(null!),
    sections = useRef<HTMLElement[]>([]), hvContent = useRef<any[]>([]), container = useRef<HTMLDivElement>(null!),
    chars = useRef<HTMLDivElement[]>([])
  const [midpoint, setMidpoint] = useState(30 / 2)
  const f = (midpoint * 2) / charscount

  const handleClick = useCallback((toggle: boolean) => {
    let toGo = navIsOpen ? true : toggle
    setDropdownOpen(toGo)
  }, [navIsOpen, setDropdownOpen])
  const handleScroll = useCallback(() => {
    setDropdownOpen(false)
    return scroller!.off('scroll', handleScroll)
  }, [scroller])
  const toggleMenu = useCallback((isOpe: boolean, navIsOpen: boolean = false) => {
    gsap.killTweensOf([content.current, container.current, ...chars.current, toggle.current])
    const t = {
      duration: 0.6, ease: 'power2.inOut',
    }
    if (isOpe) {
      wait(navIsOpen ? 300 : 0).then(() => (gsap.set(content.current, {
        autoAlpha: 1,
      }), gsap.set(content.current, {
        height: 'auto', width: 160,
      }), gsap.to(container.current, {
        ...t, x: -10,
      }), gsap.from(content.current, {
        height: 0, width: 0, ...t,
      }), gsap.to(toggle.current, {
        y: 10, x: 0, ...t, duration: 0.4,
      }), scroller && scroller.on('scroll', handleScroll)))
    } else {
      gsap.to(container.current, {
        x: 0, duration: 0.6,
      })
      gsap.set(content.current, {
        autoAlpha: 0, delay: 0.6,
      })
      gsap.to(content.current, {
        height: 0, width: 0, ...t,
      })
      gsap.to(toggle.current, {
        color: '', y: 0, x: 0, ...t,
      })
    }
  }, [content, container, toggle, scroller, handleScroll])
  useEffect(() => {
    sections.current = gsap.utils.toArray(['.dropdown-section', '.dropdown-link'])

    setMidpoint(toggle.current.offsetWidth / 2)
  }, [])

  useEffect(() => {
    toggleMenu(dropdownOpen, navIsOpen)
  }, [toggleMenu, dropdownOpen])
  useEffect(() => {
    setDropdownOpen(navIsOpen)
  }, [navIsOpen, setDropdownOpen])
  const headerTheme = useRPStore((l) => l.headerTheme)
  return (<div id="h-dropdown" ref={container} className={cn('dropdown-wrapper', {
    'nav-open': navIsOpen, open: dropdownOpen,
  })} data-themed={'background-color,border-color,color'}
               {...(user ? {} : { style: { display: 'none' } })}
  >
    <Button type="button" ref={toggle} className="rp_btn dropdown-user" onClick={() => handleClick(!dropdownOpen)}
            style={{
              fontSize: '12px', textWrap: user ? 'initial' : 'nowrap',
            }} data-themed={'color,background-color,fill'} aria-controls="h-dropdown" aria-label="Toggle Menu">
      <SvgIco viewBox="0 0 24 24" width="16" height="16" fill={'oklch(var(--n-s-fg)/1)'}
              paths={['M17.908 14.755c3.918 0 6.092 1.654 6.092 4.745 0 2.755-1.745 4.5-4.5 4.5-3.092 0-4.745-2.173-4.745-6.092v-1.806h-5.51v1.806C9.245 21.826 7.592 24 4.5 24 1.745 24 0 22.255 0 19.5c0-3.092 2.173-4.745 6.092-4.745h1.806v-5.51H6.092C2.173 9.245 0 7.592 0 4.5 0 1.745 1.745 0 4.5 0c3.092 0 4.745 2.173 4.745 6.092v1.806h5.51V6.092C14.755 2.174 16.408 0 19.5 0 22.255 0 24 1.745 24 4.5c0 3.092-2.173 4.745-6.092 4.745h-1.806v5.51zM7.898 7.898V6.092c0-3.215-1.132-4.745-3.398-4.745-2.02 0-3.153 1.133-3.153 3.153 0 2.265 1.531 3.398 4.745 3.398zm0 8.204H6.092c-3.214 0-4.745 1.132-4.745 3.398 0 2.021 1.133 3.153 3.153 3.153 2.265 0 3.398-1.531 3.398-4.745zm1.347-1.347h5.51v-5.51h-5.51zm6.857-6.857h1.806c3.214 0 4.745-1.132 4.745-3.398 0-2.02-1.132-3.153-3.153-3.153-2.265 0-3.398 1.531-3.398 4.745zM22.653 19.5c0-2.265-1.531-3.398-4.745-3.398h-1.806v1.806c0 3.215 1.133 4.745 3.398 4.745 2.02 0 3.153-1.132 3.153-3.153', {
                'data-themed': 'fill',
              }]} />
    </Button>
    <div className="dropdown-content" ref={content}>
      {user && (<>
        <div className="dropdown-spacer"></div>
        <div className="dropdown-section">
          <div className="dropdown-section-label">{'name' in user ? user.name : ''}</div>
          <Link href={'/public' + user.handle} className="dropdown-section-link">
            <span>MY CV</span>
          </Link>
        </div>
        <Link href="/vault" rel="" title="" aria-label="" className="dropdown-link">
          <span>MY SAVED</span>
          <span className="dropdown-arrow">→</span>
        </Link>
        <Link href={'/profil'} rel="" title="" aria-label="" className="dropdown-link">
          <span>MY PROFIL</span>
          <span className="dropdown-arrow">→</span>
        </Link>
        <Link href="/suite" className="dropdown-link" data-swup-animation="navlink">
          <span>Settings</span>
          <span className="dropdown-arrow">→</span>
        </Link>
        <Link className="dropdown-link" href={'/logout'} onClick={() => setUser(null)}>
          <span>Check Out</span>
          <span className="dropdown-arrow">→</span>
        </Link>
      </>)}
    </div>
  </div>)
}
