'use client'
import { AnimatePresence, motion } from 'motion/react'
import { Fragment, useEffect, useMemo, useRef, useState } from 'react'
import { getDeviceInfo, useCursorStore } from '@/providers/RP_Pro'
import { useLenis } from 'lenis/react'

export const Justification = (props: {
  posterEnabled: boolean
  controls: boolean
  loop: boolean
  playsInline: boolean
  muted: boolean
  autoPlay: boolean
  restartOnEnter: boolean
  objectFit: 'cover' | 'contain' | 'fill' | 'none' | 'scale-down' | string
  backgroundColor: CSSStyleDeclaration['backgroundColor']
  volume: number
  startTime: number
}) => {
  const { isMobile } = getDeviceInfo()
  const setCursorState = useCursorStore((store) => store.setCursorState)[0]
  const hMI = useMemo(() => (input: null | 'FOCUS' | string) => {
    !isMobile && setCursorState(input)
  }, [setCursorState, isMobile])
  const hME = () => hMI('FOCUS')
  const hMO = () => hMI(null)

  const translaterr = (t, n) => `translate(-50%, -50%) ${n}`
  const [visibility, setVisibility] = useState(false)
  const lenis = useLenis()
  const {
    posterEnabled,
    controls,
    loop,
    playsInline,
    muted,
    autoPlay,
    restartOnEnter,
    objectFit,
    backgroundColor,
    volume,
    startTime,
  } = props
  const videoRef = useRef<HTMLVideoElement>(null!)
  const [playing, setPlaying] = useState(false)
  useEffect(() => {
    if (!videoRef.current) return
    if (volume) {
      videoRef.current.volume = volume / 100
    } else {
      videoRef.current.volume = 0.15
    }
  }, [])
  const bgRE = useRef<HTMLDivElement>(null!)
  const bgTL = useRef<GSAPTimeline>(null!)

  useEffect(() => {
    lenis && lenis[visibility ? 'stop' : 'start']()
    if (visibility && videoRef.current) {
      videoRef.current.currentTime = startTime
      bgTL.current && bgTL.current.play()
    }
    if (!visibility) {
      hME()
      bgTL.current && bgTL.current.pause()
    }
  }, [visibility])

  return (<>
      <div className="flex flex-col justify-items-start shrink-0" data-highlight="true" style={{
        flex: '0 0 auto', height: 'auto', position: 'relative', width: 'auto',
      }} onMouseEnter={hME} onMouseLeave={hMO} onClick={() => {
        setVisibility(true)
      }}>
        <p>Why pay for all this?</p>
      </div>
      <div id={'overlayer'}>
        <AnimatePresence key="the_pitch" mode="sync">
          {visibility ? (<motion.div key={'pitchy'} ref={bgRE} animate={{
              opacity: 1,
              transition: {
                default: {
                  delay: 0, duration: 1, ease: [0.5, 0, 0.88, 0.77], type: 'tween',
                }, backgroundColor: {
                  delay: 0, duration: 2, type: 'tween', times: [0.2, 1],
                },
              },
              backgroundColor: ['oklch(14.17% 0 118.54/.2)', 'oklch(14.17% 0 118.54/1)'],
              backdropFilter: 'blur(10px)',
            }} exit={{
              opacity: 0, transition: {
                delay: 0, duration: 1, ease: [0.12, 0.23, 0.5, 1], type: 'tween',
              }, backgroundColor: 'oklch(14.17% 0 118.54/0)', backdropFilter: 'initial',
            }} initial={{
              opacity: 0,
            }} data-lenis-prevent="true" className="fixed inset-0 z-[10]" />) : null}
          {visibility ? (
            <motion.div key={
              'preachy'
            } data-lenis-prevent="true" layoutRoot={true} className="fixed inset-0 overflow-hidden z-[10]">
              <motion.div className="absolute opacity-0 inset-0" initial={{ zIndex: 11 }}
                          onMouseEnter={() => hMI('CLOSE')} onMouseLeave={hMO} onTap={() => {
                setVisibility(false)
              }}></motion.div>
              <motion.div
                className="items-end flex flex-nowrap justify-center gap-[10px] h-min left-[55%] p-0 overflow-visible top-[50%] absolute w-min transform-[translate(-50%,-50%)] z-[22]"
                style={{
                  flex: '0 0 auto',
                }}>
                <motion.div className="relative h-[550px] w-[550px] flex-none" initial={{
                  opacity: 1,
                  rotate: 0,
                  rotateX: -90,
                  rotateY: 0,
                  scale: 1,
                  skewX: 0,
                  skewY: 0,
                  transformPerspective: 1200,
                  x: 0,
                  y: -800,
                }} animate={{
                  opacity: 1,
                  rotate: 0,
                  rotateX: 0,
                  rotateY: 0,
                  scale: 1,
                  skewX: 0,
                  skewY: 0,
                  transformPerspective: 1200,
                  transition: {
                    delay: 0, duration: 1, ease: [0.44, 0, 0, 1], type: 'tween',
                  },
                  x: 0,
                  y: 0,
                }} exit={{
                  opacity: 1, rotate: 0, rotateX: 100, rotateY: 0, scale: 1, skewX: 0, skewY: 0, transition: {
                    delay: 0, duration: 1, ease: [0.44, 0, 0, 1], type: 'tween',
                  }, x: 0, y: 700,
                }} style={{ transformPerspective: 1200 }}>
                  <video ref={videoRef} controls={false} loop={true} muted={false} src="/media/f.mp4" width={'100%'}
                         height={'100%'} autoPlay={true} style={{
                    objectFit: 'cover',
                    backgroundColor: 'rgba(0, 0, 0, 0)',
                    borderRadius: 20,
                    borderTopLeftRadius: 20,
                    borderTopRightRadius: 20,
                    width: '100%',
                    height: '100%',
                    borderBottomLeftRadius: 20,
                    borderBottomRightRadius: 20,
                  }} />
                </motion.div>
                <motion.div
                  key={crypto.randomUUID()}
                  className="relative content-center items-center flex gap-[10px] h-min w-[161px] flex-none flex-col flex-wrap overflow-hidden p-0"
                  animate={{
                    opacity: 1, rotate: 0, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, transition: {
                      delay: 1.8, duration: 0.4, ease: [0.44, 0, 0.56, 1], type: 'tween',
                    }, x: 0, y: 0,
                  }} exit={{
                  opacity: 0, rotate: 0, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, transition: {
                    delay: 0, duration: 0.3, ease: [0.44, 0, 0.56, 1], type: 'tween',
                  }, x: 0, y: 0,
                }} initial={{
                  opacity: 0, rotate: 0, rotateX: 0, rotateY: 0, scale: 1, skewX: 0, skewY: 0, x: 0, y: 0,
                }} style={{ flex: '0 0 auto' }}>
                  <motion.div
                    className="flex-none h-auto opacity-70 relative whitespace-pre-wrap w-full break-words outline-none justify-start shrink-0">
                    <motion.p>Trust the process.</motion.p>
                  </motion.div>
                  <motion.div className="flex-none h-auto relative whitespace-pre-wrap w-full break-words outline-none justify-start shrink-0
                  ">
                    <motion.p>Trust the process.</motion.p>
                  </motion.div>
                </motion.div>
              </motion.div>
            </motion.div>) : null}
        </AnimatePresence>
      </div>
    </>)
}
