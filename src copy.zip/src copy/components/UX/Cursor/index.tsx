'use client'

import gsap from 'gsap'
import { RefObject, useEffect, useRef, useState } from 'react'

import { getDeviceInfo, useCursorStore, useRafStore, useRPStore } from '@/providers/RP_Pro'
import { lerp } from '@/utilities/Helpers'
import { cn } from '@/lib/utils'
import { useTheme } from '@/providers/Theme'

const TextCursorStates = ['HOVER', 'DRAG', 'CLICK TO TURN', 'CLOSE']

const cursorTheme = 'dark'
const P = {
  LARGE: 48, MEDIUM: 17, SMALL: 6,
}

// Initialize cursor
export default function RP_Cursor() {
  const [tc, setTextCursorStates] = useState(TextCursorStates)
  const [setCoord, api] = useCursorStore((l) => l.setMouseCoordinates)
  const cursorState = useCursorStore((l) => l.cursorState)[0]
  const oCircle = useRef(null)
  const iCircle = useRef(null)
  const cursr = useRef(null)
  const rafAdd = useRafStore((l) => l.addToRaf)
  const rafRem = useRafStore((l) => l.removeFromRaf)
  const xSetter = gsap.quickSetter(cursr.current, 'x', 'px')
  const ySetter = gsap.quickSetter(cursr.current, 'y', 'px')
  const cursorTheme = useCursorStore((l) => l.cursorTheme)[0]
  const setCursorTheme = useCursorStore((l) => l.setCursorTheme)[0]
  const theme = useTheme(r=>r.theme)
  const navIsOpen = useRPStore((l) => l.navIsOpen)
  useEffect(() => {
    const handleMouseOver = (c) => {
      let d = 0
      let h = 0
      if (c.changedTouches) {
        let p
        let m;
        (d = (p = c.changedTouches[0]) === null || void 0 === p ? void 0 : p.clientX), (h = (m = c.changedTouches[0]) === null || void 0 === m ? void 0 : m.clientY)
      } else (d = c.clientX), (h = c.clientY)
      setCoord({
        x: d, y: h,
      })
    }
    return (document.removeEventListener('pointerdown', handleMouseOver), document.removeEventListener('pointermove', handleMouseOver), document.removeEventListener('mousemove', handleMouseOver), document.addEventListener('mousemove', handleMouseOver), document.addEventListener('pointerdown', handleMouseOver), document.addEventListener('pointermove', handleMouseOver), () => {
      document.removeEventListener('pointerdown', handleMouseOver), document.removeEventListener('pointermove', handleMouseOver), document.removeEventListener('mousemove', handleMouseOver)
    })
  }, [])
  const smoothCoordinates = useRef({ x: 0, y: 0 })
  const mouseCoordinates = useRef({
    x: 0, y: 0,
  })
  const Unsub: RefObject<null | (() => void)> = useRef(null)
  const textCursor = useRef({})
  const { isMobile } = getDeviceInfo()
  const [showCursor, setShowCursor] = useState(!1)
  const [isTextCursor, setIsTextCursor] = useState(!1)
  const raf = (l: boolean) => {
    l ? (smoothCoordinates.current = {
      x: mouseCoordinates.current.x, y: mouseCoordinates.current.y,
    }) : (smoothCoordinates.current = {
      x: lerp(smoothCoordinates.current.x, mouseCoordinates.current.x, 1),
      y: lerp(smoothCoordinates.current.y, mouseCoordinates.current.y, 1),
    }), cursr.current && gsap.set(cursr.current, {
      x: smoothCoordinates.current.x - 0.5 * (cursr.current as HTMLSpanElement).offsetWidth,
      y: smoothCoordinates.current.y - 0.5 * (cursr.current as HTMLSpanElement).offsetWidth,
    })
  }
  const animateCursor = (cursorState: string | null) => {
    const isFocus = cursorState === 'FOCUS'
    const isTC = (typeof cursorState === 'string') && (!isFocus || TextCursorStates.includes(cursorState))
    setIsTextCursor(isTC), gsap.killTweensOf([oCircle.current, iCircle.current])
    let outerRad = P.SMALL;
    (isTextCursor || isFocus) && (outerRad = isFocus ? P.MEDIUM : P.LARGE), gsap.to(oCircle.current, {
      attr: {
        r: outerRad,
      }, ease: 'Power3.easeOut', duration: 0.3,
    }), gsap.to(iCircle.current, {
      attr: {
        r: cursorState === null ? outerRad : isTextCursor ? 0 : 1,
      }, ease: 'Power3.easeOut', duration: 0.3,
    })
    Object.keys(textCursor.current).forEach((text) => {
      const isTextCursor = text === cursorState
      const currentText = textCursor.current[text]
      const p = 'Power3.easeOut'
      currentText && (gsap.killTweensOf(currentText), isTextCursor ? gsap.fromTo(currentText, {
        y: '110%',
      }, {
        y: 0, duration: 0.44999999999999996, ease: p,
      }) : gsap.to(currentText, {
        y: '-110%', duration: 0.22499999999999998, ease: p,
      }))
    })
  }
  const baseTheme = useCursorStore((l) => l.baseCursorTheme)[0]
  const setBaseCursorTheme = useCursorStore((l) => l.setBaseCursorTheme)[0]
  const resetCursorTheme = useCursorStore((l) => l.resetCursorTheme)[0]

  useEffect(() => {
    console.log('cursorTheme',cursorTheme,'theme',theme)
    theme&&(setBaseCursorTheme(theme),(!navIsOpen)&&resetCursorTheme())

  }, [theme])

  useEffect(() => {
    animateCursor(cursorState)
  }, [cursorState])
  useEffect(() => {
    return (rafRem('cursor'), isMobile || rafAdd({
      key: 'cursor', callback: raf,
    }), () => {
      rafRem('cursor')
    })
  }, [isMobile])
  useEffect(() => {
    Unsub.current && Unsub.current()
    Unsub.current = api.subscribe((state) => state.mouseCoordinates, (l) => {
      ;(mouseCoordinates.current.x = l.x), (mouseCoordinates.current.y = l.y)
      l.x === 0 || l.y === 0 || showCursor || (raf(!0), setShowCursor(!0))
    }, {
      fireImmediately: true,
    })
    return () => {
      Unsub.current && Unsub.current()
    }
  }, [showCursor])


  return (<span className={cn({
    text__cursor: isTextCursor, show_cursor: showCursor,
  }, 'cursor rp__cursor')} data-theme={theme} data-state={cursorState || 'null'} ref={cursr} aria-hidden={!0}
                >
      <span className="cursor__text-container">
        {TextCursorStates.map((text, idx) => (
          <span key={idx + 'cursor'} className="cursor__text-caption" ref={(node) => {
            textCursor.current[text] = node
          }}>
            {text}
          </span>))}
      </span>
      <svg viewBox="0 0 100 100" className="cursor_svg">
        <circle ref={oCircle} className="circleOutline" cx={50} cy={50} r={0} strokeWidth={1} fill="transparent"
                data-themed="stroke" />
        <circle ref={iCircle} className="circleFilled" cx={50} cy={50} r={0} strokeWidth={0} fill="transparent"
                data-themed="fill" />
      </svg>
    </span>)
}
