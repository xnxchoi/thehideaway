'use client'
import Lottie from 'react-lottie'
import * as darkAnimation from './lottie-dark.json'
import * as lightAnimation from './lottie-light.json'
import { useEffect, useRef, useState } from 'react'
import { useRPStore } from '@/providers/RP_Pro'
import { useGSAP } from '@gsap/react'
import gsap from 'gsap'
import { canUseDOM } from '@/utilities/canUseDOM'

export const LoaderLottie = () => {

  const theme = useRPStore((l) => l.theme)
  const [animationData, setAnimationData] = useState(darkAnimation)
  useEffect(() => {
    canUseDOM&& setAnimationData(theme === 'dark' ? darkAnimation : lightAnimation)
  }, [theme])
  const pageIsTransitioning = useRPStore((l) => l.pageIsTransitioning)
  const divRef = useRef<HTMLDivElement>(null!)
  const tlRef = useRef<gsap.core.Timeline>(null!)
  useGSAP(() => {
    gsap.killTweensOf(divRef.current)
    gsap.to(divRef.current, {
      duration: 0.4,
      delay: pageIsTransitioning ? 0 : 0.2,
      ease: 'power3.easeInOut',
      autoAlpha: pageIsTransitioning ? 1 : 0,
    })
  }, { scope: divRef, dependencies: [pageIsTransitioning] })
  return (<div ref={divRef} className="w-[120px] h-[120px] xl:w-[24vw] xl:h-[24vw] gap-x-2.5 gap-y-2.5 flex flex-col justify-center items-center
    fixed inset-0 overflow-hidden contents-center bg-transparent m-auto z-[14]">
    <div className="w-full flex">
      {canUseDOM&&( <Lottie key={crypto.randomUUID()} options={{autoplay: true, loop: true, animationData, rendererSettings: {preserveAspectRatio: 'xMidYMid slice',},}} />)}
    </div>
  </div>)
}
