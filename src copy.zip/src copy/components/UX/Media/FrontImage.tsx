'use client'

import { Media } from '@/payload-types'
import { ImageMedia } from '@/components/UX/Media/ImageMedia'
import { useEffect, useState } from 'react'
import { useCursorStore, useRPStore } from '@/providers/RP_Pro'
import { getClientSideURL } from '@/utilities/getURL'
import type { Props as MediaProps } from '@/components/UX/Media/types'
import { assessImageBrightness } from '@/utilities/getPictureBrightness'

export const FrontImage = (props: MediaProps) => {
  const { resource: image, ...rest } = props
  const [imageMedia, setImageMedia] = useState<Media>(null!)
  const [hover, setHover] = useState<boolean>(false)
  const setCursorTheme = useCursorStore((store) => store.setCursorTheme)[0]
  const theme = useRPStore((store) => store.theme)
  const [imageTheme, setImageTheme] = useState<'light' | 'dark' | string>('light')
  useEffect(() => {
    if (!image) return
    if (typeof image === 'number' || typeof image === 'string') {
      fetch(`${getClientSideURL()}/api/media/${image}`).then((res) => res.json()).then((res) => {
        setImageMedia(res)
      })
    } else {
      setImageMedia(image)
    }
  }, [])
  useEffect(() => {
    if (!imageMedia) return
    if (imageMedia.darkmode === null || imageMedia.darkmode === undefined) {

      {
        assessImageBrightness({
          url: imageMedia.url, width: imageMedia.width, height: imageMedia.height, id: imageMedia.id,
        }).then((res) => {
          fetch(`${getClientSideURL()}/api/media/${image}`).then((res) => res.json()).then((res) => {
            setImageMedia(res)
          })
        })
      }
    }
  }, [])
  useEffect(() => {
    if (!imageMedia || (imageMedia.darkmode === null) || (imageMedia.darkmode === undefined)) return
    setImageTheme(imageMedia.darkmode ? 'dark' : 'light')
  }, [imageMedia])
  useEffect(() => {

    if (hover) {
      setCursorTheme(imageTheme)
    } else {
      setCursorTheme(theme)
    }
  }, [hover])
  return imageMedia && (
    <ImageMedia fill priority={false} loading="lazy" imgClassName="rp_lazy thumb css-filter size-large"
                resource={imageMedia} {...rest} />) || (
    <div onMouseOver={() => setHover(true)} onMouseLeave={() => setHover(false)}
         className="w-full h-full rp_lazy thumb css-filter size-large bg-[oklch(var(--faded-fg)/0.2)]" />)
}