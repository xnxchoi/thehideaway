import type { StaticImageData } from 'next/image'
import type { CSSProperties, ElementType, Ref, RefObject } from 'react'

import type { Media as MediaType } from '@/payload-types'

export interface Props {
  alt?: string
  className?: string
  fill?: boolean // for NextImage only
  htmlElement?: ElementType | null
  imgClassName?: string
  onClick?: () => void
  onLoad?: () => void
  loading?: 'lazy' | 'eager' // for NextImage only
  priority?: boolean // for NextImage only
  resource?: MediaType | string | number // for Payload media
  size?: string // for NextImage only
  src?: StaticImageData // for static media
  videoClassName?: string
  style?: CSSProperties
  pageKey?: string
  wrapRef?: Ref<HTMLDivElement | HTMLElement>
  ref?: RefObject<HTMLVideoElement | HTMLImageElement | null>
}

