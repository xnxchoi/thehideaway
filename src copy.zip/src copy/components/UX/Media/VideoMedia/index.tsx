'use client'

import React, { RefObject, useEffect } from 'react'
import { cn } from '@/lib/utils'

import { getClientSideURL } from '@/utilities/getURL'

import type { Props as MediaProps } from '../types'

export const VideoMedia: React.FC<MediaProps> = (props) => {
  const { onClick, resource, videoClassName, style, ref } = props
  // const [showFallback] = useState<boolean>()

  useEffect(() => {
    if (ref) {
      (ref.current) && ref.current.addEventListener('suspend', () => {
        // setShowFallback(true);
        // console.warn('Video was suspended, rendering fallback image.')
      })
    }
  }, [])

  if (resource && typeof resource === 'object') {
    const { filename } = resource

    return (
      (<video autoPlay className={cn(videoClassName)} controls={false} loop muted onClick={onClick} playsInline
                     ref={ref as RefObject<HTMLVideoElement | null>} style={style}>
        <source src={`${getClientSideURL()}/media/${filename}`} />
      </video>)
    );
  }

  return null
}
