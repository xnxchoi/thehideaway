'use client'
import { Fragment, useCallback, useEffect, useRef } from 'react'
import { useRPStore } from '@/providers/RP_Pro'
import gsap from 'gsap'
import { cn } from '@/lib/utils'
import { useWindowResize } from '@/utilities/use_window_resize'

export function ContentMask(l) {
  const windowResize = useWindowResize()
  useEffect(() => {
    document.documentElement.style.setProperty('--vh', window.innerHeight * 0.01 + 'px')
  }, [windowResize])
  let clipType = 'content-mask-clipping', k = 1.8, easeType = 'Power3.easeInOut', { children: c } = l,
    svgRef = useRef(null), rectRef = useRef(null), middlePositioningRef = useRef<HTMLDivElement>(null),
    contentMaskRef = useRef(null), isPreloader = useRPStore((l) => l.isPreloader),
    setIsPreloader = useRPStore((l) => l.setIsPreloader), O = useRPStore((l) => l.setIsAnimatingOutPreloader),
    enablePreloaderAnimation = useRPStore((l) => l.enablePreloaderAnimation), timelineRef = useRef<GSAPTimeline>(null),
    preloaderAnimationType = useRPStore((l) => l.preloaderAnimationType), V = useCallback(() => {
      var l
      if (!svgRef.current || !rectRef.current || !middlePositioningRef.current || !contentMaskRef.current) return
      gsap.set(svgRef.current, {
        width: window.innerWidth, height: window.innerHeight,
      })
      let c = middlePositioningRef.current.offsetHeight,
        h = null === (l = middlePositioningRef.current) || void 0 === l ? void 0 : l.getBoundingClientRect().top
      gsap.set(rectRef.current, {
        width: 0, height: c, attr: {
          y: h, x: 0.5 * window.innerWidth, rx: 0,
        },
      })
    }, []), D = useCallback(() => {
      var l, c
      if (!middlePositioningRef.current) return
      timelineRef.current && timelineRef.current.kill(), (timelineRef.current = gsap.timeline({
        onComplete: () => {
          setIsPreloader(!1)
        },
      }))
      let d = null === (l = middlePositioningRef.current) || void 0 === l ? void 0 : l.offsetWidth, { left: h } = (null === (c = middlePositioningRef.current) || void 0 === c ? void 0 : c.getBoundingClientRect()) || {
        left: 0,
      }
      'FAST' === preloaderAnimationType ? gsap.set(rectRef.current, {
        attr: {
          rx: 15,
        },
      }) : timelineRef.current.to(rectRef.current, {
        width: d, attr: {
          x: h, rx: 15,
        }, delay: 0.2, duration: 1, ease: 'Power3.easeInOut',
      })
      let delayTime = 'FAST' === preloaderAnimationType ? 0 : 3, g = k
      timelineRef.current.to(rectRef.current, {
        width: window.innerWidth, height: window.innerHeight, attr: {
          y: 0, x: 0, rx: 0,
        }, duration: g, ease: easeType, delay: delayTime, onStart: () => {
          O(!0)
        },
      }, 0)
    }, [windowResize, setIsPreloader, preloaderAnimationType, O])

  useEffect(() => {
    V(), enablePreloaderAnimation && D()
  }, [D, windowResize, enablePreloaderAnimation, V])
  return (<Fragment>
      {isPreloader && <div {...{ className: 'middlePositioning', ref: middlePositioningRef }} />}
      <div
        {...{
          className: cn('content-mask', { ['isPreloader']: isPreloader }),
          ref: contentMaskRef,
          style: { clipPath: isPreloader ? 'url("#'.concat(clipType, '")') : void 0 },
        }}
      >
        <div {...{ children: c }} className={'mask__content'} />
        {isPreloader && (<svg {...{ ref: svgRef, className: 'svg-content' }}>
            <defs>
              <clipPath
                {...{
                  id: clipType,
                }}
              >
                <rect
                  {...{
                    ref: rectRef, fill: 'white', y: 0, x: 0, rx: 0, width: 0, height: 0, className: 'rect',
                  }} />
              </clipPath>
            </defs>
          </svg>)}
      </div>
    </Fragment>)
}
