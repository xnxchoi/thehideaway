'use client'
import { useEffect, useRef, useState } from 'react'
import { useLenis } from 'lenis/react'
import { useRPStore } from '@/providers/RP_Pro'
import gsap from 'gsap'
import { cn } from '@/lib/utils'

export const ScrollIndicator = () => {
  const [scroll, setScroll] = useState(0)
  const pageIsTransitioning = useRPStore((l) => l.pageIsTransitioning)
  const scrolle = useRef<HTMLDivElement>(null!)
  const navIsOpen = useRPStore((l) => l.navIsOpen)
  useLenis((lenis) => {
    (!pageIsTransitioning) &&setScroll(lenis.progress * 100)
  })
  useEffect(() => {
    let tovalue=pageIsTransitioning?0:1
     gsap.to(scrolle.current,{autoAlpha:tovalue,scaleY:tovalue,duration:0.2,ease:'power4.inOut'})
  },[pageIsTransitioning])

  return (

    <div className={cn('fixed right-0 bottom-[45px] top-[45px] w-[10px] flex justify-center bg-n-s-fg z-[248]',{hidden:navIsOpen})}>
      <svg aria-hidden="true" >
        <defs>
          <filter id="goo-effect">
            <feGaussianBlur in="SourceGraphic" stdDeviation="5" result="blur" />
            <feColorMatrix
              in="blur"
              type="matrix"
              values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 18 -15"
              result="goo"
            />
            <feComposite in="SourceGraphic" in2="goo" operator="atop" />
          </filter>
        </defs>
      </svg>
      <div ref={scrolle} style={{ height: `${scroll}%` , transitionTimingFunction:'ease',transitionProperty:'height'}} className="bg-red-700 w-[2px]"></div>
    </div>)
}