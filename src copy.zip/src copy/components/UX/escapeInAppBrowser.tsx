'use client'
import { getDeviceInfo, useRPStore } from '@/providers/RP_Pro'
import { useEffect, useRef, useState } from 'react'
import canUseDOM from '@/utilities/canUseDOM'
import Link from 'next/link'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import { Copy } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Label } from '@/components/ui/label'
import { useLenis } from 'lenis/react'
import { toast } from 'sonner'

type BaseError = Error
type AppError = BaseError & { cause: { app: string } }
type UnknownError = BaseError & { cause: 'unknown' | string }
export type ErrorState = BaseError | AppError | UnknownError

export const EscapeInAppBrowser = (
  props: { targetURL: string } = { targetURL: process.env.NEXT_PUBLIC_SERVER_URL },
) => {
  const [open, setOpen] = useState(false)
  const lenis = useLenis()
  const { device, os, browser } = getDeviceInfo()
  const { targetURL } = props
  const hrefString = useRef<string>(null!)
  const errorMessage = useRef<ErrorState>(null!)
  if (!browser.inApp) return <></>
  if (!os.ios && !os.android) {
    if (device.type !== 'mobile' && device.type !== 'tablet') {
      return <></>
    }
  }
  useEffect(() => {
    if (os.android) {
      try {
        hrefString.current = escapeAndroidInApp(targetURL)
      } catch (e) {
        console.log(e)
        //some method for displaying error & possibly suggesting the site be opened in browser

        errorMessage.current =
          'cause' in e
            ? (e as ErrorState)
            : (new Error('Unknown Error: Original Error Message is' + e, {
                cause: 'unknown',
              }) as ErrorState)
      }
    } else if (os.ios) {
      try {
        hrefString.current = escapeIOSinApp(targetURL)
      } catch (e) {
        console.log(e)
        //some method for displaying error & possibly suggesting the site be opened in browser
        errorMessage.current =
          'cause' in e
            ? (e as ErrorState)
            : (new Error('Unknown Error: Original Error Message is' + e, {
                cause: 'unknown',
              }) as ErrorState)
      }
    }
  }, [])

  useEffect(() => {
    lenis?.[open ? 'stop' : 'start']()
  }, [open])
  useEffect(() => {
    if (hrefString.current && canUseDOM) {
    }
    setOpen(true)
  }, [])
  const user = useRPStore((l) => l.user)
  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogContent className="overflow-hidden p-10 shadow-lg">
        <DialogHeader>
          <DialogTitle className="text-left text-background">Excuse Us...</DialogTitle>
          <DialogDescription className="pr-3 py-5 text-xl font-medium text-[oklch(var(--bg)/.8)] leading-[1.5] text-left text-pretty">
            Welcome to The Hideaway{user && `, ${user.name}`}!<br />
            Unfortunately, The Hideaway does not work inside {browser.name}.<br />
            {(hrefString.current && (
              <>Please click the button below to open the site in your browser : </>
            )) || (
              <>
                Please copy & paste the link below into the address bar of your browser- see you
                there!
              </>
            )}
          </DialogDescription>
        </DialogHeader>
        {hrefString.current && (
          <Link href={hrefString.current} target="_blank">
            Click To Open In Browser
          </Link>
        )}
        <div className="flex items-center space-x-2">
          <div className="grid flex-1 gap-2">
            <Label htmlFor="link" className="sr-only">
              Link
            </Label>

            <input
              id="link"
              defaultValue={targetURL}
              readOnly
              style={{
                color: 'oklch(var(--bg)/.8)',
                border: '1px solid oklch(var(--border-subtle))',
                borderRadius: ' 4px',
                backgroundColor: 'oklch(var(--off-white)/.3)',
              }}
            />
          </div>
          <Button
            type="button"
            onClick={() => {
              try {
                navigator.clipboard.writeText(targetURL).then(() => {
                  toast('Great', { description: 'Copied to clipboard!' })
                })
              } catch (e) {}
            }}
            size="sm"
            className="p-[4px] h-[24px] w-[24px] flex rounded-[6px] text-[oklch(var(--fg)/.5)] bg-[oklch(var(--bg)/.5)] border-[1px] border-[oklch(var(--border-subtle))]"
          >
            <span className="sr-only">Copy</span>
            <Copy />
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  )
}
const escapeIOSinApp = (turl: string) => {
  if (turl.startsWith('http://'))
    throw new Error(
      'IOS Safari scheme does not support http:// protocol. Please use https:// instead.',
    )
  const targetURL = turl.startsWith('https://') ? turl : `https://${turl}`
  const {
    browser: { name: browserName },
  } = getDeviceInfo()
  switch (browserName) {
    case 'threads':
    case 'twitter':
    case 'telegram':
    case 'facebook':
    case 'instagram':
    case 'linkedin':
    case 'tiktok':
    case 'messenger':
    case 'gsa':
      return 'x-safari-' + targetURL
    case 'KakaoTalk':
      return 'kakaotalk://web/openExternal?url=' + encodeURIComponent(targetURL)
    case 'line':
      return targetURL + (targetURL.indexOf('?') !== -1 ? '&' : '?') + 'openExternalBrowser=1'
    default:
      throw new Error('Unsupported app', { cause: { app: browserName } })
  }
}
const escapeAndroidInApp = (targetURL: string) => {
  const {
    browser: { name: browserName },
  } = getDeviceInfo()
  switch (browserName) {
    case 'facebook':
    case 'instagram':
    case 'messenger':
    case 'threads':
    case 'telegram':
      return `intent://${targetURL.replace(/https?:\/\//i, '')}#Intent;scheme=https;end`
    case 'KakaoTalk':
      return 'kakaotalk://web/openExternal?url=' + encodeURIComponent(targetURL)
    case 'line':
      return targetURL + (targetURL.indexOf('?') !== -1 ? '&' : '?') + 'openExternalBrowser=1'
    default:
      throw new Error('Unsupported app', { cause: { app: browserName } })
  }
}
