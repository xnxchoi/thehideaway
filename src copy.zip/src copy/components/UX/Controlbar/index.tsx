import '@/styles/executor.scss'
import { FloatWrapper } from '@/components/UX/Controlbar/FloatWrapper'

export const Controlbar = () => {
  return (<>
      <div className="float-section" style={{
        translate: 'none', rotate: 'none', scale: 'none', transform: 'translate(0px, 0px)',
      }}>
        <div className="menu-float__inner">
          <FloatWrapper />
        </div>
      </div>
    </>)
}
