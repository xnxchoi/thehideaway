import { useLenis } from 'lenis/react'
import { useRPStore } from '@/providers/RP_Pro'
import { useEffect } from 'react'
import { cn } from '@/lib/utils'

export const CBBackdrop = () => {
  const lenis = useLenis()
  const cbOpen = useRPStore((state) => state.cbMenu)
  const closeCB = useRPStore((state) => state.setCBmenu)

  useEffect(() => {
    cbOpen ? lenis?.stop() : lenis?.start()
  }, [lenis, cbOpen])
  return (
    <div
      onClick={() => closeCB(false)}
      className={cn('menu-float__search-backdrop', { 'is-active': cbOpen })}
    />
  )
}
