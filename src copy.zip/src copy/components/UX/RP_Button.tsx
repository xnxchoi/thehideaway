"use client"

import React, { useState } from "react"

import { cn } from "@/lib/utils"

export default function RP_Button(children: any, size = "small", classes: any[], ...props: any[]) {
  const [isHovered, setHover] = useState(false)
  const [isActive, setActive] = useState(false)
  const args = [
    "rp_btn",
    { bt_sm: size === "small" },
    { bt_lg: size === "large" },
    { hover: isHovered },
    { active: isActive },
  ]
  return (
    <button
      id="primary__nav"
      className={cn(...args, ...classes)}
      data-themed="border-color,background-color"
      aria-label="Open the main navigation menu"
      {...props}
      onMouseEnter={() => setHover(true)}
    >
      {children}
    </button>
  )
}
