'use client'

import type { SVGAttributes } from 'react'
import { forwardRef } from 'react'

type PathProp = SVGAttributes<SVGPathElement> & {
  'data-themed'?: string
}

export type SVGIcoProps = Partial<SVGAttributes<SVGSVGElement>> & {
  paths: Array<PathProp | string | [string, Omit<PathProp, 'd'>]>
}

export const SvgIco = forwardRef<SVGSVGElement, SVGIcoProps>(function (props: SVGIcoProps, ref) {
  const { paths, width, height, viewBox, ...rest } = props
  const w = width ?? 22
  const h = height ?? 22
  const dim = {
    width: w,
    height: h,
  }
  return (
    <svg
      xmlns="http://www.w3.org/2000/svg"
      width={dim.width}
      height={dim.height}
      viewBox={viewBox}
      ref={ref}
      {...rest}
    >
      {paths.map((path, index: number) => {
        if (typeof path === 'string') {
          return <path key={index} d={path} />
        }
        if (typeof path === 'object') {
          if (path instanceof Array) {
            return <path key={index} {...path[1]} d={path[0]} />
          } else {
            return <path key={index} {...path} />
          }
        }
      })}
    </svg>
  )
})
