'use client'

import gsap from 'gsap'
import { useLenis } from 'lenis/react'
import { DateTime } from 'luxon'
import { RefObject, SVGAttributes, useCallback, useEffect, useRef, useState } from 'react'
import { getDeviceInfo, useCursorStore, useRPStore } from '@/providers/RP_Pro'
import { getUrlFromPageData, typeSlugFromLink } from '@/utilities/Helpers'
import { useWindowResize } from '@/utilities/use_window_resize'
import { cn } from '@/lib/utils'
import { ReferencedLink } from '@/components/UX/Link/referencedLink'
import { useIsMobile } from '@/utilities/getBreakpoints'
import { useRouter } from 'next/navigation'
import { SvgIco } from '@/components/UX/svgIco'
import { useVoyageur } from '@/stores/RP_Voyageur'
import { Link } from '@/components/UX/Link'
import { Button } from '@/components/ui/button'
import { getServerSideURL } from '@/utilities/getURL'
import { getPayload } from 'payload'
import configPromise from '@payload-config'
import { canUseDOM } from '@/utilities/canUseDOM'
const B = 'navWindow'
export const getNavId = () => B
export const getNavOpeningElement = () => document.getElementById(getNavId())

export const getNavigationHeightRatio = (): number => getNavOpeningHeight() / window.innerHeight
export const getNavOpeningHeight = () => {
  const l = getNavOpeningElement()
  if (l) {
    return l.offsetHeight
  }
  return 0
}

export const RP_Menu = () => {
  const H = 590
  const router = useRouter()
  const lenis = useLenis()
  const { isMobile } = useIsMobile()
  const { os, device, browser } = getDeviceInfo()
  const frames = ['top', 'right', 'bottom', 'left']
  const corners = ['tl', 'tr', 'br', 'bl']
  const pageType = useVoyageur((l) => l.pageType)
  const pageSlug = useVoyageur((l) => l.slug)
  const [focusedIndex, setFocusedIndex] = useState<string | -1>(-1), focusedRef = useRef<-1 | string>(-1),
    activeRef = useRef<string | -1>(-1), [activeIndex, setActiveIndex] = useState<string | -1>(-1)

  /**
   * Ref Objects for Navigation Items
   *
   */
  const navigationList = useRef<HTMLUListElement>(null!)
  const navItems = useRef<HTMLLIElement[]>([])
  const navLines = useRef<HTMLSpanElement[]>([])
  const navButtons = useRef<HTMLAnchorElement[]>([])
  const navWindow = useRef<HTMLDivElement>(null!)
  /**
   *  Menu Frame ref Objects
   */
  const menuFrames: RefObject<Array<HTMLDivElement>> = useRef([])
  const menuCorners: RefObject<Array<HTMLDivElement>> = useRef([])
  const menuSVgs: RefObject<Array<HTMLDivElement>> = useRef([])

  /**
   * Cursor Functions
   */
  const setCursorTheme = useCursorStore((l) => l.setCursorTheme)[0]
  const resetCursorTheme = useCursorStore((l) => l.resetCursorTheme)[0]
  /**
   *  Transition / UI Functions
   */
  const theme = useRPStore((l) => l.theme)
  const setCanInteract = useRPStore((store) => store.setCanInteract)
  const setTransitionOutType = useRPStore((store) => store.setTransitionOutType)
  const setNavigationPageIsTransitioning = useRPStore((store) => store.setNavigationPageIsTransitioning)
  const navIsOpen = useRPStore((l) => l.navIsOpen)
  const setNavIsTransitioning = useRPStore((l) => l.setNavIsTransitioning)
  const setNavIsOpen = useRPStore((l) => l.setNavIsOpen)
  const navigationSettings = useRPStore((l) => l.globalSettings.navigation)
  const setNavIsOpenDebounced = useRPStore((l) => l.setNavIsOpenDebounced)
  const menuPageItemKeys = useRPStore((l) => l.navigationPageItemKeys)
  const lastAdjustRealTime = useRef(DateTime.now().year)
  const currentPageKey = useVoyageur((l) => l.pageKey)
  const mapped = useRef<{ [x: string]: number }>({})
  const setNavItemHovered = useRPStore((l) => l.setNavigationPageItemHovered)
  const setNavItemSelected = useRPStore((l) => l.setNavigationPageItemSelected)
  const focusedTO = useRef<ReturnType<typeof setTimeout>>(null!)
  useEffect(() => {
    menuPageItemKeys.forEach((l, i) => {
      mapped.current[l] = i
    })
  }, [])
  const handlePagePreviewMouseEnter = (pagekey: string | -1) => {
    currentPageKey !== pagekey && setFocusedIndex(pagekey)
  }
  const handlePagePreviewMouseLeave = () => {
    setFocusedIndex(-1)
  }
  const serverurl = getServerSideURL()

  useEffect(() => {
    setNavItemHovered(focusedIndex)
  }, [focusedIndex])
  const hoveredNavItem = useRPStore((l) => l.navigationPageItemHovered)
  const activeNavItem = useRPStore((l) => l.navigationPageItemSelected)
  const activeTO = useRef<ReturnType<typeof setTimeout>>(null!)
  useEffect(() => {
    if (hoveredNavItem === -1) {
      {
        activeTO.current && clearTimeout(activeTO.current)
        activeTO.current = setTimeout(() => {
          setActiveIndex(currentPageKey)
        }, 450)
      }
    }
  }, [hoveredNavItem])
  const menuToPageCallback = useCallback((pagekey: string) => {
    setTransitionOutType('MENU_TO_PAGE'), setNavItemSelected(pagekey), setNavigationPageIsTransitioning(true), setCanInteract(false)
    setTimeout(() => {
      setCanInteract(true)
      // setNavIsOpen(!1)
    }, 1e3 * 0.7)
  }, [setCanInteract, setNavIsOpen, setNavigationPageIsTransitioning, setActiveIndex, setTransitionOutType])
  const handlePagePreviewClick = (pageKey: string) => {
    isMobile ? (handlePagePreviewMouseEnter(pageKey), setTimeout(() => {
      menuToPageCallback(pageKey)
    }, 300)) : menuToPageCallback(pageKey)
  }, er = useRef(null), resizeTime = useWindowResize(), lastResize = useRef(0)
  const focusResetTO = useRef<ReturnType<typeof setTimeout>>(null!)
  const isHome = useVoyageur((l) => l.isHome)
  useEffect(() => {
    focusResetTO.current && clearTimeout(focusResetTO.current), (focusResetTO.current = setTimeout(() => {
      setNavIsOpenDebounced(navIsOpen)
    }, 400))
  }, [setNavIsOpenDebounced, navIsOpen])
  const resetFrames = useCallback(() => {
    const l = focusedRef.current !== activeIndex
    const nothingIsActive = activeIndex === -1 && focusedIndex === -1
    const resetElement = (l: gsap.TweenTarget, c: gsap.TweenTarget, d = 0.3) => {
      const dur = 0.3
      gsap.killTweensOf([l, c])
      gsap.to(l, {
        x: '102%', duration: dur,
      })
      gsap.to(c, {
        autoAlpha: d, duration: dur,
      })
    }
    navLines.current.forEach((navLine, h) => {
      if (!navLine) {
        return
      }
      const currentButton = navButtons.current[h]
      if (currentButton) {
        if (l) {
          resetElement(navLine, currentButton, nothingIsActive ? 1 : 0.3)
        }
        if (menuPageItemKeys[h] === focusedIndex || (focusedIndex === -1 && menuPageItemKeys[h] === activeIndex)) {
          gsap.killTweensOf([navLine, currentButton])
          gsap.fromTo(navLine, {
            x: '-102%',
          }, {
            x: 0, duration: 0.6, ease: 'Power3.easeOut',
          })
          gsap.to(currentButton, {
            autoAlpha: 1, duration: 0.6, ease: 'Power3.easeOut',
          })
        } else if (menuPageItemKeys[h] === activeRef.current || (focusedIndex !== -1 && menuPageItemKeys[h] === activeIndex) || activeIndex === -1) {
          resetElement(navLine, currentButton)
        }
        if (nothingIsActive) {
          gsap.killTweensOf([navLine, currentButton])
          resetElement(navLine, currentButton, 1)
        }
      }
    })
    activeRef.current = focusedIndex
    focusedRef.current = activeIndex
  }, [focusedIndex, activeIndex])

  useEffect(() => {
    setActiveIndex(-1);
    (isHome && window.innerHeight > H && !isMobile) || navItems.current.forEach((el, ind) => {
      if (el && el.dataset.isActive == 'true') {
        setTimeout(() => {
          setActiveIndex(menuPageItemKeys[ind])
        }, 400)
      }
    })
  }, [isHome, lastResize, isMobile])

  const toggleMenuCallback = useCallback((isNavOpen: boolean, needsResizing: boolean) => {
    if (!er.current || !navWindow.current) {
      return
    }
    setNavIsTransitioning(!0)
    const navWClient = (navWindow.current as HTMLElement).getBoundingClientRect()
    const windowHeight = (navWindow.current as HTMLElement).offsetHeight
    const windowXOff = navWClient.left
    const windowYOff = navWClient.top
    gsap.killTweensOf([...menuFrames.current, ...menuCorners.current, ...menuSVgs.current, ...navItems.current, er.current])
    menuFrames.current.forEach((frame, ind) => {
      let xOff: string | number = 0
      let yOff: string | number = 0
      if (!isNavOpen) {
        switch (ind) {
          case 0:
            yOff = -frame.offsetHeight + 10
            break
          case 1:
            xOff = frame.offsetWidth - 10
            break
          case 2:
            // yOff = isMobile && os.name === 'android' ? frame.offsetHeight : '100%'
            yOff = isMobile && os.name === 'android' ? frame.offsetHeight : frame.offsetHeight - 20
            break
          case 3:
            xOff = -frame.offsetWidth + 10
        }
      }
      gsap.to(frame, {
        x: xOff,
        y: yOff,
        autoAlpha: 1,
        duration: isNavOpen ? 1.2 : 1.2,
        ease: isNavOpen ? 'Power4.easeInOut' : 'Power3.easeInOut',
      })
    })
    menuCorners.current.forEach((corner, indx) => {
      let xoffse = 0
      let yoffse = 0
      if (!isNavOpen && isMobile && os.name === 'android') {
        const l = menuFrames.current[2]
        const c = (l == null ? undefined : l.offsetHeight) || 0
        switch (indx) {
          case 2:
          case 3:
            yoffse = c - c / 1.5
        }
      }
      switch (indx) {
        case 0:
          if (isNavOpen) {
            yoffse = windowYOff
            xoffse = windowXOff
          } else {
            yoffse = 10
            xoffse = 10
          }
          break
        case 1:
          if (isNavOpen) {
            yoffse = windowYOff
            xoffse = -windowXOff
          } else {
            yoffse = 10
            xoffse = -10
          }
          break
        case 2:
          if (isNavOpen) {
            xoffse = -windowXOff
            yoffse = isMobile ? -((window.innerHeight - (windowHeight + windowYOff)) * 1) + 1 : -windowYOff
          } else {
            xoffse = -11
            yoffse = -20
          }
          break
        case 3:
          if (isNavOpen) {
            xoffse = windowXOff
            yoffse = isMobile ? -((window.innerHeight - (windowHeight + windowYOff)) * 1) + 1 : -windowYOff
          } else {
            xoffse = 10
            yoffse = -20
          }
      }

      gsap.to(corner, {
        x: xoffse,
        y: yoffse,
        duration: isNavOpen ? 1.2 : 1.2,
        ease: isNavOpen ? 'Power4.easeInOut' : 'Power3.easeInOut',
      })
    })
    menuSVgs.current.forEach((svg) => {
      if (svg) {
        const m = {
          scale: 1, duration: isNavOpen ? 1.2 : 1.2, ease: isNavOpen ? 'Power4.easeInOut' : 'Power3.easeInOut',
        }
        needsResizing ? gsap.set(svg, m) : gsap.to(svg, m)
      }
    })
    const startLoc = isMobile ? 0 : -150
    const moveTargets = [navigationList.current]

    gsap.killTweensOf(moveTargets)
    gsap[needsResizing ? 'set' : 'to'](moveTargets, {
      x: isNavOpen ? 0 : startLoc,
      autoAlpha: isNavOpen ? 1 : 0,
      delay: isNavOpen ? 0.5 : 0,
      duration: isNavOpen ? 1.2 : 1.2 * 0.75,
      ease: 'Power3.easeOut',
    })
    gsap[needsResizing ? 'set' : 'to'](er.current, {
      autoAlpha: isNavOpen ? 1 : 0, delay: isNavOpen ? 0.5 : 0, duration: isNavOpen ? 1.2 : 1.2, onComplete: () => {
        setNavIsTransitioning(false)
      },
    })
  }, [isMobile, navigationList, setNavIsTransitioning, os.name])

  useEffect(() => {
    setActiveIndex(-1), (isHome && window.innerHeight > H && !isMobile) || navItems.current.forEach((l, c) => {
      l && 'true' === l.dataset.isActive && setTimeout(() => {
        setActiveIndex(menuPageItemKeys[c])
      }, 400)
    })
  }, [setActiveIndex, currentPageKey, isHome, resizeTime, isMobile])

  useEffect(() => {
    resetFrames()
  }, [resetFrames])
  useEffect(() => {
    lenis && lenis[navIsOpen ? 'stop' : 'start'](), toggleMenuCallback(navIsOpen, lastResize.current !== resizeTime), (lastResize.current = resizeTime), navIsOpen || setFocusedIndex(-1)
  }, [toggleMenuCallback, navIsOpen, resizeTime, lenis])
  useEffect(() => {
    if (canUseDOM) document.body.classList[navIsOpen ? 'add' : 'remove']('menu__open')
  }, [navIsOpen])
  return (<div className={cn('menu__body', { menu__open: navIsOpen })}>
    <div className="menu__window-pos" ref={navWindow} onMouseEnter={() => setCursorTheme('dark')}
         onMouseLeave={() => setCursorTheme(theme === 'dark' ? 'light' : 'dark')} onClick={() => {
      setNavIsOpen(false)
      resetCursorTheme()
    }} id={B} />
    <nav className="menu__navigation">
      <ul className="menu__nav-items-list scroll__items" ref={navigationList} onMouseLeave={() => {
      }}>
        {navigationSettings.navItems.map((l, index) => {
          let { type, slug } = typeSlugFromLink(l)
          let theKey = menuPageItemKeys[index]
          let href = getUrlFromPageData(type, slug)
          return (<li className="menu__nav-item" key={index + 'nav_item'} ref={(el) => {
            el && (navItems.current[index] = el)
          }} data-is-active={currentPageKey === theKey} data-themed="color" style={{}}>
            <ReferencedLink ref={(el: HTMLAnchorElement) => {
              el && (navButtons.current[index] = el)
            }} key={index + '-' + theKey} className={'button__scroll lift__button'} link={l.link} href={href}
                            onMouseEnter={() => handlePagePreviewMouseEnter(theKey)}
                            onMouseLeave={() => isMobile || handlePagePreviewMouseLeave()} onClick={async () => {
              handlePagePreviewClick(theKey)
            }}>
              {l.link.label}
            </ReferencedLink>
            <span className="menu__item-line-container">
                  <span className="menu__item-line" data-themed="background-color" style={{
                    translate: 'none', rotate: 'none', scale: 'none', transform: 'translate(102%, 0px)',
                  }} ref={(el) => {
                    el && (navLines.current[index] = el)
                  }} />
                </span>
          </li>)
        })}
        <li className="menu__nav-item">
          <Link className={"button__scroll lift__button"} href={'/dev'}>DEV</Link>
        </li>
        <li className="menu__nav-item">
          <Button className={"button__scroll lift__button"} type='button' onClick={async() => {
            await fetch(`${serverurl}/api/seed`, {
              method: 'POST', credentials: 'include', headers: {
                'Content-Type': 'application/json',
              },
            }).catch(e => console.error(e))
          }}>SEED</Button>
        </li>

      </ul>
    </nav>
    <div className="menu__noti-scroller">
      <div className="notifications__list" style={{ opacity: 0, visibility: 'hidden' }} />
    </div>
    <p ref={er} className="menu__year" data-themed="color">
      {`\xa9${lastAdjustRealTime.current}`}
    </p>
    <div>
      {frames.map((frame, ind) => {
        return (<div className={cn('menu__frame', `frame-${frame}`)} ref={(el) => {
          if (el) {
            menuFrames.current[ind] = el
          }
        }} data-themed="background-color" key={`${frame + ind}`} />)
      })}
      {corners.map((corner, ind) => {
        return (<div className={cn(['menu__frame-corner', `corner-${corner}`])} ref={(el) => {
          if (el) {
            menuCorners.current[ind] = el
          }
        }} key={corner + 'frame'}>
          <div className="menu__corner-svg" ref={(el) => {
            if (el) {
              menuSVgs.current[ind] = el
            }
          }} style={{
            width: `${isMobile ? 22 : 27}px`,
            height: `${isMobile ? 22 : 27}px`,
            translate: 'none',
            rotate: 'none',
            scale: 'none',
            transform: 'translate(0px, 0px)',
          }}>
            <CornerStone side={corner} />
          </div>
        </div>)
      })}
    </div>
  </div>)
}
const Corner = {
  mobile: {
    tr: 'M.07.01c50.62,2.79,51.7,3.82,56.01,56.12,0-.45,0-3.7,0-8.44,0-13.09.02-35.5-.01-47.69C40.43,0,14.98,0,0,0h.07Z',
    tl: 'M56.07,0C41.09,0,15.65,0,.01,0,0,12.23,0,34.57,0,47.69c0,4.74,0,8,0,8.44C.92,3.75,2.1,2.82,56,.01h.07Z',
    br: 'M0,56.13c14.99,0,40.42.01,56.06,0,.02-12.23.01-34.56.01-47.69,0-4.74,0-8,0-8.44C53.76,52.46,52.63,53.43.07,56.12h-.07Z',
    bl: 'M0,0c.02,10.34-.01,29.22,0,40.94,0,8.72,0,15.31,0,15.18,2.85.03,7.55-.02,15.18,0,10.22,0,22.94,0,32.7,0,4.69,0,7.88,0,8.24,0,0,0,.05,0,0,0h-.3c-35.4-1.47-50.86,1.97-54.23-24.43C.39,22.32.28,10.22,0,.06v-.06Z',
  }, desktop: {
    tr: 'M0,0q25.73,1.58,28.07,28.07V0H0Z',
    bl: 'M0,0v28.07h28.07Q.65,27.54,0,0Z',
    br: 'M0,28.07h28.07V0Q26.73,26.54,0,28.07Z',
    tl: 'M28.07,0H0v28.07Q.65,1.58,28.07,0Z',
  },
}
const CornerStone = (props: { side: string } & SVGAttributes<SVGPathElement>) => {
  const ref = useRef<SVGSVGElement>(null)
  const { side, ...rest } = props
  const { isMobile } = useIsMobile()

  const dimes = {
    mobile: 56.15, desktop: 28.07,
  }
  const sides = ['t', 'b'].flatMap((side) => {
    return ['r', 'l'].flatMap((suf) => {
      return `${side}${suf}`
    })
  })
  const [de, setDe] = useState<string>('')
  useEffect(() => {
    setDe(Corner[isMobile ? 'mobile' : 'desktop'][side])
  }, [])

  useEffect(() => {
    gsap.to(`#cs_${side}`, {
      autoAlpha: 0, duration: 0.4, onComplete: () => setDe(Corner[isMobile ? 'mobile' : 'desktop'][side]),
    })
    gsap.to(`#cs_${side}`, {
      delay: 0.5, duration: 0.4, autoAlpha: 1,
    })
  }, [isMobile])
  return (<>
    <SvgIco ref={ref} id={`cs_${side}`}
            viewBox={`0 0 ${dimes[isMobile ? 'mobile' : 'desktop']} ${dimes[isMobile ? 'mobile' : 'desktop']}`} style={{
      width: isMobile ? '2.2rem' : '27px', height: isMobile ? '2.2rem' : '27px', display: 'block',
    }} paths={[{
      d: de, 'data-themed': 'fill,color', clipRule: 'evenodd', fillRule: 'evenodd', ...rest,
    }]} />
  </>)
}
