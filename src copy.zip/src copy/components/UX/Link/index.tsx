'use client'

import { useLenis } from 'lenis/react'
import NextLink, { type LinkProps as NextLinkProps } from 'next/link'
import React, { ComponentPropsWithoutRef, RefAttributes, useEffect, useMemo, useState } from 'react'
import { cn } from '@/lib/utils'
import gsap from 'gsap'
import { useCursorStore, useRPStore } from '../../../providers/RP_Pro'
import { useIsMobile } from '@/utilities/getBreakpoints'
import { isInternalLink } from '@/utilities/isInternalLink'
import { useVoyageur } from '@/stores/RP_Voyageur'
import { delay } from '@/utilities/rp_utils'
import { useRouter } from 'next/navigation'
import { Member, Page, Post, Surf } from '@/payload-types'
import { useCursorHandlers } from '@/components/core/cursorWrapper'

export type PayloadLinkProps = {
  type: 'reference' | 'custom'
  newTab: boolean
  reference?: {
    relationTo: 'pages' | 'members' | 'posts' | 'surf'
    value: number | Page | Member | Post | Surf
  } | null
  url?: string | null
  label: string
  appearance?: 'default' | 'outline' | null
}
type AllowedTags = HTMLAnchorElement | HTMLSpanElement | HTMLDivElement
export type RPLinkProps =
  Omit<ComponentPropsWithoutRef<'a'>, 'onMouseEnter' | 'onClick' | 'onMouseLeave'>
  & Omit<NextLinkProps, 'onMouseEnter' | 'onClick' | 'onMouseLeave'>
  & {
  onMouseLeave?: () => void
  onMouseEnter?: () => void
  onClick?: () => void
}
export type RPButtonProps = Omit<ComponentPropsWithoutRef<'button'>, 'onMouseEnter' | 'onClick' | 'onMouseLeave'> & {
  onMouseLeave?: () => void
  onMouseEnter?: () => void
  onClick?: () => void
}
export type RPLinkPropsWithRef =
  RPLinkProps
  & (| RefAttributes<HTMLAnchorElement> | RefAttributes<HTMLDivElement> | RefAttributes<HTMLButtonElement>)

const RP_Link = (props: RPLinkPropsWithRef) => {
  const { href, onClick, onMouseLeave: doML, onMouseEnter: doME, ref, ...rest } = props
  const lenis = useLenis() // eslint-disable-line
  const handler = useCursorHandlers('dom', { onEnter: doME, onLeave: doML })
  const { onMouseEnter, onMouseLeave } = handler
  const currentPath = useVoyageur((r) => r.pathName)
  const rout = useRouter()

  if (!href || typeof href !== 'string') {
    return <div>{props.children}</div>
  }
  const isAnchor = href.startsWith('#') || href.startsWith(`${currentPath}#`)
  const setPageIsTransitioning = useRPStore((l) => l.setPageIsTransitioning)
  const [propsToPass, setPropsToPass] = useState<Partial<RPLinkProps>>({
    ...rest,
  })

  const [isExternal, setIsExternal] = useState(false)
  useEffect(() => {
    setIsExternal(isInternalLink(href))
  }, [href])
  useEffect(() => {
    if (isExternal) {
      setPropsToPass((tp) => ({
        ...tp, target: '_blank', rel: 'noreferrer',
      }))
    } else {
      setPropsToPass((tp) => (delete tp.target, delete tp.rel, tp))
    }
  }, [isExternal])

  return (<NextLink className={cn({
    link_hashLink: isAnchor,
  }, {
    link_inactive: !isAnchor && currentPath === href,
  }, props?.className)} href={href} onClick={(e) => {
    e.preventDefault()
    if (isAnchor) {
      ;(lenis && lenis.scrollTo(href)) || window.scrollTo({ top: 0, behavior: 'smooth' })
    } else {
      gsap.to('.rp-container .page', {
        duration: 0.2, opacity: 0,
      })
      setPageIsTransitioning(true)
      delay(40).then(() => {
        rout.push(href)
      })
    }
  }} ref={ref as RefAttributes<HTMLAnchorElement>['ref']}
                    {...propsToPass} onMouseEnter={onMouseEnter} onMouseLeave={onMouseLeave} />)
}
export const RP_Btn = (props: RPButtonProps & RefAttributes<HTMLButtonElement>) => {
  const { onClick, onMouseLeave: doML, onMouseEnter: doME, ref, ...rest } = props
  const handler = useCursorHandlers('dom', { onEnter: doME, onLeave: doML })
  const { onMouseEnter, onMouseLeave } = handler
  const [propsToPass, setPropsToPass] = useState<Partial<RPButtonProps>>({
    ...rest,
  })


  return (<button className={cn(props?.className)} ref={ref as RefAttributes<HTMLButtonElement>['ref']}
                  {...propsToPass} onMouseEnter={onMouseEnter} onMouseLeave={onMouseLeave} />)
}

export function Link(props: RPLinkPropsWithRef) {
  return RP_Link(props)
}
