'use client'
import {
  Command as Commands,
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
  CommandSeparator,
} from '@/components/ui/command'
import React, { ComponentPropsWithoutRef, ReactNode, RefObject, useCallback, useEffect, useRef, useState } from 'react'
import { LinkedCommandItem, LinkedItem } from '@/components/UX/CommandKey/Commando'
import { DialogTitle } from '@/components/ui/dialog'
import { getDeviceInfo, useCursorStore, useRPStore, useSearchBar } from '@/providers/RP_Pro'
import '@/(CMS)/search/__searchBar.scss'
import { Command as CommandPrimitive, Command, CommandLoading } from 'cmdk'
import * as Popover from '@radix-ui/react-popover'
import { useIsMobile } from '@/utilities/getBreakpoints'
import { useLenis } from 'lenis/react'
import { isInternalLink } from '@/utilities/isInternalLink'
import { useVoyageur } from '@/stores/RP_Voyageur'
import { SvgIco } from '@/components/UX/svgIco'
import { RPTooltip } from '@/components/UX/tooltip'
import { cn } from '@/lib/utils'
import gsap from 'gsap'
import { delay } from '@/utilities/rp_utils'
import { router } from 'next/client'
import { Button } from '@/components/ui/button'
import { useTheme } from '@/providers/Theme'

import { useDebounce } from '@/utilities/useDebounce'
import { CreditCard, SearchIcon, Settings, User } from 'lucide-react'
import { useCursorHandlers } from '@/components/core/cursorWrapper'

export const SearchBar = () => {
  const navIsOpen = useRPStore((store) => store.navIsOpen)
  const setValue = useSearchBar((l) => l.setValue)
  const value = useSearchBar((l) => l.value)
  const toggleTheme = useTheme(store => store.toggleTheme)
  const theme = useTheme(store => store.theme)
  const open = useSearchBar((l) => l.open)
  const setOpen = useSearchBar((l) => l.setOpen)
  const toggleOpen = useSearchBar((l) => l.toggleOpen)
  const toggle = useRef<HTMLButtonElement>(null!)
  const inputRef = useRef<HTMLInputElement>(null!)
  const listRef = useRef<HTMLUListElement>(null!)
  const setNav = useRPStore((store) => store.setNavIsOpen)
  const user = useRPStore((store) => store.user)
  const [loading, setLoading] = useState<boolean>(false)
  const [items, setItems] = useState<{
    categories: any[]
    createdAt: string
    doc: { relationTo: string; value: string }
    id: string
    meta: {
      description: string
      image: {
        id: string
        alt: string
        caption: { [x: string]: any }
        filename: string
        mimeType: string
      }
      title: string
    }
    slug: string
    title: string
    updatedAt: string
  }[]>([])
  const [init, setInit] = useState(true)
  const debouncedValue = useDebounce(value)
  useEffect(() => {
    async function load() {
      if (open && debouncedValue.length > 0) {
        setLoading(true)
        setInit(false)
        const ite = await fetch('/api/search/?q=' + encodeURIComponent(debouncedValue), {
          method: 'GET',
        })
        if (ite.ok) {
          let a = await ite.json()
          if (a.docs && a.docs.length > 0) {
            setItems(a.docs.map((doc) => doc))
          } else {
            setItems([])
          }
        } else {
          setItems([])
        }
        setLoading(false)
      } else {
        setItems([])
        setInit(true)
        setLoading(false)
      }
    }

    load()
  }, [debouncedValue])


  const handleClick = useCallback(() => {
    toggleOpen()
  }, [toggleOpen])
  useEffect(() => {
    if (open) {
      setNav(false)
      inputRef?.current?.focus()
    }
  }, [open])

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.metaKey || e.ctrlKey) {
        switch (e.key) {
          case 'k':
            return(e.preventDefault(), toggleOpen())
          case 'h':
            return (e.preventDefault(),toggleTheme())
        }
      }
    }
    document.addEventListener('keydown', down)
    return () => document.removeEventListener('keydown', down)
  }, [])

  return (<>
    <Button type="button" ref={toggle} className={cn('rp_btn bt_sm has-tooltip', {
      hover: navIsOpen,
    })} onClick={handleClick} data-themed={'color,background-color,fill'} aria-controls="h-dropdown"
            aria-label="Toggle Menu">
      <SvgIco viewBox="0 0 24 24" className="fill-[oklch(var(--n-s-btn)/.9)]" data-themed={'fill'} width="12"
              height="12"
              paths={['M17.908 14.755c3.918 0 6.092 1.654 6.092 4.745 0 2.755-1.745 4.5-4.5 4.5-3.092 0-4.745-2.173-4.745-6.092v-1.806h-5.51v1.806C9.245 21.826 7.592 24 4.5 24 1.745 24 0 22.255 0 19.5c0-3.092 2.173-4.745 6.092-4.745h1.806v-5.51H6.092C2.173 9.245 0 7.592 0 4.5 0 1.745 1.745 0 4.5 0c3.092 0 4.745 2.173 4.745 6.092v1.806h5.51V6.092C14.755 2.174 16.408 0 19.5 0 22.255 0 24 1.745 24 4.5c0 3.092-2.173 4.745-6.092 4.745h-1.806v5.51zM7.898 7.898V6.092c0-3.215-1.132-4.745-3.398-4.745-2.02 0-3.153 1.133-3.153 3.153 0 2.265 1.531 3.398 4.745 3.398zm0 8.204H6.092c-3.214 0-4.745 1.132-4.745 3.398 0 2.021 1.133 3.153 3.153 3.153 2.265 0 3.398-1.531 3.398-4.745zm1.347-1.347h5.51v-5.51h-5.51zm6.857-6.857h1.806c3.214 0 4.745-1.132 4.745-3.398 0-2.02-1.132-3.153-3.153-3.153-2.265 0-3.398 1.531-3.398 4.745zM22.653 19.5c0-2.265-1.531-3.398-4.745-3.398h-1.806v1.806c0 3.215 1.133 4.745 3.398 4.745 2.02 0 3.153-1.132 3.153-3.153', {
                'data-themed': 'fill',
              }]} />
      <RPTooltip className="top" label={'⌘ + K'} />
    </Button>
    <CommandDialog open={open} onOpenChange={setOpen} key={'commando-dialog'}>
      <DialogTitle></DialogTitle>
      <div className={cn('relative flex p-[8px] items-center w-full z-1',loading)} cmdk-rp-courier={''} data-slot="command-input-wrapper">
        <SearchIcon className="mr-2 size-4 shrink-0 text-[oklch(var(--bg)/1)]" data-themed={'color, stroke'} />
        <CommandPrimitive.Input data-slot="command-input"
                                className={'flex text-sm h-11 w-full rounded-md bg-transparent py-3 outline-hidden disabled:cursor-not-allowed disabled:opacity-50 placeholder:text-[oklch(var(--bg)/1)]'}
                                data-themed={'color, background-color'} onValueChange={setValue}
                                placeholder="Search for anything (we have)..." />
      </div>
      <CommandList>
       <CommandGroup heading="Search Results">

          {items.map((doc) => (<LinkedItem key={doc.id + 'command_doc'} {...doc}></LinkedItem>))}
          {!loading && items.length === 0 && <CommandEmpty>Nothing found :(</CommandEmpty>}
        </CommandGroup>
        <CommandSeparator />
        {user && (<CommandGroup heading="Settings">
          <LinkedCommandItem value="profile" href={`/users/${user.slug}`} title="Profile">
            <User />
          </LinkedCommandItem>
          <CommandItem>
            <CreditCard />
            <span>Billing</span>
          </CommandItem>
          <CommandItem>
            <Settings />
            <span>Settings</span>
          </CommandItem>
        </CommandGroup>)||(<CommandGroup heading="">

        </CommandGroup>)}
      </CommandList>
      <div cmdk-raycast-footer="" className="flex items-center absolute bottom-0 left-0 right-0 p-[8px] w-full bg-[oklch(var(--faded-fg)/.3)] gap-[4px] z-[56]">
        <SubCommand data-themed={'color, background-color'} inputRef={inputRef} listRef={listRef} />
        <CommandItem cmdk-action-trigger=""
                      data-themed={'color, background-color'}>
          To {theme === 'light' ? 'Dark' : 'Light'} Mode
          <kbd>⌘</kbd>
          <kbd>H</kbd>
        </CommandItem>
      </div>
    </CommandDialog>
  </>)
}

function SubCommand({
  inputRef, listRef,
}: {
  inputRef: RefObject<HTMLInputElement | null>
  listRef: RefObject<HTMLElement | null>
}) {
  const value = useSearchBar((l) => l.value)
  const setValue = useSearchBar((l) => l.setValue)
  const { isMobile } = useIsMobile()
  const [open, setOpen] = React.useState(false)
  const setCur = useCursorStore((l) => l.setCursorState)[0]
  const focusCur = () => {
    !isMobile && setCur('FOCUS')
  }
  const nullCur = () => {
    !isMobile && setCur(null)
  }
  useEffect(() => {
    function listener(e: KeyboardEvent) {
      if (e.key === 'i' && e.metaKey) {
        e.preventDefault()
        setOpen((o) => !o)
      }
    }

    document.addEventListener('keydown', listener)

    return () => {
      document.removeEventListener('keydown', listener)
    }
  }, [])

  useEffect(() => {
    if (!listRef.current) return
    const el = listRef.current

    if (open) {
      el.style.overflow = 'hidden'
    } else {
      el.style.overflow = ''
    }
  }, [open, listRef])
  const user = useRPStore((l) => l.user)

  const kv = {
    b: `CV${crypto.randomUUID()}`, u: `Find${crypto.randomUUID()}`, a: `Login${crypto.randomUUID()}`,
  }
  const keys = Object.keys(kv)
  useEffect(() => {
    const dispatcher = (e: KeyboardEvent) => {
      if (e.ctrlKey || e.metaKey) {
        for (const key of keys) {
          if (e.key === key) {
            e.preventDefault()
            setValue(kv[key])
          }
        }
      }
    }
    document.addEventListener('keydown', dispatcher, { capture: true })
    return () => {
      document.removeEventListener('keydown', dispatcher, { capture: true })
    }
  }, [])
  return (<Popover.Root open={open} onOpenChange={setOpen} modal>
    <Popover.Trigger cmdk-raycast-subcommand-trigger="" onClick={() => setOpen(true)} aria-expanded={open}
                     data-themed={'color, background-color'} onMouseEnter={focusCur} onMouseLeave={nullCur}>
      Actions
      <kbd>⌘</kbd>
      <kbd>I</kbd>
    </Popover.Trigger>
    <Popover.Content side="top" align="start" className="commando-submenu" sideOffset={16} alignOffset={0}
                     onCloseAutoFocus={(e) => {
                       e.preventDefault()
                       inputRef?.current?.focus()
                     }}>
      <Commands>
        <CommandList>
          <CommandGroup heading={'Commands'} data-state={open ? 'open' : 'closed'}>
            {user && (<>
              <SubItem link="/me" shortcut="⌘ B">
                My Profile
              </SubItem>
              <SubItem link={`/users/@${user.slug}/cv`} shortcut="⌘ U">
                My CV
              </SubItem>
              <SubItem link={`/users/@${user.slug}/settings`} shortcut="⌘ A">
                Settings
              </SubItem>
            </>)}
          </CommandGroup>
        </CommandList>
        <CommandInput placeholder="Search for actions..." />
      </Commands>
    </Popover.Content>
  </Popover.Root>)
}

function SubItem({
  children, shortcut, link, ...props
}: {
  children: ReactNode
  shortcut: string
  link?: string
} & ComponentPropsWithoutRef<typeof Command.Item>) {

  if (link) {
    return (
      <LinkedSubItem shortcut={shortcut} link={link} children={children}
                     {...props} />)
  }

  return (<CommandItem {...props}>
    {children}
    <div cmdk-raycast-submenu-shortcuts="">
      {shortcut.split(' ').map((key) => {
        return <kbd key={key}>{key}</kbd>
      })}
    </div>
  </CommandItem>)
}

const LinkedSubItem = (props: {
  children: ReactNode; shortcut: string; link: string
} & ComponentPropsWithoutRef<typeof Command.Item>) => {
  const { link, shortcut, children, ...rest } = props
  const href = link
  const setPageIsTransitioning = useRPStore(r => r.setPageIsTransitioning)
  const lenis = useLenis()
  const isExternal = !isInternalLink(href)
  const setOpen = useSearchBar((l) => l.setOpen)
  const url = useVoyageur((l) => l.url)
  const isAnchor = href === url || href.startsWith(`${url}#`)
  const target = shortcut.split(' ')[1].toLowerCase()
  const handleClick = async () => {
    setOpen(false)
    if (isAnchor) {
      ;(lenis && lenis.scrollTo(href)) || window.scrollTo({ top: 0, behavior: 'smooth' })
    } else {
      setPageIsTransitioning(true)
      gsap.to('.rp-container .page', { opacity: 0, duration: 0.2 })
      delay(40).then(() => {
        router.push(href)
      })
    }
  }

  return (<CommandItem value={href} onSelect={handleClick} {...rest}>
    {children}
    <div cmdk-raycast-submenu-shortcuts="">
      {shortcut.split(' ').map((key) => {
        return <kbd key={key}>{key}</kbd>
      })}
    </div>
  </CommandItem>)
}
