'use client'
import { ScrollTrigger } from 'gsap/ScrollTrigger'
import { useLenis } from 'lenis/react'
import { HTMLMotionProps, motion } from 'motion/react'
import { ReactNode, RefObject, useCallback, useEffect, useRef, useState } from 'react'
import gsap from 'gsap'
import { getNavigationHeightRatio, getNavOpeningElement } from '@/components/UX/Menu'
import { useCursorStore, useRPStore } from '@/providers/RP_Pro'
import { useIsMobile } from '@/utilities/getBreakpoints'
import { ArticleSection, PortfolioSection, SectionData, wait } from '@/utilities/Helpers'
import { cn } from '@/lib/utils'
import { useGSAP } from '@gsap/react'
import { SvgIco } from '@/components/UX/svgIco'
import { useVoyageur } from '@/stores/RP_Voyageur'
import { canUseDOM } from '@/utilities/canUseDOM'

export type PageTransitionType = 'NORMAL' | 'MENU_TO_PAGE' | 'HOMEPAGE_TO_CASE_STUDY' | 'IMMEDIATE'
export type SectionPreviewProps = {
  id: string
  sections: Array<any | SectionData | ArticleSection | PortfolioSection>
  minimizePageDuringOpenNav: (target: RefObject<HTMLElement | null>, isNavOpen: boolean) => void
  footerType: any
  type: string
  slug: string
  children: ReactNode
}

export interface mDivProps extends HTMLMotionProps<'div'> {
  children: ReactNode
  className?: string
}

const tz = {
  position: 'fixed', top: 0, left: 0, width: '100%', height: '100%',

  overflow: 'hidden',
}
const tU = {
  position: 'relative', top: 0, left: 0, width: '100%', height: 'auto', overflow: 'visible',
}
const dlay = 0.7
export const transitionMappings = {
  NORMAL: {
    start: {
      ...tz, opacity: 0,
    }, enter: {
      ...tU, opacity: 1, transition: {
        ease: 'easeIn', duration: 0.3, delay: dlay,
      },
    }, exit: {
      ...tz, opacity: 0, transition: {
        delay: dlay, duration: 0.3, ease: 'easeOut',
      },
    },
  }, MENU_TO_PAGE: {
    start: {
      ...tz,
    }, enter: {
      ...tU, opacity: 1, transition: {
        duration: 0, delay: 0,
      },
    }, exit: {
      transition: {
        duration: 0, delay: 0,
      },
    },
  }, HOMEPAGE_TO_CASE_STUDY: {
    start: {
      ...tz,
    }, enter: {
      ...tU, transition: {
        delay: 0, duration: 0,
      },
    }, exit: {
      opacity: 0, position: 'relative', transition: {
        delay: 0, duration: 0,
      },
    },
  }, IMMEDIATE: {
    start: {}, enter: {
      opacity: 1, transition: {
        delay: 0, duration: 0.1, ease: 'easeIn',
      },
    }, exit: {
      opacity: 0, transition: {
        delay: 0, duration: 0.1, ease: 'easeOut',
      },
    },
  },
}
export const getPageTransitionVariants = (l) => {
  let c: any = transitionMappings.NORMAL
  return (l === 'HOMEPAGE_TO_CASE_STUDY' && (c = transitionMappings.HOMEPAGE_TO_CASE_STUDY), l === 'MENU_TO_PAGE' && (c = transitionMappings.MENU_TO_PAGE), l === 'IMMEDIATE' && (c = transitionMappings.IMMEDIATE), c)
}
export const trans = new Map()
trans.set('top', { x: '0', y: '-100%' })
trans.set('bottom', { x: '0', y: '100%' })
trans.set('right', { x: '100%', y: '0' })
trans.set('left', { x: '-100% ', y: '0' })
const use_transition_style_fix = () => (useEffect(() => {
  Array.from(document.querySelectorAll('head > link[rel="stylesheet"][data-n-p]')).forEach((l) => {
    l.removeAttribute('data-n-p')
  })
  const l = new MutationObserver((l) => {
    l.forEach((l) => {
      const c = l.target
      c.nodeName === 'STYLE' && (c as HTMLElement).getAttribute('media') === 'x' && (c as HTMLElement).removeAttribute('media')
    })
  })
  return (l.observe(document.head, {
    subtree: !0, attributeFilter: ['media'],
  }), () => {
    l.disconnect()
  })
}, []), null)
gsap.registerPlugin(ScrollTrigger)
// Main PageTransition Component
export const PageTransition = ({
  type, slug, children,
}: {
  type: string
  slug: string[]
  children: ReactNode
}) => {
  const navIsOpen = useRPStore((l) => l.navIsOpen)
  const navIsOpenDebounced = useRPStore((l) => l.navIsOpenDebounced)
  const setN = useRPStore((l) => l.setNavIsOpen)
  const isPreloader = useRPStore((l) => l.isPreloader)
  const setPage = useVoyageur((l) => l.setPage)
  const pageRef = useRef<HTMLDivElement>(null!)
  const setCursorState = useCursorStore((l) => l.setCursorState)[0]
  const transitionOutType = useRPStore((l) => l.transitionOutType)
  const pageIsTransitioning = useRPStore((l) => l.pageIsTransitioning)
  const setPageIsTransitioning = useRPStore((l) => l.setPageIsTransitioning),
    scroll = useLenis(), { isMobile } = useIsMobile(), scrollToTop = () => window.scroll(0, 0)
  use_transition_style_fix()
  useEffect(() => {
    setPage({ pageType: type, slug: slug })

  }, [])

  // useEffect(() => {
  //   timeOutRef.current && clearTimeout(timeOutRef.current),
  //     navigationPageItemSelected !== -1 && setCurrentKey(navigationPageItemSelected),
  //     (timeOutRef.current = setTimeout(() => {
  //       setCurrentKey(navigationPageItemSelected)
  //     }, 1400))
  // }, [navigationPageItemSelected])

  const scrollRefresher = useCallback(() => {
    scroll && scroll.resize()
  }, [scroll])

  const [scaled, setScaled] = useState(1.1 * getNavigationHeightRatio())
  useGSAP(() => {
    if (!pageRef.current || !scroll) return
    gsap.killTweensOf(pageRef.current)
    pageRef.current.style.removeProperty('transform')
    let scaleDown = scaled
    let scaledScrollY = (1 - scaleDown) * (scroll.scroll - scroll.limit / 2)
    isMobile && ((scaledScrollY = 0), (scaleDown = 1))
    gsap.to(pageRef.current, {
      y: navIsOpen ? scaledScrollY : 0,
      scale: navIsOpen ? scaleDown : 1,
      ease: 'Power3.inOut',
      duration: 1.2,
      onComplete: () => {
        !navIsOpen && gsap.to(pageRef.current, { delay: 0.4, clearProps: 'transform' })
      },
    })
  }, { dependencies: [navIsOpen] })
  const toR = useRef<ReturnType<typeof setTimeout>>(null!)
  const onComplete = useCallback(() => {
    ScrollTrigger.refresh()
    scrollRefresher()
    setPageIsTransitioning(false)
  }, [])

  return (<motion.div key="navigation" initial="start" animate="enter" exit="exit" data-themed="background-color"
                      ref={pageRef} variants={getPageTransitionVariants(transitionOutType)}
                      className={cn('page', { transitioning: pageIsTransitioning })} onAnimationStart={(phase) => {
    phase === 'exit' && (setPageIsTransitioning(true)), toR.current && clearTimeout(toR.current), (toR.current = setTimeout(() => {
      setN(!1)
    }, 50))
    !isMobile && setCursorState(null)
  }} onAnimationComplete={(phase) => {
    phase === 'enter' && onComplete(), phase === 'exit' && (setTimeout(() => {
      scrollRefresher(), scrollToTop()
    }, 20))
  }}>
    {children}
  </motion.div>)
}

let M = 0.7

export const PageTransitionPortal = () => {
  const frameDir = ['top', 'right', 'bottom', 'left']
  const cornDir = [['topLeft', 'M500 0H0V500C0 223.858 223.858 0 500 0Z'], ['topRight', 'M500 500L500 4.19617e-05L1.90735e-05 -2.18557e-05C276.142 0.000249614 500 223.858 500 500Z'], ['bottomRight', 'M0 500L500 500L500 0C500 276.142 276.142 500 0 500Z'], ['bottomLeft', 'M-2.18557e-05 0L0 500L500 500C223.858 500 -9.78513e-06 276.142 -2.18557e-05 0Z']]
  let frameRefs = useRef<HTMLElement[]>([]), cornerRefs = useRef<HTMLElement[]>([]),
    svgRefs = useRef<HTMLElement[]>([]), m = useRef(null), { isMobile: isMobile } = useIsMobile(),
    pageIsTransitioning = useRPStore((l) => l.pageIsTransitioning),
    transitionOutType = useRPStore((l) => l.transitionOutType),
    setIsTransitioningWipe = useRPStore((l) => l.setIsTransitioningWipe),
    setCanInteract = useRPStore((l) => l.setCanInteract),
    isTransitioningWipe = useRPStore((l) => l.isTransitioningWipe), alreadyReset = useRef(false), scroll = useLenis()
  const animateTransition = useCallback((h: boolean, p: () => void) => {
    if (!canUseDOM) return
    let navOpeningElement = getNavOpeningElement()
    if (!frameRefs.current.length || !cornerRefs.current.length || !svgRefs.current.length || !navOpeningElement) return
    let g = navOpeningElement.getBoundingClientRect(), v = g.top
    frameRefs.current.forEach((l, c) => {
      if (!l) return
      gsap.killTweensOf(l)
      let xMove: number | string = 0, yMove: number | string = 0
      if (!h) switch (c) {
        case 0:
          yMove = '-100%'
          break
        case 1:
          xMove = '100%'
          break
        case 2:
          yMove = '100%'
          break
        case 3:
          xMove = '-100%'
      }
      gsap.to(l, {
        x: xMove, y: yMove, duration: M, ease: h ? 'Power4.easeInOut' : 'Power3.easeInOut', onComplete: () => {
          0 === c && p && p()
        },
      })
    })
    cornerRefs.current.forEach((l, c) => {
      if (!l) return
      gsap.killTweensOf(l)
      let d = 0, p = 0, m = 0.5 * window.innerWidth
      if (h) switch (c) {
        case 0:
          ;(p = v - 1), (d = m - 1)
          break
        case 1:
          ;(p = v - 1), (d = -m + 1)
          break
        case 2:
          ;(d = -m + 1), (p = -v + 1)
          break
        case 3:
          ;(d = m - 1), (p = -v + 1)
      }
      gsap.to(l, {
        x: d, y: p, duration: M, ease: h ? 'Power4.easeInOut' : 'Power3.easeInOut',
      })
    })
    svgRefs.current.forEach((l) => {
      l && (gsap.killTweensOf(l), gsap.to(l, {
        scale: h ? 1 : 0, duration: M, ease: h ? 'Power4.easeInOut' : 'Power3.easeInOut',
      }))
    })
  }, [frameRefs, cornerRefs, svgRefs])
  const setCur = useCursorStore((r) => r.setCursorState)[0]
  useEffect(() => {
    if (!pageIsTransitioning) {
      setCur(null)
    }
  }, [pageIsTransitioning])
  useEffect(() => {
    if (!isTransitioningWipe || alreadyReset.current) return
    alreadyReset.current = true
    let fire = async () => {
      await wait(10), animateTransition(!0, async () => {
        setCanInteract(!1), window.scroll(0, 0), scroll && scroll.scrollTo(0, {
          immediate: !0,
        }), await wait(500), window.scroll(0, 0), ScrollTrigger.refresh(), scroll && scroll.scrollTo(0, {
          immediate: !0,
        }), scroll && scroll.resize(), animateTransition(!1, () => {
          setIsTransitioningWipe(!1), setCanInteract(!0), (alreadyReset.current = false), scroll && scroll.resize(), ScrollTrigger.refresh()
        })
      })
    }
    fire()
  }, [isMobile, pageIsTransitioning, transitionOutType, animateTransition, isTransitioningWipe, setIsTransitioningWipe, setCanInteract, scroll])
  return (<div ref={m} className="pt_container">
    {frameDir.map((v, index) => (<div data-themed="background-color" className={`pt_mask` + ` pt_${v}`}
                                      style={{ transform: `translate(${trans.get(v).x},${trans.get(v).y})` }}
                                      key={v + 'pt'} ref={(el) => {
      frameRefs.current[index] = el!
    }}></div>))}
    {cornDir.map((v, index) => (<div className={`pt_cornerstones pt_${v[0]}`} key={v[0] + 'corner'} ref={(el) => {
      cornerRefs.current[index] = el!
    }}>
      <div className="pt_cs_svg" ref={(el) => {
        svgRefs.current[index] = el!
      }}>
        <SvgIco viewBox="0 0 500 500" fill="none" paths={[v[1], {
          fillRule: 'evenodd', clipRule: 'evenodd', fill: 'currentColor', 'data-themed': 'fill,color',
        }]} />
      </div>
    </div>))}
  </div>)
}
/*
 <AnimatePresence mode="sync" key={'navigation'} initial={false}>
        {navigationPageItemData.map((l, c) => {
          if (!l.link || l.link.type === 'custom' || !l.link.reference) return null
          let slug =
            typeof l.link.reference.value === 'string'
              ? l.link.reference.value
              : l.link.reference.value.slug
          let previewKey = getMenuPagePreviewKey(l.link.reference.relationTo, slug),
            h = navigationPageItemSelected === previewKey
          if (!h && !navIsOpenDebounced && currentKey !== previewKey && !isPreloader) return null
          return (
            <SectionPreview
              id={previewKey}
              type={'pages'}
              slug={slug}
              key={previewKey}
              sections={[]}
              minimizePageDuringOpenNav={transitionCallback}
            />
          )
        })}
      </AnimatePresence>
* */
