'use client'
import { useRouter } from 'next/navigation'
import { transitionSetter } from '@/components/UX/Transition/transitionSetter'

export const goToPage = (page: string) => {
  const g = useRouter()
  const { setGenericPageTransition } = transitionSetter()
  setGenericPageTransition(),
    setTimeout(() => {
      g.push(page, { scroll: !1 })
    }, 40)
}
