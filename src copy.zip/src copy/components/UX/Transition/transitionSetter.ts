'use client'
import { useCallback } from 'react'

import { useCursorStore, useRPStore } from '@/providers/RP_Pro'

export const transitionSetter = function () {
  const setTransitionOutType = useRPStore((l) => l.setTransitionOutType)
  const setTransitionWipe = useRPStore((l) => l.setIsTransitioningWipe)

  const isNavOpen = useRPStore((l) => l.navIsOpen)
  const setCurs = useCursorStore((l) => l.setCursorState)[0]
  const setGenericPageTransition = useCallback(() => {
    setTransitionOutType('NORMAL'), isNavOpen || setTransitionWipe(false), setCurs(null)
  }, [setTransitionOutType, setTransitionWipe, isNavOpen])

  return {
    setGenericPageTransition,
  }
}
