'use client'

import * as React from 'react'
import { Command as CommandPrimitive } from 'cmdk'
import { SearchIcon } from 'lucide-react'

import { cn } from '@/lib/utils'
import {
  Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle,
} from '@/components/ui/dialog'
import { useCursorStore, useSearchBar } from '@/providers/RP_Pro'
import { useIsMobile } from '@/utilities/getBreakpoints'
import { useCursorHandlers } from '../core/cursorWrapper'

function Command({
  className, ...props
}: React.ComponentProps<typeof CommandPrimitive>) {

  return (<CommandPrimitive data-slot="command"
    className={cn('flex h-full w-full flex-col overflow-hidden rounded-lg bg-[oklch(var(--n-s-fg)/.35)]', className)}
    data-themed={'background-color'}
    {...props} />)
}

function CommandDialog({
  title = 'Command Palette', description = 'Search for a command to run...', children, open, onOpenChange, ...props
}: React.ComponentProps<typeof Dialog> & {
  title?: string
  description?: string
}) {
  return (<Dialog open={open} onOpenChange={onOpenChange} {...props}>
    <DialogHeader className="sr-only">
      <DialogTitle>{title}</DialogTitle>
      <DialogDescription>{description}</DialogDescription>
    </DialogHeader>
    <DialogContent open={open} className="overflow-hidden p-0">
      <Command
        data-themed={'background-color,height,color'}
        className="p-[4px] [&_[cmdk-group-heading]]:px-[8px] [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group]:not([hidden])_~[cmdk-group]]:pt-0 [&_[cmdk-group]]:px-[8px] [&_[cmdk-input-wrapper]_svg]:h-8 [&_[cmdk-input-wrapper]_svg]:w-8 [&_[cmdk-input]]:h-[48px] [&_[cmdk-item]]:px-[8px] [&_[cmdk-item]]:py-3 [&_[cmdk-item]_svg]:h-5 [&_[cmdk-item]_svg]:w-5 text-xl">
        {children}
      </Command>
    </DialogContent>
  </Dialog>)
}

function CommandInput({
  className, ...props
}: React.ComponentProps<typeof CommandPrimitive.Input>) {
  return (<div className="flex p-[8px] items-center w-full z-1" cmdk-rp-courier={''} data-slot="command-input-wrapper">
    <SearchIcon className="mr-2 size-4 shrink-0 text-[oklch(var(--bg)/1)]" data-themed={'color, stroke'} />
    <CommandPrimitive.Input data-slot="command-input"
      className={cn('flex text-sm h-[44px] w-full rounded-md bg-transparent py-5 outline-hidden disabled:cursor-not-allowed disabled:opacity-50 placeholder:text-[oklch(var(--bg)/1)]', className)}
      data-themed={'color, background-color,height,placeholder-color'}
      {...props} />
  </div>)
}

function CommandList({
  className, ...props
}: React.ComponentProps<typeof CommandPrimitive.List>) {
  return (<CommandPrimitive.List data-slot="command-list"
    className={cn('max-h-[500px] scroll-py-1.5 overflow-y-auto overflow-x-hidden relative', className)}
    {...props} />)
}

function CommandEmpty({
  ...props
}: React.ComponentProps<typeof CommandPrimitive.Empty>) {
  return (<CommandPrimitive.Empty data-slot="command-empty"
    className="text-xl absolute py-6 text-center flex items-center justify-center inset-0 text-[oklch(var(--border-subtle))]"
    {...props} />)
}

function CommandGroup({
  className, ...props
}: React.ComponentProps<typeof CommandPrimitive.Group>) {
  return (<CommandPrimitive.Group data-slot="command-group"
    className={cn('overflow-hidden rounded-[4px] p-6 [&_[cmdk-group-heading]]:px-3.5 [&_[cmdk-group-heading]]:py-2.5 [&_[cmdk-group-heading]]:text-xl [&_[cmdk-group-heading]]:font-medium [&_[cmdk-group-heading]]:text-[oklch(var(--border-subtle)/1)]', className)}
    {...props} />)
}

function CommandSeparator({
  className, ...props
}: React.ComponentProps<typeof CommandPrimitive.Separator>) {
  return (<CommandPrimitive.Separator data-slot="command-separator"
    className={cn('-mx-1.5 h-px bg-[oklch(var(--border-subtle)/.8)]', className)}
    {...props} />)
}

function CommandItem({
  className, onMouseEnter: onEnter, onMouseLeave: onLeave, ...props
}: React.ComponentProps<typeof CommandPrimitive.Item>) {
  const handler = useCursorHandlers('dom', { onEnter, onLeave })
  const { onMouseEnter, onMouseLeave } = handler

  return (<CommandPrimitive.Item
    className={cn('group min-h-[2.5rem] relative text-lg flex transition-colors duration-300 ease-in-out text-[oklch(var(--bg)/1)] gap-3.5 select-none items-center rounded-sm px-3.5 py-2.5 outline-hidden data-[disabled=true]:pointer-events-none data-[selected=true]:bg-[oklch(var(--off-bg)/.5)] data-[selected=true]:text-[oklch(var(--faded-fg)/1)] data-[disabled=true]:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-6 [&_svg]:shrink-0', className)}
    {...props} onMouseEnter={onMouseEnter} onMouseLeave={onMouseLeave}
  />)
}

function CommandShortcut({
  className, ...props
}: React.ComponentProps<'span'>) {
  return (<span data-slot="command-shortcut"
    className={cn('text-muted-foreground ml-auto text-xs tracking-widest', className)}
    {...props} />)
}

//   <div className={cn('ml-auto flex gap-0.5', className)} {...props}>
//       {shortcut.split(' ').map((key) => {
//         return <kbd key={key}>{key}</kbd>
//       })}
//     </div>
export {
  Command,
  CommandDialog,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
  CommandShortcut,
  CommandSeparator,
}
