import { cn } from '@/lib/utils'
import { Button } from '@/components/ui/button'
import {
  Card, CardContent, CardDescription, CardHeader, CardTitle,
} from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { authMembersProviderMap } from '@/auth.members.config'
import { signIn } from '@/auth.members'
import { authProviderIcons } from '@/components/icons/authProviders'
import { Link } from '@/components/UX/Link'

export function LoginForm({
  className, ...props
}: React.ComponentProps<'div'>) {
  return (<div className={cn('flex flex-col gap-9', className)} {...props}>
      <Card className="bg-[oklch(var(--faded-bg)/.9)]">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl">Welcome back.</CardTitle>
          <CardDescription>
            Check in with your social account
          </CardDescription>
        </CardHeader>
        <CardContent>
            <div className="grid gap-9">
              <div className="flex flex-col gap-7">
                {Object.values(authMembersProviderMap).map((provider) => (<form className="col" key={provider.name} action={async () => {
                  'use server'
                  await signIn(provider.id )
                }}><Button  variant="outline"
                           className="inline-flex min-h-[35px] items-center justify-center gap-[8px] whitespace-nowrap rounded-md text-lg font-medium transition-colors focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-6 [&_svg]:shrink-0 border border-[oklch(var(--faded-fg)/.65)] bg-[oklch(var(--off-bg)/.7)] shadow-sm hover:bg-accent hover:text-accent-foreground h-14 px-4 py-3 w-full">
                  {authProviderIcons[provider.name] || null}
                  Check in with {provider.name}
                </Button></form>))}
              </div>
              <div className={"relative h-[3px] w-full bg-transparent flex items-center justify-center gap-[1px]"}>
                <div className={"h-[1px] flex-[1_1_35%] relative -left-1 bg-linear-to-r from-transparent to-[oklch(var(--fg)/.7)]"}></div>
                <div className={'text-[12px] px-[1px] text-center'}>Or continue with </div>
                <div className={"h-[1px] flex-[1_1_35%] relative -right-1 bg-linear-to-r from-[oklch(var(--fg)/.7)] to-transparent"}></div>
              </div>
              <div className="grid gap-9">
              {/*  <div className="grid gap-5">*/}
              {/*    <Label htmlFor="email">Email</Label>*/}
              {/*    <Input id="email" type="email" placeholder="" required />*/}
              {/*  </div>*/}
              {/*  <div className="grid gap-5">*/}
              {/*    <div className="flex items-center">*/}
              {/*      <Label htmlFor="password">Password</Label>*/}
              {/*      <Link href="#" className="ml-auto text-lg underline-offset-4 hover:underline">*/}
              {/*        Forgot your password?*/}
              {/*      </Link>*/}
              {/*    </div>*/}
              {/*    <Input id="password" type="password" required />*/}
              {/*  </div>*/}
              {/*  <Button type="submit" className="w-full">*/}
              {/*    Login*/}
              {/*  </Button>*/}
              </div>
              <div className="text-center text-lg">
                Don&apos;t have an account?{' '}
                <Link href="#" className="underline underline-offset-4">
                  Sign up
                </Link>
              </div>
            </div>
        </CardContent>
      </Card>
      <div
        className="text-muted-foreground *:[a]:hover:text-primary text-center text-lg text-balance *:[a]:underline *:[a]:underline-offset-4">
        By clicking continue, you agree to our <Link href="#">Terms of Service</Link>{' '}
        and <Link href="#">Privacy Policy</Link>.
      </div>
    </div>)
}
