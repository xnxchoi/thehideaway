'use client'

import type { SanitizedPermissions } from 'payload'

import React, { createContext, useCallback, useContext, useEffect, useState } from 'react'

import type { User } from '@/payload-types'
import type { AuthContext, Create, ForgotPassword, Login, Logout, ResetPassword } from './types'

import { gql, USER } from './gql'
import { rest } from './rest'
import { useRPStore } from '@/providers/RP_Pro'
import { PayloadMeUser } from 'payload-admin-bar'
import { RP_Patron } from '@/stores/RP_Ui'

const Context = createContext({} as AuthContext)

export const AuthProvider: React.FC<{
  api?: 'gql' | 'rest'
  children: React.ReactNode
  devMode?: boolean
}> = (props) => {
  let { api, children, devMode } = props
  const [user, setUser] = useState<null | RP_Patron>()
  const [permissions, setPermissions] = useState<null | SanitizedPermissions>(null)
  const setU = useRPStore((l) => l.setUser),
    setP = useRPStore((l) => l.setPermissions)
  const dummyUser: RP_Patron = {
    email: 'dev@email.com',
    id: '1234567890',
    name: 'dev',
  }

  const create = useCallback<Create>(
    async (args) => {
      if (api === 'rest') {
        const user = await rest(`${process.env.NEXT_PUBLIC_SERVER_URL}/api/users`, args)
        setUser(user)
        return user
      }

      if (api === 'gql') {
        const { createUser: user } = await gql(`mutation {
        createUser(data: { email: "${args.email}", password: "${args.password}", firstName: "${args.firstName}", lastName: "${args.lastName}" }) {
          ${USER}
        }
      }`)

        setUser(user)
        return user
      }
    },
    [api],
  )

  const login = useCallback<Login>(
    async (args) => {
      if (api === 'rest') {
        const user = await rest(`${process.env.NEXT_PUBLIC_SERVER_URL}/api/users/login`, args)
        setUser(user)
        return user
      }

      if (api === 'gql') {
        const { loginUser } = await gql(`mutation {
        loginUser(email: "${args.email}", password: "${args.password}") {
          user {
            ${USER}
          }
          exp
        }
      }`)

        setUser(loginUser?.user)
        return loginUser?.user
      }
    },
    [api],
  )

  const logout = useCallback<Logout>(async () => {
    if (api === 'rest') {
      await rest(`${process.env.NEXT_PUBLIC_SERVER_URL}/api/users/logout`)
      setUser(null)
      return
    }

    if (api === 'gql') {
      await gql(`mutation {
        logoutUser
      }`)

      setUser(null)
    }
  }, [api])
  const fetchThis: () => Promise<PayloadMeUser> = useCallback(async () => {
    const fetchMe = async () => {
      try {
        const meRequest = await fetch(`${process.env.NEXT_PUBLIC_SERVER_URL}/api/users/me`, {
          method: 'get',
          credentials: 'include',
        })
        const meResponse = await meRequest.json()
        const { user } = meResponse

        if (user) {
          setUser(user)
          return user
        } else {
          if (devMode !== true) {
            setUser(null)
            return null
          } else {
            setUser(dummyUser)
            return dummyUser
          }
        }
      } catch (err) {
        console.warn(err)
        if (devMode === true) {
          setUser(dummyUser)
          return dummyUser
        }
      }
      return null
    }
    return await fetchMe()
  }, [devMode, setUser])
  useEffect(() => {
    fetchThis()
  }, [])
  useEffect(() => {
    user && setU(user)
  }, [user])
  useEffect(() => {
    let k: SanitizedPermissions | null = {}
    if (permissions) {
      k.canAccessAdmin = permissions.canAccessAdmin
      if (permissions.collections) {
        for (const key in permissions.collections) {
          k.collections = {
            ...k.collections,
            [key]: permissions?.collections[key]?.read?.permission,
          }
        }
      }
    } else {
      k = null
    }
    setP(k)
  }, [permissions])
  // On mount, get user and set
  // useEffect(() => {
  //   const fetchMe = async () => {
  //     if (api === 'rest') {
  //       const user = await rest(
  //         `${process.env.NEXT_PUBLIC_SERVER_URL}/api/users/me`,
  //         {},
  //         {
  //           method: 'GET',
  //         },
  //       )
  //       setUser(user)
  //     }
  //
  //     if (api === 'gql') {
  //       const { meUser } = await gql(`query {
  //         meUser {
  //           user {
  //             ${USER}
  //           }
  //           exp
  //         }
  //       }`)
  //
  //       setUser(meUser.user)
  //     }
  //   }
  //
  //   void fetchMe()
  // }, [api])

  const forgotPassword = useCallback<ForgotPassword>(
    async (args) => {
      if (api === 'rest') {
        const user = await rest(
          `${process.env.NEXT_PUBLIC_SERVER_URL}/api/users/forgot-password`,
          args,
        )
        setUser(user)
        return user
      }

      if (api === 'gql') {
        const { forgotPasswordUser } = await gql(`mutation {
        forgotPasswordUser(email: "${args.email}")
      }`)

        return forgotPasswordUser
      }
    },
    [api],
  )

  const resetPassword = useCallback<ResetPassword>(
    async (args) => {
      if (api === 'rest') {
        const user = await rest(
          `${process.env.NEXT_PUBLIC_SERVER_URL}/api/users/reset-password`,
          args,
        )
        setUser(user)
        return user
      }

      if (api === 'gql') {
        const { resetPasswordUser } = await gql(`mutation {
        resetPasswordUser(password: "${args.password}", token: "${args.token}") {
          user {
            ${USER}
          }
        }
      }`)

        setUser(resetPasswordUser.user)
        return resetPasswordUser.user
      }
    },
    [api],
  )

  return (
    <Context.Provider
      value={{
        create,
        forgotPassword,
        login,
        logout,
        permissions,
        resetPassword,
        setPermissions,
        setUser,
        user,
      }}
    >
      {children}
    </Context.Provider>
  )
}

type UseAuth<T = PayloadMeUser | User> = () => AuthContext

export const useAuth: UseAuth = () => useContext(Context)
