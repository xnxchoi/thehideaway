'use client'

import React, { createContext, ReactNode, useContext, useEffect, useRef, useState } from 'react'

import {
  createDeviceStore,
  createHAStore,
  createRafStore,
  HA_DEVICE,
  HA_VAULT,
  RAF,
} from '@/stores/RP_Ui'
import { createCursorStore, HA_CURS } from '@/stores/CursorStore'
import { useStore } from 'zustand/index'
import { createSearchBarStore, RP_SearchBar } from '@/stores/SearchStore'

export type RafAPI = ReturnType<typeof createRafStore>
export type HAAPI = ReturnType<typeof createHAStore>
export type HACPI = ReturnType<typeof createCursorStore>
export type DeviceAPI = ReturnType<typeof createDeviceStore>

export const DeviceContext = createContext<DeviceAPI | undefined>(undefined)
export const HAStoreContext = createContext<HAAPI | undefined>(undefined)
export const CurContext = createContext<HACPI | undefined>(undefined)
export const RafContext = createContext<RafAPI | undefined>(undefined)

export interface DeviceProviderProps {
  children: ReactNode
}

export interface HAStoreProviderProps {
  children: ReactNode
}

export interface CurProviderProps {
  children: ReactNode
}

export interface RafProviderProps {
  children: ReactNode
}

export interface URLProviderProps {
  children: ReactNode
}
export const DeviceProvider = ({ children }: DeviceProviderProps) => {
  //@ts-ignore
  const storeRef = useRef<HA_DEVICE>(undefined)

  if (!storeRef.current) {
    storeRef.current = createDeviceStore()
  }
  return <DeviceContext.Provider value={storeRef.current}>{children}</DeviceContext.Provider>
}
export const HAStoreProvider = ({ children }: HAStoreProviderProps) => {
  // @ts-ignore
  const storeRef = useRef<HAAPI>(undefined)
  if (!storeRef.current) {
    storeRef.current = createHAStore()
  }

  return <HAStoreContext.Provider value={storeRef.current}>{children}</HAStoreContext.Provider>
}

export const RafProvider = (l: { children: ReactNode }) => {
  const { children } = l
  const animations = useRef(0)
  const [animationList, setAnimation] = useState<{ [key: string]: (l?: any) => void }>({})
  const storeRef = useRef<RafAPI>(null!)
  if (!storeRef.current) {
    storeRef.current = createRafStore({
      addToRaf: ({ key, callback }) =>
        setAnimation({
          ...animationList,
          [key]: callback,
        }),
      removeFromRaf: (l) => setAnimation(() => (delete animationList[l], animationList)),
    })
  }
  useEffect(() => {
    animations.current && cancelAnimationFrame(animations.current)
    const render = () => {
      animations.current = requestAnimationFrame(render)
      Object.keys(animationList).forEach((l) => {
        animationList[l]()
      })
    }
    render()
  }, [animationList])
  return <RafContext.Provider value={storeRef.current}>{children}</RafContext.Provider>
}
export const CurProvider = ({ children }: CurProviderProps) => {
  // @ts-ignore
  const sRef = useRef<HACPI>(undefined)
  if (!sRef.current) {
    sRef.current = createCursorStore()
  }
  return <CurContext.Provider value={sRef.current}>{children}</CurContext.Provider>
}
export const useCursorStore = <T,>(selector: (store: HA_CURS) => T): [T, HACPI] => {
  const haStoreContext = useContext(CurContext)
  if (!haStoreContext) {
    throw new Error(`useCursorStore must be used within CurStoreProvider`)
  }
  return [useStore(haStoreContext, selector), haStoreContext]
}
export const useRPStore = <T,>(selector: (store: HA_VAULT) => T): T => {
  const haStoreContext = useContext(HAStoreContext)
  if (!haStoreContext) {
    throw new Error('useRPStore must be used within RPStoreProvider')
  }
  return useStore(haStoreContext, selector)
}

export const useRafStore = <T,>(selector: (store: RAF) => T): T => {
  const rafContext = useContext(RafContext)
  if (!rafContext) {
    throw new Error('useRafStore must be used within RafStoreProvider')
  }
  return useStore(rafContext, selector)
}
export type SearchAPI = ReturnType<typeof createSearchBarStore>
const SearchBarContext = createContext<SearchAPI | undefined>(undefined)
export const SearchBarProvider = ({ children }: { children: ReactNode }) => {
  // @ts-ignore
  const searchBar = useRef<SearchAPI>(undefined)
  if (!searchBar.current) {
    searchBar.current = createSearchBarStore()
  }
  return <SearchBarContext.Provider value={searchBar.current}>{children}</SearchBarContext.Provider>
}
export const useSearchBar = <T,>(selector: (store: RP_SearchBar) => T): T => {
  const searchBar = useContext(SearchBarContext)
  if (!searchBar) {
    throw new Error('useSearchBar must be used within a SearchBarProvider')
  }
  return useStore(searchBar, selector)
}
export const getDeviceInfo = () => {
  const deviceContext = useContext(DeviceContext)
  if (!deviceContext) {
    throw new Error('getDeviceInfo must be used within a DeviceProvider')
  }
  return deviceContext
}
