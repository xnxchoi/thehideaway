'use client'
import { useRPStore } from '@/providers/RP_Pro'
import { useTheme } from '@/providers/Theme'
import { defaultTheme, getImplicitPreference, themeLocalStorageKey } from '@/providers/Theme/shared'
import { useEffect } from 'react'
import { storageAvailable } from '@/utilities/isLocalStorageAvailable'
import { themeIsValid } from '@/providers/Theme/types'
import canUseDOM from '@/utilities/canUseDOM'

export const MiddleMan = ({ children }: { children: React.ReactNode }) => {
  const localStorageEnabled = useRPStore(r => r.localStorageEnabled),
    setLocalStorageEnabled = useRPStore(r => r.setLocalStorageEnabled)
  const locked = useTheme(r => r.locked)
  const setTheme = useTheme(store => store.setTheme)
  const saveTheme = useTheme(r => r.saveTheme)
  const pageTheme = useTheme(store => store.pageTheme)
  const savedTheme = useTheme(store => store.savedTheme)
  const theme = useTheme(store => store.theme)
  useEffect(() => {
    if (canUseDOM) {
      let s = storageAvailable('localStorage')
      setLocalStorageEnabled(s)
      let implicitPreference = (getImplicitPreference() ?? defaultTheme)
      if (s) {
        const k = window.localStorage.getItem(themeLocalStorageKey)
        if (themeIsValid(k)) {
          implicitPreference = k
        }
      }
      saveTheme(implicitPreference)

    }
  }, [])
  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme)
  }, [theme])
  useEffect(() => {
    savedTheme && (setTheme(locked && pageTheme || savedTheme))
  }, [locked, savedTheme, pageTheme])
  useEffect(() => {
    if (localStorageEnabled) {
      if (savedTheme) {
        window.localStorage.setItem(themeLocalStorageKey, savedTheme)
      } else {
        window.localStorage.removeItem(themeLocalStorageKey)
      }
    }
  }, [saveTheme])


  return <>{children}</>
}
