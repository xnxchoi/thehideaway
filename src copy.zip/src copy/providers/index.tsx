'use client'

import {
  CurProvider, DeviceProvider, getDeviceInfo, HAStoreProvider, RafProvider, SearchBarProvider, useRPStore,
} from '@/providers/RP_Pro'

import { HeaderThemeProvider } from './HeaderTheme'
import { ThemeProvider, useTheme } from './Theme'
import React, { useEffect } from 'react'
import { Voyageur, VoyageurProvider } from '@/stores/RP_Voyageur'
import { themeLocalStorageKey } from './Theme/shared'
import { MiddleMan } from './MiddleMan'


export const Providers: React.FC<{
  children: React.ReactNode
}> = ({ children }) => {
  return (<DeviceProvider>
    <RafProvider>
      <HAStoreProvider>
        <Voyageur>
          <ThemeProvider>
            <MiddleMan>
              <CurProvider>
                <SearchBarProvider>
                  <HeaderThemeProvider>{children}</HeaderThemeProvider>
                </SearchBarProvider>
              </CurProvider>
            </MiddleMan>
          </ThemeProvider>
        </Voyageur>
      </HAStoreProvider>
    </RafProvider>
  </DeviceProvider>)
}
