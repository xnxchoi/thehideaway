'use client'

import React, { Context, createContext, useCallback, useContext, useEffect, useRef, useState } from 'react'

import canUseDOM from '@/utilities/canUseDOM'

import { defaultTheme, getImplicitPreference, themeLocalStorageKey } from './shared'
import type { Theme, ThemeContextType } from './types'
import { themeIsValid } from './types'
import { useRPStore } from '@/providers/RP_Pro'
import { useVoyageur } from '@/stores/RP_Voyageur'
import { createStore } from 'zustand'
import { RAF } from '@/stores/RP_Ui'
import { useStore } from 'zustand/index'
import { storageAvailable } from '@/utilities/isLocalStorageAvailable'

const initialContext: ThemeContextType = {
  savedTheme: 'dark', pageTheme: null, theme:'dark', locked: false,

}
export const FALLBACK_THEME: Theme = 'dark'
type ThemeActions = {
  saveTheme: (theme: Theme) => void
  setTheme: (theme: Theme | null) => void // eslint-disable-line no-unused-vars
  setPageTheme: (theme: Theme | null, lock?: boolean) => void // eslint-disable-line no-unused-vars
  clearSave: () => void
  setLocked: (locked: boolean) => void
  clearPageTheme: () => void
  toggleTheme: () => void
  setBaseTheme: () => void
}
type ThemeStore = ThemeContextType & ThemeActions
const createThemeStore = (init: ThemeContextType = initialContext) => {

  return createStore<ThemeStore>()((set) => ({
    ...init, saveTheme: (themeToSet: Theme) => (set(state => ({
      ...state, savedTheme: themeToSet,

    }))), clearSave: () => (set((state) => {
      const def = getImplicitPreference() ?? FALLBACK_THEME
      return {
        ...state, theme: state.locked && state.pageTheme || def, savedTheme: def,
      }
    })), toggleTheme: () => set((state) => {
      if (state.locked) return (state)
      const vice = state.theme === 'dark' ? 'light' : 'dark'

      return ({
        ...state, theme: vice, savedTheme: vice,
      })
    }), setLocked: (locked: boolean) => set({ locked }), setTheme: (themeToSet: Theme) => set(state => {
      if (state.locked || state.theme === themeToSet) return (state)
      return ({
        ...state, theme: themeToSet,
      })
    }), setBaseTheme: () => set(state => ({
      ...state,
      theme: (state.locked ? (state.pageTheme ?? FALLBACK_THEME) : state.savedTheme) ?? FALLBACK_THEME,
      savedTheme: state.savedTheme ?? FALLBACK_THEME,
    })), setPageTheme: (themeToSet: Theme | null) => set(state => ({
      ...state, pageTheme: themeToSet, theme: state.locked && themeToSet || state.theme,
    })), clearPageTheme: () => set(state => ({
      ...state,
      pageTheme: null,
      locked: false,
      theme: state.savedTheme ?? FALLBACK_THEME,
      savedTheme: state.savedTheme ?? FALLBACK_THEME,
    })),
  }))
}
export type ThemeAPI = ReturnType<typeof createThemeStore>
const ThemeContext: Context<ThemeAPI | undefined> = createContext(undefined)

export const ThemeProvider = ({ children }: { children: React.ReactNode }) => {
  const themeRef = useRef<ThemeAPI>(null!)
  if (!themeRef.current) {
    themeRef.current = createThemeStore()
  }
  return (<ThemeContext.Provider value={themeRef.current}>
    {children}
  </ThemeContext.Provider>)
}
export const useTheme = <T, >(selector: (store: ThemeStore) => T): T => {
  const context = useContext(ThemeContext)
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider')
  }
  return useStore(context, selector)
}

// export const useTheme = (): ThemeContextType => useContext(ThemeContext)
