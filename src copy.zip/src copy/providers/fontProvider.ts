import localFont from 'next/dist/compiled/@next/font/dist/local'

export const blatt = localFont({
  src: [{
    path: '/assets/fonts/Blatt/BlattRegular.otf', weight: '400', style: 'normal',
  }, {
    path: '/assets/fonts/Blatt/BlattMedium.otf', weight: '500', style: 'normal',
  }, {
    path: '/assets/fonts/Blatt/BlattSemiBold.otf', weight: '600', style: 'normal',
  }, {
    path: '/assets/fonts/Blatt/BlattBold.otf', weight: '700', style: 'normal',
  }, {
    path: '/assets/fonts/Blatt/BlattExtraBold.otf', weight: '800', style: 'normal',
  }, {
    path: '/assets/fonts/Blatt/BlattLight.otf', weight: '100', style: 'normal',
  }, {
    path: '/assets/fonts/Blatt/BlattSemiLight.otf', weight: '200', style: 'normal',
  }],
})
